CREATE POLICY "Store users can view customers from their owner"
ON public.customers
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.stores s
    WHERE s.auth_user_id = auth.uid()
      AND s.user_id = customers.user_id
  )
);

CREATE POLICY "Store users can view their own limit requests"
ON public.limit_requests
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.stores s
    WHERE s.id = limit_requests.store_id
      AND s.auth_user_id = auth.uid()
  )
);

CREATE POLICY "Clients can view their own limit requests"
ON public.limit_requests
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.customers c
    WHERE c.id = limit_requests.customer_id
      AND c.client_user_id = auth.uid()
  )
);