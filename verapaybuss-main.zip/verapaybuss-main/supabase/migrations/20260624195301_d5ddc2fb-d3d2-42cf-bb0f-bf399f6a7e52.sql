
CREATE TABLE public.store_month_closings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  store_name TEXT NOT NULL,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  total_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  purchases_count INTEGER NOT NULL DEFAULT 0,
  closed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_by_user_id UUID,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, store_name, year, month)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.store_month_closings TO authenticated;
GRANT ALL ON public.store_month_closings TO service_role;

ALTER TABLE public.store_month_closings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own store closings" ON public.store_month_closings
  FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_store_month_closings_updated_at
  BEFORE UPDATE ON public.store_month_closings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_store_month_closings_user_period ON public.store_month_closings(user_id, year, month);
