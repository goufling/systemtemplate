-- Drop the overly broad policy
DROP POLICY IF EXISTS "Public Access for loan-attachments" ON storage.objects;

-- Create a more restricted policy for selection
CREATE POLICY "Authenticated users can view loan-attachments"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'loan-attachments' 
  AND auth.role() = 'authenticated'
);
