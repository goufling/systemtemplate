
UPDATE public.loans
  SET customer_id = '6af1a113-2648-4f28-893b-369000d07c84'
  WHERE customer_id = '926ab58e-0b7e-4ba4-ac07-ac7f8c4863fc';

UPDATE public.installments
  SET customer_id = '6af1a113-2648-4f28-893b-369000d07c84'
  WHERE customer_id = '926ab58e-0b7e-4ba4-ac07-ac7f8c4863fc';

DELETE FROM public.customers
  WHERE id = '926ab58e-0b7e-4ba4-ac07-ac7f8c4863fc';
