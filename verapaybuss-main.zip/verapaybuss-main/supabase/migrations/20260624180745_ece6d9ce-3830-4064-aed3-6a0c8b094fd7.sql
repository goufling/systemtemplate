ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS signup_token UUID UNIQUE DEFAULT gen_random_uuid();
UPDATE public.profiles SET signup_token = gen_random_uuid() WHERE signup_token IS NULL;