-- Fix search_path for handle_updated_at
ALTER FUNCTION public.handle_updated_at() SET search_path = public;

-- Fix search_path for handle_new_user and restrict access
ALTER FUNCTION public.handle_new_user() SET search_path = public;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM public;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;
