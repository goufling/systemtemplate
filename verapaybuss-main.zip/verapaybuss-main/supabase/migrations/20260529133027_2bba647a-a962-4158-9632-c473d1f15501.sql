
-- Helper function for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- CATEGORIES
CREATE TABLE public.personal_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'expense',
  color TEXT DEFAULT '#D8A86C',
  icon TEXT DEFAULT 'Wallet',
  monthly_budget NUMERIC DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_categories TO authenticated;
GRANT ALL ON public.personal_categories TO service_role;
ALTER TABLE public.personal_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_categories" ON public.personal_categories FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- TRANSACTIONS
CREATE TABLE public.personal_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  type TEXT NOT NULL,
  category_id UUID REFERENCES public.personal_categories(id) ON DELETE SET NULL,
  category_name TEXT,
  transaction_date DATE NOT NULL DEFAULT CURRENT_DATE,
  payment_method TEXT,
  notes TEXT,
  receipt_url TEXT,
  recurring_bill_id UUID,
  credit_card_id UUID,
  source TEXT DEFAULT 'manual',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_personal_transactions_user_date ON public.personal_transactions(user_id, transaction_date DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_transactions TO authenticated;
GRANT ALL ON public.personal_transactions TO service_role;
ALTER TABLE public.personal_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_transactions" ON public.personal_transactions FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- RECURRING BILLS
CREATE TABLE public.personal_recurring_bills (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  category_id UUID REFERENCES public.personal_categories(id) ON DELETE SET NULL,
  category_name TEXT,
  due_day INTEGER NOT NULL,
  type TEXT NOT NULL DEFAULT 'expense',
  active BOOLEAN NOT NULL DEFAULT true,
  reminder_days_before INTEGER DEFAULT 3,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_recurring_bills TO authenticated;
GRANT ALL ON public.personal_recurring_bills TO service_role;
ALTER TABLE public.personal_recurring_bills ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_recurring_bills" ON public.personal_recurring_bills FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- CREDIT CARDS
CREATE TABLE public.personal_credit_cards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  bank TEXT,
  brand TEXT,
  last_digits TEXT,
  credit_limit NUMERIC NOT NULL DEFAULT 0,
  closing_day INTEGER NOT NULL,
  due_day INTEGER NOT NULL,
  color TEXT DEFAULT '#D8A86C',
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_credit_cards TO authenticated;
GRANT ALL ON public.personal_credit_cards TO service_role;
ALTER TABLE public.personal_credit_cards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_credit_cards" ON public.personal_credit_cards FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- CREDIT CARD EXPENSES
CREATE TABLE public.personal_credit_card_expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  credit_card_id UUID NOT NULL REFERENCES public.personal_credit_cards(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  total_amount NUMERIC NOT NULL,
  installments INTEGER NOT NULL DEFAULT 1,
  current_installment INTEGER NOT NULL DEFAULT 1,
  purchase_date DATE NOT NULL DEFAULT CURRENT_DATE,
  category_id UUID REFERENCES public.personal_categories(id) ON DELETE SET NULL,
  category_name TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_personal_cc_expenses_card ON public.personal_credit_card_expenses(credit_card_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_credit_card_expenses TO authenticated;
GRANT ALL ON public.personal_credit_card_expenses TO service_role;
ALTER TABLE public.personal_credit_card_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_cc_expenses" ON public.personal_credit_card_expenses FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- GOALS
CREATE TABLE public.personal_goals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  target_amount NUMERIC NOT NULL,
  current_amount NUMERIC NOT NULL DEFAULT 0,
  deadline DATE,
  icon TEXT DEFAULT 'Target',
  color TEXT DEFAULT '#D8A86C',
  notes TEXT,
  completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.personal_goals TO authenticated;
GRANT ALL ON public.personal_goals TO service_role;
ALTER TABLE public.personal_goals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own personal_goals" ON public.personal_goals FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Triggers
CREATE TRIGGER trg_pc_updated BEFORE UPDATE ON public.personal_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_pt_updated BEFORE UPDATE ON public.personal_transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_prb_updated BEFORE UPDATE ON public.personal_recurring_bills FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_pcc_updated BEFORE UPDATE ON public.personal_credit_cards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_pg_updated BEFORE UPDATE ON public.personal_goals FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
