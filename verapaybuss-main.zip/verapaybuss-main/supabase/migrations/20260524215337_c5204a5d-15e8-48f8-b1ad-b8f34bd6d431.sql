-- Add attachment_url to loans table
ALTER TABLE public.loans ADD COLUMN IF NOT EXISTS attachment_url TEXT;

-- Create storage bucket for loan attachments if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('loan-attachments', 'loan-attachments', true)
ON CONFLICT (id) DO NOTHING;

-- Set up RLS for storage.objects
CREATE POLICY "Public Access for loan-attachments"
ON storage.objects FOR SELECT
USING (bucket_id = 'loan-attachments');

CREATE POLICY "Authenticated users can upload loan-attachments"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'loan-attachments' 
  AND auth.role() = 'authenticated'
);

CREATE POLICY "Users can update their own loan-attachments"
ON storage.objects FOR UPDATE
USING (bucket_id = 'loan-attachments' AND auth.uid() = owner);

CREATE POLICY "Users can delete their own loan-attachments"
ON storage.objects FOR DELETE
USING (bucket_id = 'loan-attachments' AND auth.uid() = owner);
