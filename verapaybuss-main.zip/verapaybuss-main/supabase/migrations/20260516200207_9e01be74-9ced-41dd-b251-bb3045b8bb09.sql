REVOKE EXECUTE ON FUNCTION public.handle_new_user FROM public, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_updated_at FROM public, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.log_activity FROM public, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_installment_status_after_payment FROM public, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.handle_new_user TO service_role;
GRANT EXECUTE ON FUNCTION public.handle_updated_at TO service_role;
GRANT EXECUTE ON FUNCTION public.log_activity TO service_role;
GRANT EXECUTE ON FUNCTION public.update_installment_status_after_payment TO service_role;