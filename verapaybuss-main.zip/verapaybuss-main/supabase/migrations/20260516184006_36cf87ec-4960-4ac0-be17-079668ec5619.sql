-- Adicionar campos à tabela de empréstimos (loans)
ALTER TABLE public.loans 
ADD COLUMN IF NOT EXISTS order_number TEXT,
ADD COLUMN IF NOT EXISTS capital_source TEXT DEFAULT 'proprio',
ADD COLUMN IF NOT EXISTS profit_margin_percent NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS legal_terms_accepted BOOLEAN DEFAULT false;

-- Adicionar campo para contrato na tabela de parcelas (opcional, ou no loan)
ALTER TABLE public.loans
ADD COLUMN IF NOT EXISTS contract_pdf_url TEXT;

-- Criar bucket para contratos se não existir
-- Nota: Isso geralmente é feito via RPC ou interface, mas garantimos a política
INSERT INTO storage.buckets (id, name, public) 
VALUES ('contracts', 'contracts', false)
ON CONFLICT (id) DO NOTHING;

-- Políticas de armazenamento para contratos
CREATE POLICY "Users can upload their own contracts" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'contracts' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own contracts" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'contracts' AND auth.uid()::text = (storage.foldername(name))[1]);
