DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.loans;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.installments;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END$$;
ALTER TABLE public.loans REPLICA IDENTITY FULL;
ALTER TABLE public.installments REPLICA IDENTITY FULL;