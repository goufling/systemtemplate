
CREATE TABLE public.limit_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_user_id UUID NOT NULL,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  store_id UUID REFERENCES public.stores(id) ON DELETE SET NULL,
  store_name TEXT,
  requested_amount NUMERIC(12,2) NOT NULL,
  purchase_amount NUMERIC(12,2),
  reason TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  responded_at TIMESTAMPTZ,
  response_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_limit_requests_owner ON public.limit_requests(owner_user_id, status);
CREATE INDEX idx_limit_requests_customer ON public.limit_requests(customer_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.limit_requests TO authenticated;
GRANT ALL ON public.limit_requests TO service_role;

ALTER TABLE public.limit_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners manage their limit requests"
ON public.limit_requests FOR ALL
USING (auth.uid() = owner_user_id)
WITH CHECK (auth.uid() = owner_user_id);

CREATE TRIGGER trg_limit_requests_updated
BEFORE UPDATE ON public.limit_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
