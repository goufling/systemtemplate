ALTER TABLE public.customers ADD COLUMN IF NOT EXISTS avatar_url text;

-- Permite que o cliente vinculado atualize seus próprios dados básicos
DROP POLICY IF EXISTS "Client can update own profile" ON public.customers;
CREATE POLICY "Client can update own profile"
ON public.customers
FOR UPDATE
TO authenticated
USING (client_user_id = auth.uid())
WITH CHECK (client_user_id = auth.uid());

-- E ler os próprios dados
DROP POLICY IF EXISTS "Client can read own profile" ON public.customers;
CREATE POLICY "Client can read own profile"
ON public.customers
FOR SELECT
TO authenticated
USING (client_user_id = auth.uid());