
-- access_requests table
CREATE TABLE public.access_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  full_name TEXT,
  user_id UUID,
  requested_role TEXT NOT NULL DEFAULT 'admin' CHECK (requested_role IN ('admin','client')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','denied')),
  notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.access_requests TO authenticated;
GRANT ALL ON public.access_requests TO service_role;

ALTER TABLE public.access_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins manage access requests"
  ON public.access_requests
  FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER access_requests_updated_at
  BEFORE UPDATE ON public.access_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Replace default role assignment with allowlist + access request creation
CREATE OR REPLACE FUNCTION public.assign_default_admin_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  user_email TEXT;
  approved_role TEXT;
BEGIN
  user_email := LOWER(COALESCE(NEW.email, ''));

  IF EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = NEW.id) THEN
    RETURN NEW;
  END IF;

  -- Internal synthetic emails (admin-created clients/lojas)
  IF user_email LIKE '%@clientes.verapay.app' OR user_email LIKE '%@lojas.verapay.app' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');
    RETURN NEW;
  END IF;

  -- Hardcoded admin allowlist
  IF user_email IN ('ramonsisilva@gmail.com', 'vera10290@gmail.com') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
    RETURN NEW;
  END IF;

  -- Pre-approved access request
  SELECT requested_role INTO approved_role
    FROM public.access_requests
    WHERE email = user_email AND status = 'approved'
    LIMIT 1;

  IF approved_role IS NOT NULL THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, approved_role::app_role);
    UPDATE public.access_requests SET user_id = NEW.id WHERE email = user_email;
    RETURN NEW;
  END IF;

  -- Otherwise: create/refresh pending access request, no role granted
  INSERT INTO public.access_requests (email, full_name, user_id, status, requested_role)
  VALUES (
    user_email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.id,
    'pending',
    'admin'
  )
  ON CONFLICT (email) DO UPDATE
    SET user_id = EXCLUDED.user_id,
        full_name = COALESCE(EXCLUDED.full_name, public.access_requests.full_name);

  RETURN NEW;
END;
$function$;
