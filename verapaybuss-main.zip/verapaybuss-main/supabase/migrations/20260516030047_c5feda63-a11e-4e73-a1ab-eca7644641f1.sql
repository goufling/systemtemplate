-- Fix security linter warnings by setting search_path and restricting execution
ALTER FUNCTION public.update_installment_status_after_payment() SET search_path = public;
REVOKE EXECUTE ON FUNCTION public.update_installment_status_after_payment() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.update_installment_status_after_payment() TO authenticated;
GRANT EXECUTE ON FUNCTION public.update_installment_status_after_payment() TO service_role;

-- Ensure indexes for performance on new table
CREATE INDEX IF NOT EXISTS idx_payment_records_installment_id ON public.payment_records(installment_id);
CREATE INDEX IF NOT EXISTS idx_payment_records_user_id ON public.payment_records(user_id);
