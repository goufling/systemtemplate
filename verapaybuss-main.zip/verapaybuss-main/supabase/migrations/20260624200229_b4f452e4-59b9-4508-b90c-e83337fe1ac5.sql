ALTER TABLE public.store_month_closings 
  ADD COLUMN IF NOT EXISTS payment_method TEXT,
  ADD COLUMN IF NOT EXISTS commission_amount NUMERIC(12,2);