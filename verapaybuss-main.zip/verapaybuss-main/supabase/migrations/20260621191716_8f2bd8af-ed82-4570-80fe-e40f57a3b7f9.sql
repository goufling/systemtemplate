ALTER TABLE public.limit_requests
ADD COLUMN IF NOT EXISTS approved_amount NUMERIC(12,2),
ADD COLUMN IF NOT EXISTS applied_delta NUMERIC(12,2) NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS consumed_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_limit_requests_temp_release
ON public.limit_requests(customer_id, store_id, status, consumed_at)
WHERE status = 'approved' AND consumed_at IS NULL;