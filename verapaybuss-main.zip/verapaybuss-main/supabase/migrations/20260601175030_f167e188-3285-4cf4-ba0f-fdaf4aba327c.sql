
CREATE TABLE public.month_closings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  closed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  notes TEXT,
  totals JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, year, month)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.month_closings TO authenticated;
GRANT ALL ON public.month_closings TO service_role;

ALTER TABLE public.month_closings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own month_closings"
ON public.month_closings
FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER trg_month_closings_updated_at
BEFORE UPDATE ON public.month_closings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
