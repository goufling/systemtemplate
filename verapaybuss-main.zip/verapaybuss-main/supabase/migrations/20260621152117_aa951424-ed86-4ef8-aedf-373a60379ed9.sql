
-- Per-customer monthly note closing
CREATE TABLE public.customer_month_closings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  closed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  closed_by_role TEXT NOT NULL DEFAULT 'admin' CHECK (closed_by_role IN ('admin','store','client')),
  closed_by_user_id UUID,
  total_amount NUMERIC(12,2) DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (customer_id, year, month)
);

CREATE INDEX idx_cmc_customer ON public.customer_month_closings(customer_id);
CREATE INDEX idx_cmc_user ON public.customer_month_closings(user_id);
CREATE INDEX idx_cmc_period ON public.customer_month_closings(year, month);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.customer_month_closings TO authenticated;
GRANT ALL ON public.customer_month_closings TO service_role;

ALTER TABLE public.customer_month_closings ENABLE ROW LEVEL SECURITY;

-- Admin (owner) full access
CREATE POLICY "Admin manages own customer closings"
  ON public.customer_month_closings FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Client (customer logged in) can view & insert closings for their own row
CREATE POLICY "Client views own closings"
  ON public.customer_month_closings FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.customers c
      WHERE c.id = customer_month_closings.customer_id
        AND c.client_user_id = auth.uid()
    )
  );

CREATE POLICY "Client closes own month"
  ON public.customer_month_closings FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.customers c
      WHERE c.id = customer_month_closings.customer_id
        AND c.client_user_id = auth.uid()
    )
  );

CREATE TRIGGER trg_cmc_updated_at
  BEFORE UPDATE ON public.customer_month_closings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
