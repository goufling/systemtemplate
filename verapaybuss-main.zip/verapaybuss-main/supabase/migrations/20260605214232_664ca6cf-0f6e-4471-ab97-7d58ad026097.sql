ALTER TABLE public.installments DROP CONSTRAINT IF EXISTS installments_payment_method_check;
ALTER TABLE public.installments ADD CONSTRAINT installments_payment_method_check 
CHECK (payment_method = ANY (ARRAY['pix'::text, 'cheque'::text, 'card'::text, 'cash'::text, 'multiple'::text, 'nota_promissoria'::text]));