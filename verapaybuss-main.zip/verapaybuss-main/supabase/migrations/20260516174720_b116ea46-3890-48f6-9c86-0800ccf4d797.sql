-- Create stores table
CREATE TABLE IF NOT EXISTS public.stores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id),
    name TEXT NOT NULL,
    category TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS for stores
ALTER TABLE public.stores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their own stores" ON public.stores FOR ALL USING (auth.uid() = user_id);

-- Add fields to customers
ALTER TABLE public.customers 
ADD COLUMN IF NOT EXISTS secondary_phone TEXT,
ADD COLUMN IF NOT EXISTS credit_limit NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active', -- active, blocked, inactive
ADD COLUMN IF NOT EXISTS is_favorite BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';

-- Create renegotiations table
CREATE TABLE IF NOT EXISTS public.renegotiations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id),
    installment_id UUID NOT NULL REFERENCES public.installments(id),
    original_amount NUMERIC NOT NULL,
    paid_amount NUMERIC NOT NULL,
    remaining_amount NUMERIC NOT NULL,
    new_installment_id UUID, -- Will be filled if a new one is created
    reason TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.renegotiations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their own renegotiations" ON public.renegotiations FOR ALL USING (auth.uid() = user_id);

-- Add fields to installments
ALTER TABLE public.installments
ADD COLUMN IF NOT EXISTS interest_amount NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS penalty_amount NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS discount_amount NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS receipt_url TEXT,
ADD COLUMN IF NOT EXISTS renegotiation_id UUID REFERENCES public.renegotiations(id);

-- Add proof_url to payment_records
ALTER TABLE public.payment_records
ADD COLUMN IF NOT EXISTS proof_url TEXT;

-- Create activity_logs table
CREATE TABLE IF NOT EXISTS public.activity_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id),
    action TEXT NOT NULL, -- 'INSERT', 'UPDATE', 'DELETE'
    table_name TEXT NOT NULL,
    record_id UUID NOT NULL,
    old_data JSONB,
    new_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own activity logs" ON public.activity_logs FOR SELECT USING (auth.uid() = user_id);

-- Function to handle timestamp updates
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for stores
CREATE TRIGGER update_stores_updated_at
    BEFORE UPDATE ON public.stores
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_updated_at();

-- Trigger for logging activities (basic example)
CREATE OR REPLACE FUNCTION public.log_activity()
RETURNS TRIGGER AS $$
DECLARE
    current_user_id UUID;
BEGIN
    current_user_id := auth.uid();
    IF current_user_id IS NULL THEN
        RETURN NEW;
    END IF;

    IF (TG_OP = 'DELETE') THEN
        INSERT INTO public.activity_logs (user_id, action, table_name, record_id, old_data)
        VALUES (current_user_id, TG_OP, TG_TABLE_NAME, OLD.id, to_jsonb(OLD));
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO public.activity_logs (user_id, action, table_name, record_id, old_data, new_data)
        VALUES (current_user_id, TG_OP, TG_TABLE_NAME, NEW.id, to_jsonb(OLD), to_jsonb(NEW));
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO public.activity_logs (user_id, action, table_name, record_id, new_data)
        VALUES (current_user_id, TG_OP, TG_TABLE_NAME, NEW.id, to_jsonb(NEW));
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply logging to core tables
CREATE TRIGGER log_customers_activity AFTER INSERT OR UPDATE OR DELETE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.log_activity();
CREATE TRIGGER log_loans_activity AFTER INSERT OR UPDATE OR DELETE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.log_activity();
CREATE TRIGGER log_installments_activity AFTER INSERT OR UPDATE OR DELETE ON public.installments FOR EACH ROW EXECUTE FUNCTION public.log_activity();
CREATE TRIGGER log_payment_records_activity AFTER INSERT OR UPDATE OR DELETE ON public.payment_records FOR EACH ROW EXECUTE FUNCTION public.log_activity();
