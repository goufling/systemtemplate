
-- 1) App roles enum + user_roles table
CREATE TYPE public.app_role AS ENUM ('admin', 'client');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can read their own roles"
  ON public.user_roles FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- 2) Customers: cpf + client_user_id link
ALTER TABLE public.customers
  ADD COLUMN cpf TEXT,
  ADD COLUMN client_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- CPF unique per admin (user_id owns the customer)
CREATE UNIQUE INDEX customers_user_cpf_unique
  ON public.customers (user_id, cpf)
  WHERE cpf IS NOT NULL;

CREATE UNIQUE INDEX customers_client_user_unique
  ON public.customers (client_user_id)
  WHERE client_user_id IS NOT NULL;

-- 3) Client-side read access policies
-- Customers: client can read own row
CREATE POLICY "Clients can view their own customer record"
  ON public.customers FOR SELECT TO authenticated
  USING (client_user_id = auth.uid());

-- Installments: client can read their own
CREATE POLICY "Clients can view their own installments"
  ON public.installments FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.customers c
    WHERE c.id = installments.customer_id
      AND c.client_user_id = auth.uid()
  ));

-- Loans: client can read their own
CREATE POLICY "Clients can view their own loans"
  ON public.loans FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.customers c
    WHERE c.id = loans.customer_id
      AND c.client_user_id = auth.uid()
  ));

-- Payment records: client can read payments for their own installments
CREATE POLICY "Clients can view their own payment records"
  ON public.payment_records FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.installments i
    JOIN public.customers c ON c.id = i.customer_id
    WHERE i.id = payment_records.installment_id
      AND c.client_user_id = auth.uid()
  ));

-- 4) Backfill: every existing auth user gets 'admin' role
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role FROM auth.users
ON CONFLICT (user_id, role) DO NOTHING;

-- 5) Auto-assign 'admin' role to new sign-ups (so the existing
--    handle_new_user flow keeps creating admins by default;
--    client accounts are created via admin server function and
--    get their 'client' role assigned explicitly there).
CREATE OR REPLACE FUNCTION public.assign_default_admin_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- only if this user has no role yet AND was not flagged as client
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = NEW.id) THEN
    IF COALESCE((NEW.raw_user_meta_data->>'account_type'), '') <> 'client' THEN
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
    ELSE
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created_assign_role
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.assign_default_admin_role();
