ALTER PUBLICATION supabase_realtime ADD TABLE public.limit_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.customers;
ALTER TABLE public.limit_requests REPLICA IDENTITY FULL;
ALTER TABLE public.customers REPLICA IDENTITY FULL;