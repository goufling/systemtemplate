-- Mudar o trigger: novos cadastros viram 'client' por padrão.
-- Ninguém vira admin automaticamente. Para promover alguém a admin,
-- insira manualmente em public.user_roles.
CREATE OR REPLACE FUNCTION public.assign_default_admin_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = NEW.id) THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'client');
  END IF;
  RETURN NEW;
END;
$function$;