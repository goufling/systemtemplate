-- Revoke execute on security definer functions from public and anon roles
REVOKE EXECUTE ON FUNCTION public.handle_updated_at() FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.log_activity() FROM PUBLIC, anon;

-- Grant execute to authenticated users (since the trigger runs under their session usually, 
-- but actually log_activity is security definer so it runs as the owner)
-- Better yet, keep it restricted to system roles if possible, but triggers need execute permission.
GRANT EXECUTE ON FUNCTION public.handle_updated_at() TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.log_activity() TO authenticated, service_role;
