
-- Add login credentials linkage to stores
ALTER TABLE public.stores
  ADD COLUMN IF NOT EXISTS username text,
  ADD COLUMN IF NOT EXISTS auth_user_id uuid;

CREATE UNIQUE INDEX IF NOT EXISTS stores_username_unique
  ON public.stores (lower(username))
  WHERE username IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS stores_auth_user_unique
  ON public.stores (auth_user_id)
  WHERE auth_user_id IS NOT NULL;

-- Allow a logged-in store user to SELECT its own store row
DROP POLICY IF EXISTS "Store user can view own store" ON public.stores;
CREATE POLICY "Store user can view own store"
  ON public.stores
  FOR SELECT
  TO authenticated
  USING (auth_user_id = auth.uid());
