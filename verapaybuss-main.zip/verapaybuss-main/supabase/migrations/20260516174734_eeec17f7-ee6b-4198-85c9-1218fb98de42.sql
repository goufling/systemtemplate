-- Fix security definer functions search_path
ALTER FUNCTION public.handle_updated_at() SET search_path = public;
ALTER FUNCTION public.log_activity() SET search_path = public;
