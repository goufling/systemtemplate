-- Create payment_records table for partial payments
CREATE TABLE IF NOT EXISTS public.payment_records (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    installment_id UUID NOT NULL REFERENCES public.installments(id) ON DELETE CASCADE,
    amount DECIMAL(12,2) NOT NULL,
    payment_method TEXT NOT NULL, -- 'pix', 'cash', 'card', 'cheque'
    paid_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    card_fee DECIMAL(12,2) DEFAULT 0,
    cheque_number TEXT,
    cheque_bank TEXT,
    cheque_date DATE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add bank details to installments for existing or single-payment logic (legacy/backup)
ALTER TABLE public.installments 
ADD COLUMN IF NOT EXISTS cheque_number TEXT,
ADD COLUMN IF NOT EXISTS cheque_bank TEXT;

-- Enable RLS for payment_records
ALTER TABLE public.payment_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own payment records" 
ON public.payment_records 
FOR ALL 
USING (auth.uid() = user_id);

-- Function to update installment status based on total payments
CREATE OR REPLACE FUNCTION public.update_installment_status_after_payment()
RETURNS TRIGGER AS $$
DECLARE
    total_paid DECIMAL(12,2);
    installment_amount DECIMAL(12,2);
BEGIN
    -- Get installment amount
    SELECT amount INTO installment_amount FROM public.installments WHERE id = NEW.installment_id;
    
    -- Sum all payments for this installment
    SELECT COALESCE(SUM(amount), 0) INTO total_paid FROM public.payment_records WHERE installment_id = NEW.installment_id;
    
    -- Update installment status
    IF total_paid >= installment_amount THEN
        UPDATE public.installments 
        SET status = 'paid', 
            paid_at = NEW.paid_at,
            payment_method = 'multiple' -- Indicate multiple if there was partial logic
        WHERE id = NEW.installment_id;
    ELSEIF total_paid > 0 THEN
        UPDATE public.installments 
        SET status = 'pending' -- Keep pending but we can show progress in UI
        WHERE id = NEW.installment_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for payment updates
DROP TRIGGER IF EXISTS tr_update_installment_status ON public.payment_records;
CREATE TRIGGER tr_update_installment_status
AFTER INSERT OR UPDATE ON public.payment_records
FOR EACH ROW
EXECUTE FUNCTION public.update_installment_status_after_payment();
