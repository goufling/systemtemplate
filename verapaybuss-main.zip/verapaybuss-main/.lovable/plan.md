
São quatro frentes — antes de partir para o código, quero confirmar o escopo de cada uma para não fazer mais ou menos do que você espera.

## 1. PDF de Relatórios (melhorias visuais + filtros)

**Hoje:** a aba Relatórios gera PDF com layout simples e só permite escolher "próximas parcelas", virando bagunça.

**Vou implementar:**
- Novo template do PDF na identidade visual do sistema (vinho `#7D2958`, rosa `#C84D8A`, fundo creme `#FAF6F7`) com cabeçalho, tabela zebrada, totais destacados e rodapé com data.
- Painel de filtros antes de gerar: **Cliente**, **Loja** (lista das lojas cadastradas), **Mês/Ano** (select), **Status** (pendente / pago / todos) e **Período personalizado** (data início/fim opcional).
- O PDF só inclui o que bate com os filtros — nada de "tudo misturado".
- Resumo no topo do PDF: total selecionado, qtd. de parcelas, valor em aberto, valor pago.

## 2. Aba "Histórico" do admin (não funciona)

**Diagnóstico inicial:** a query só dispara após `hasSearched=true`, então abre vazia. Há também tabs misturando histórico de pagamentos, atividade do sistema e auditoria.

**Vou implementar:**
- Carregar histórico automaticamente ao abrir (sem precisar clicar em "buscar").
- Filtros funcionais: cliente, loja, mês/ano, status.
- Tabela mostrando: data, cliente, loja, parcela X/Y, valor, status, ações.
- Botão "Exportar Excel" e "Exportar PDF" reaproveitando o template novo do item 1.
- Manter as outras abas (atividade/auditoria) intactas — só vou consertar a aba principal vazia.

## 3. Financeiro Pessoal — melhorias

Aqui preciso de orientação porque "melhoria rígida" pode significar várias coisas. Por padrão eu faria:

- Dashboard no topo com 4 cards: **saldo do mês**, **entradas**, **saídas**, **% gasto vs orçamento**.
- Gráfico de barras (entradas x saídas dos últimos 6 meses).
- Gráfico de pizza por categoria de despesa do mês.
- Filtro de mês fixo no topo (em vez de espalhado).
- Lista de transações com busca, ordenação e badge de categoria colorido.
- Alerta visual quando uma conta recorrente está próxima do vencimento.

Se você quiser algo diferente (ex.: meta de economia, divisão por contas bancárias, projeção do mês), me diga antes que eu mexa.

## 4. Não vou alterar agora

- Portal do cliente, portal da loja, fluxo de QR/limites (já funcionando).
- Estrutura do banco — exceto se descobrir algo quebrado no Histórico.

---

## Detalhes técnicos

- PDF: substituir `jspdf` puro por `jspdf-autotable` para tabelas estilizadas (já está instalado se não, adiciono).
- Filtros do PDF: estado local em React + função que filtra o array antes de passar pro gerador.
- Histórico: remover gate `hasSearched`, ajustar `useQuery` para SWR padrão.
- Financeiro Pessoal: usar `recharts` (já no projeto) para os gráficos; agregar dados no cliente (sem nova tabela).

---

## Antes de eu começar — duas dúvidas rápidas

1. **No Financeiro Pessoal** — a lista que sugeri acima está ok, ou você quer focar em algo específico (ex.: só os gráficos, ou só meta/orçamento)?
2. **No PDF de Relatórios** — quer manter a opção "próximas parcelas" como um filtro a mais, ou remover de vez?

Se preferir, pode só responder "manda ver tudo" que eu sigo com o padrão acima.
