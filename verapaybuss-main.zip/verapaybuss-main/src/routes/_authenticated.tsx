import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    if (typeof window === "undefined") return;

    let { data: { session } } = await supabase.auth.getSession();

    // OAuth callback race: hash/code is processed async by supabase-js.
    // If the URL still contains auth artifacts (or session is missing on first hit),
    // wait briefly for the SIGNED_IN / INITIAL_SESSION event before redirecting.
    if (!session?.user) {
      const hash = window.location.hash || "";
      const search = window.location.search || "";
      const looksLikeOAuth =
        hash.includes("access_token") ||
        hash.includes("refresh_token") ||
        /[?&]code=/.test(search);

      if (looksLikeOAuth) {
        session = await new Promise((resolve) => {
          const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
            if (s?.user) {
              clearTimeout(timer);
              sub.subscription.unsubscribe();
              resolve(s);
            }
          });
          const timer = setTimeout(() => {
            sub.subscription.unsubscribe();
            resolve(null);
          }, 4000);
        });
      }
    }

    if (!session?.user) {
      throw redirect({ to: "/login" as any });
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id);
    const isAdmin = (roles || []).some((row) => row.role === "admin");
    const isClient = (roles || []).some((row) => row.role === "client");

    if (isAdmin) return; // allowed
    if (isClient) throw redirect({ to: "/cliente" as any });
    throw redirect({ to: "/login" as any });
  },
  pendingComponent: () => (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Loader2 className="animate-spin text-primary" size={32} />
    </div>
  ),
  component: Outlet,
});
