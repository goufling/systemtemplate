import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Store, Lock, Loader2, LogIn } from "lucide-react";
import { storeUsernameToEmail } from "../serverFunctions";

export const Route = createFileRoute("/loja/login")({
  beforeLoad: async () => {
    if (typeof window !== "undefined") {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) throw redirect({ to: "/loja" as any });
    }
  },
  component: LojaLoginPage,
});

function LojaLoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const u = username.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (u.length < 3) return toast.error("Usuário inválido.");
    if (password.length < 6) return toast.error("Senha precisa ter no mínimo 6 caracteres.");
    setLoading(true);
    try {
      const email = storeUsernameToEmail(u);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast.success("Bem-vinda!");
      navigate({ to: "/loja" as any });
    } catch (err: any) {
      toast.error("Acesso negado", { description: err?.message || "Confira usuário e senha." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7] px-4">
      <Card className="w-full max-w-md border border-[#EAEAEA] shadow-xl rounded-3xl">
        <CardContent className="p-8 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 rounded-2xl bg-[#7D2958] flex items-center justify-center mx-auto">
              <Store className="text-white" size={28} />
            </div>
            <h1 className="text-2xl font-black text-[#2A2A2A] uppercase tracking-tighter">Acesso da Loja</h1>
            <p className="text-sm text-[#6B6B6B]">Entre com o usuário e senha da sua loja.</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Usuário</Label>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="nomedaloja"
                autoComplete="username"
                className="h-12 bg-[#FAF6F7] border-[#EAEAEA]"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Senha</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" size={16} />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  autoComplete="current-password"
                  className="h-12 pl-10 bg-[#FAF6F7] border-[#EAEAEA]"
                />
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full h-12 btn-primary text-base font-bold flex items-center justify-center gap-2">
              {loading ? <Loader2 className="animate-spin" size={18} /> : <LogIn size={18} />}
              Entrar
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
