import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, Target, Briefcase, BarChart3, CreditCard, Banknote, FileText } from "lucide-react";
import { listAllStoreClosings } from "@/lib/fechamento.functions";

export const Route = createFileRoute("/_authenticated/financeiro-profissional")({
  component: FinanceiroProfissional,
});

const MONTHS = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
const METHOD_LABEL: Record<string, string> = { cartao: "Cartão", pix: "PIX", cheque: "Cheque" };
const METHOD_ICON: Record<string, any> = { cartao: CreditCard, pix: Banknote, cheque: FileText };
const fmt = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function FinanceiroProfissional() {
  const list = useServerFn(listAllStoreClosings);
  const { data: closings = [], isLoading } = useQuery({
    queryKey: ["all-store-closings"],
    queryFn: () => list(),
  });

  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());

  const years = useMemo(() => {
    const ys = new Set<number>([now.getFullYear()]);
    (closings as any[]).forEach((c) => ys.add(c.year));
    return Array.from(ys).sort((a, b) => b - a);
  }, [closings, now]);

  const yearRows = useMemo(
    () => (closings as any[]).filter((c) => c.year === year),
    [closings, year]
  );

  // KPIs
  const totals = useMemo(() => {
    let received = 0;
    let commission = 0;
    let interest = 0;
    const byMethod: Record<string, number> = {};
    const byMonth: Record<number, { received: number; commission: number }> = {};
    for (const c of yearRows) {
      const v = Number(c.total_amount || 0);
      const com = Number(c.commission_amount || 0);
      const det = c.payment_details || {};
      received += v;
      commission += com;
      interest += Number(det.interestAmount || 0);
      const m = c.payment_method || "outro";
      byMethod[m] = (byMethod[m] || 0) + v;
      if (!byMonth[c.month]) byMonth[c.month] = { received: 0, commission: 0 };
      byMonth[c.month].received += v;
      byMonth[c.month].commission += com;
    }
    return { received, commission, interest, byMethod, byMonth, count: yearRows.length };
  }, [yearRows]);

  const monthlyArr = useMemo(() => {
    const arr = [];
    for (let i = 1; i <= 12; i++) {
      arr.push({ month: i, ...(totals.byMonth[i] || { received: 0, commission: 0 }) });
    }
    return arr;
  }, [totals]);

  const maxMonth = Math.max(...monthlyArr.map((m) => m.received), 1);
  const marginPct = totals.received > 0 ? (totals.commission / totals.received) * 100 : 0;

  return (
    <div className="space-y-8 p-6 lg:p-10 max-w-7xl mx-auto animate-in fade-in duration-500">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b pb-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-black tracking-tight">
            Financeiro <span className="gold-text">Profissional</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Visão consolidada das comissões e pagamentos por loja.
          </p>
        </div>
        <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
          <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
      </header>

      {/* KPIs */}
      <div className="grid gap-4 md:grid-cols-4">
        <KpiCard label="Faturamento Recebido" value={fmt(totals.received)} icon={TrendingUp} tone="emerald" />
        <KpiCard label="Comissões Pagas" value={fmt(totals.commission)} icon={Briefcase} tone="primary" />
        <KpiCard label="Margem" value={`${marginPct.toFixed(1)}%`} icon={Target} tone="purple" />
        <KpiCard label="Fechamentos" value={String(totals.count)} icon={BarChart3} tone="blue" />
      </div>

      {/* Métodos de pagamento */}
      <div className="grid gap-4 md:grid-cols-3">
        {(["cartao", "pix", "cheque"] as const).map((m) => {
          const Icon = METHOD_ICON[m];
          const val = totals.byMethod[m] || 0;
          const pct = totals.received > 0 ? (val / totals.received) * 100 : 0;
          return (
            <Card key={m}>
              <CardContent className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary"><Icon size={18} /></div>
                  <div className="flex-1">
                    <p className="text-xs font-bold uppercase text-muted-foreground tracking-wider">{METHOD_LABEL[m]}</p>
                    <p className="text-xl font-black">{fmt(val)}</p>
                  </div>
                  <Badge variant="outline">{pct.toFixed(0)}%</Badge>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Gráfico mensal */}
      <Card>
        <CardHeader>
          <CardTitle>Faturamento Mensal — {year}</CardTitle>
          <CardDescription>Recebido por mês (barras) e comissão (linha inferior).</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-56 flex items-end justify-between gap-2">
            {monthlyArr.map((m) => {
              const h = (m.received / maxMonth) * 100;
              return (
                <div key={m.month} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full relative group flex flex-col items-center">
                    {m.received > 0 && (
                      <span className="text-[9px] font-bold text-muted-foreground mb-1">
                        {(m.received / 1000).toFixed(1)}k
                      </span>
                    )}
                    <div className="w-full gold-gradient rounded-t-md transition-all hover:opacity-80"
                      style={{ height: `${Math.max(h, 2)}%`, minHeight: m.received > 0 ? 6 : 2 }}
                      title={`${fmt(m.received)} — comissão ${fmt(m.commission)}`} />
                  </div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase">
                    {MONTHS[m.month - 1]}
                  </span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Tabela detalhada */}
      <Card>
        <CardHeader>
          <CardTitle>Pagamentos por Loja</CardTitle>
          <CardDescription>Detalhamento de cada fechamento pago no ano.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground py-8 text-center">Carregando...</p>
          ) : yearRows.length === 0 ? (
            <p className="text-muted-foreground py-8 text-center">Nenhum fechamento neste ano ainda.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Período</TableHead>
                    <TableHead>Loja</TableHead>
                    <TableHead>Pagamento</TableHead>
                    <TableHead>Detalhes</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                    <TableHead className="text-right">Comissão</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {yearRows
                    .sort((a, b) => b.month - a.month || (a.store_name || "").localeCompare(b.store_name || ""))
                    .map((c: any) => {
                      const det = c.payment_details || {};
                      let detailStr = "—";
                      if (c.payment_method === "cartao") {
                        detailStr = `${det.installments || 1}x${det.interestAmount ? ` + juros ${fmt(det.interestAmount)}` : ""}`;
                      } else if (c.payment_method === "cheque") {
                        detailStr = `${det.checkCount || 1} cheque(s) ${det.checkTerms || ""}`;
                      } else if (c.payment_method === "pix") {
                        detailStr = "À vista";
                      }
                      return (
                        <TableRow key={c.id}>
                          <TableCell className="text-sm font-medium">{MONTHS[c.month - 1]}/{c.year}</TableCell>
                          <TableCell className="font-bold">{c.store_name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{METHOD_LABEL[c.payment_method] || "—"}</Badge>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{detailStr}</TableCell>
                          <TableCell className="text-right font-mono font-bold">{fmt(Number(c.total_amount || 0))}</TableCell>
                          <TableCell className="text-right font-mono text-primary font-bold">
                            {fmt(Number(c.commission_amount || 0))}
                            {det.commissionMode === "percent" && det.commissionPercent ? (
                              <span className="block text-[10px] text-muted-foreground">{det.commissionPercent}%</span>
                            ) : null}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function KpiCard({ label, value, icon: Icon, tone }: { label: string; value: string; icon: any; tone: string }) {
  const toneClasses: Record<string, string> = {
    emerald: "text-emerald-500 bg-emerald-500/10",
    primary: "text-primary bg-primary/10",
    purple: "text-purple-500 bg-purple-500/10",
    blue: "text-blue-500 bg-blue-500/10",
  };
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-3">
          <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">{label}</p>
          <div className={`p-1.5 rounded-lg ${toneClasses[tone]}`}><Icon size={14} /></div>
        </div>
        <p className="text-2xl font-black">{value}</p>
      </CardContent>
    </Card>
  );
}
