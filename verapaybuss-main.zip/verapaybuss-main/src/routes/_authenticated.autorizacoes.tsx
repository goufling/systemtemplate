import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, ShieldCheck, ShieldX, Mail, Clock, CheckCircle2, XCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/autorizacoes")({
  component: AutorizacoesPage,
});

type Req = {
  id: string;
  email: string;
  full_name: string | null;
  user_id: string | null;
  requested_role: "admin" | "client";
  status: "pending" | "approved" | "denied";
  created_at: string;
  reviewed_at: string | null;
};

function AutorizacoesPage() {
  const [requests, setRequests] = useState<Req[]>([]);
  const [loading, setLoading] = useState(true);
  const [actingId, setActingId] = useState<string | null>(null);
  const [filter, setFilter] = useState<"pending" | "all">("pending");

  const load = useCallback(async () => {
    setLoading(true);
    const query = supabase.from("access_requests").select("*").order("created_at", { ascending: false });
    const { data, error } = filter === "pending" ? await query.eq("status", "pending") : await query;
    if (error) toast.error("Erro ao carregar solicitações", { description: error.message });
    setRequests((data ?? []) as Req[]);
    setLoading(false);
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  const approve = async (r: Req, role: "admin" | "client") => {
    setActingId(r.id);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error: updErr } = await supabase
        .from("access_requests")
        .update({ status: "approved", requested_role: role, reviewed_at: new Date().toISOString(), reviewed_by: user?.id })
        .eq("id", r.id);
      if (updErr) throw updErr;

      if (r.user_id) {
        const { error: roleErr } = await supabase
          .from("user_roles")
          .upsert({ user_id: r.user_id, role }, { onConflict: "user_id,role" });
        if (roleErr) throw roleErr;
      }
      toast.success(`Acesso liberado como ${role === "admin" ? "Administrador" : "Cliente"}.`);
      load();
    } catch (e: any) {
      toast.error("Erro ao aprovar", { description: e.message });
    } finally {
      setActingId(null);
    }
  };

  const deny = async (r: Req) => {
    setActingId(r.id);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error } = await supabase
        .from("access_requests")
        .update({ status: "denied", reviewed_at: new Date().toISOString(), reviewed_by: user?.id })
        .eq("id", r.id);
      if (error) throw error;

      if (r.user_id) {
        await supabase.from("user_roles").delete().eq("user_id", r.user_id);
      }
      toast.success("Acesso bloqueado.");
      load();
    } catch (e: any) {
      toast.error("Erro ao bloquear", { description: e.message });
    } finally {
      setActingId(null);
    }
  };

  const pendingCount = requests.filter(r => r.status === "pending").length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-black text-foreground flex items-center gap-3">
            <ShieldCheck className="text-primary" size={32} />
            Autorizações de Acesso
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Aprove ou bloqueie tentativas de login no sistema administrativo.
          </p>
        </div>
        <Select value={filter} onValueChange={(v: any) => setFilter(v)}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pendentes ({pendingCount})</SelectItem>
            <SelectItem value="all">Todas</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="animate-spin text-primary" size={32} />
        </div>
      ) : requests.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <CheckCircle2 className="mx-auto text-green-500 mb-3" size={48} />
            <p className="font-bold text-lg">Nenhuma solicitação {filter === "pending" ? "pendente" : ""}.</p>
            <p className="text-sm text-muted-foreground mt-1">
              Todas as tentativas de acesso já foram revisadas.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {requests.map((r) => (
            <Card key={r.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                      <Mail size={20} />
                    </div>
                    <div>
                      <CardTitle className="text-base">{r.full_name || r.email}</CardTitle>
                      <p className="text-xs text-muted-foreground">{r.email}</p>
                    </div>
                  </div>
                  <StatusBadge status={r.status} />
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-xs text-muted-foreground flex items-center gap-1 mb-3">
                  <Clock size={12} />
                  Solicitado em {new Date(r.created_at).toLocaleString("pt-BR")}
                </p>
                {r.status === "pending" ? (
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      onClick={() => approve(r, "admin")}
                      disabled={actingId === r.id}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      <ShieldCheck size={16} className="mr-1" /> Aprovar como Admin
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => approve(r, "client")}
                      disabled={actingId === r.id}
                    >
                      Aprovar como Cliente
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deny(r)}
                      disabled={actingId === r.id}
                    >
                      <ShieldX size={16} className="mr-1" /> Bloquear
                    </Button>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    Revisado em {r.reviewed_at ? new Date(r.reviewed_at).toLocaleString("pt-BR") : "—"}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: Req["status"] }) {
  if (status === "pending") return <Badge variant="outline" className="border-amber-500 text-amber-600"><Clock size={12} className="mr-1" />Pendente</Badge>;
  if (status === "approved") return <Badge className="bg-green-600"><CheckCircle2 size={12} className="mr-1" />Aprovado</Badge>;
  return <Badge variant="destructive"><XCircle size={12} className="mr-1" />Bloqueado</Badge>;
}
