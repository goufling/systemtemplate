import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { getCustomerDetails } from "../serverFunctions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Loader2, 
  ArrowLeft, 
  Calendar, 
  ShoppingBag, 
  CreditCard, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Smartphone, 
  TrendingUp, 
  Wallet, 
  AlertCircle,
  FileText,
  Download,
  Image as ImageIcon,
  History,
  Info,
  MapPin
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { toast } from "sonner";
import { ReceivePaymentDialog } from "@/components/ReceivePaymentDialog";

export const Route = createFileRoute("/_authenticated/clientes_/$customerId")({
  component: ClientePerfil,
});

function ClientePerfil() {
  const { customerId } = Route.useParams();

  const { data: customer, isLoading, error } = useQuery({
    queryKey: ["customer", customerId],
    queryFn: () => getCustomerDetails({ data: { customerId } } as any),
    retry: false,
  });

  // Filtros (hooks devem ser declarados antes de qualquer return condicional)
  const [filterMonth, setFilterMonth] = useState<string>("all");
  const [filterStore, setFilterStore] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterParcela, setFilterParcela] = useState<string>("all");



  if (isLoading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="animate-spin text-primary" size={48} />
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div className="flex flex-col h-96 items-center justify-center gap-4">
        <AlertCircle className="text-rose-400" size={48} />
        <p className="text-rose-400 font-bold">{(error as any)?.message || "Cliente não encontrado"}</p>
        <Link to="/clientes" className="text-[#C84D8A] underline">Voltar para clientes</Link>
      </div>
    );
  }

  const allInstallments = (customer?.loans || []).flatMap((loan: any) => 
    (loan.installments || []).map((inst: any) => ({ ...inst, store_name: loan.store_name }))
  ).sort((a: any, b: any) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime());

  // Filtros


  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    allInstallments.forEach((i: any) => {
      const d = new Date(i.due_date);
      set.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
    });
    return Array.from(set).sort().reverse();
  }, [allInstallments]);

  const availableStores = useMemo(
    () => Array.from(new Set(allInstallments.map((i: any) => i.store_name).filter(Boolean))),
    [allInstallments]
  );

  const availableParcelas = useMemo(
    () => Array.from(new Set(allInstallments.map((i: any) => i.number))).sort((a: any, b: any) => a - b),
    [allInstallments]
  );

  const filteredInstallments = useMemo(() => {
    return allInstallments.filter((i: any) => {
      if (filterStore !== "all" && i.store_name !== filterStore) return false;
      if (filterStatus !== "all" && i.status !== filterStatus) return false;
      if (filterParcela !== "all" && String(i.number) !== filterParcela) return false;
      if (filterMonth !== "all") {
        const d = new Date(i.due_date);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        if (key !== filterMonth) return false;
      }
      return true;
    });
  }, [allInstallments, filterMonth, filterStore, filterStatus, filterParcela]);


  const totalBorrowed = (customer?.loans || []).reduce((acc: number, loan: any) => acc + Number(loan.total_amount), 0);
  const totalPaid = allInstallments.filter((i: any) => i.status === 'paid').reduce((acc: number, i: any) => acc + Number(i.amount), 0);

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const monthInstallments = allInstallments.filter((i: any) => {
    if (i.status === 'paid') return false;
    const d = new Date(i.due_date);
    return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
  });
  const monthTotal = monthInstallments.reduce((s: number, i: any) => s + Number(i.amount), 0);

  const generatePDF = (loan: any = null) => {
    try {
      const doc = new jsPDF();
      const customerName = (customer?.name || "Cliente").toUpperCase();

      // VeraPay palette
      const brandPrimary: [number, number, number] = [200, 77, 138];   // #C84D8A rosa
      const brandDeep: [number, number, number] = [125, 41, 88];       // #7D2958 vinho
      const brandSoft: [number, number, number] = [245, 235, 239];     // rosa claro
      const brandCream: [number, number, number] = [250, 246, 247];    // creme

      const fmtMoney = (v: number) =>
        new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(v) || 0);

      // Header banner
      doc.setFillColor(...brandDeep);
      doc.rect(14, 14, 182, 16, 'F');
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.setTextColor(255, 255, 255);
      const titleText = loan
        ? `EXTRATO DE COMPRA - ${customerName}`
        : `EXTRATO COMPLETO - ${customerName}`;
      doc.text(titleText, 105, 24, { align: "center" });

      // One row per purchase (loan)
      const sourceLoans: any[] = loan ? [loan] : (customer?.loans || []);

      // For "próxima parcela" info on header
      const allInst = sourceLoans.flatMap((l: any) =>
        (l.installments || []).map((i: any) => ({ ...i, store_name: l.store_name }))
      );
      const nextOpen = [...allInst]
        .filter((i: any) => i.status !== 'paid')
        .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];

      // Customer info table
      autoTable(doc, {
        startY: 34,
        theme: 'grid',
        styles: { font: 'helvetica', fontSize: 12, textColor: brandDeep, lineColor: brandPrimary, lineWidth: 0.2, cellPadding: 3 },
        columnStyles: {
          0: { fontStyle: 'bold', cellWidth: 50, fillColor: brandSoft, textColor: brandDeep },
          1: { halign: 'left', fillColor: [255, 255, 255] }
        },
        body: [
          ['CLIENTE', customerName],
          ['TELEFONE', customer?.phone || '--'],
          ['STATUS', customer?.status === 'active' ? 'ATIVO' : 'BLOQUEADO'],
          ['EMISSÃO', format(new Date(), "dd/MM/yyyy 'às' HH:mm")],
          ['PRÓXIMO VENCIMENTO', nextOpen ? format(new Date(nextOpen.due_date), "dd/MM/yyyy") : 'TUDO EM DIA'],
          ['PRÓXIMA PARCELA', nextOpen ? `${fmtMoney(nextOpen.amount)} - ${nextOpen.store_name || ''}` : '--'],
        ],
        margin: { left: 14, right: 14 },
      });

      // Explanatory note
      const noteY = (doc as any).lastAutoTable.finalY + 4;
      doc.setFillColor(...brandSoft);
      doc.rect(14, noteY, 182, 11, 'F');
      doc.setFont("helvetica", "italic");
      doc.setFontSize(10);
      doc.setTextColor(...brandDeep);
      doc.text(
        "Abaixo estão suas compras. A coluna PARCELA mostra em qual parcela você está (ex: 2/3).",
        105, noteY + 7, { align: "center" }
      );

      // Build body: one row per purchase
      const body: any[] = [];
      let openTotal = 0;

      const sortedLoans = [...sourceLoans].sort(
        (a, b) => new Date(b.loan_date).getTime() - new Date(a.loan_date).getTime()
      );

      sortedLoans.forEach((l: any) => {
        const insts = (l.installments || []);
        const totalCount = l.installments_count || insts.length || 0;
        const paidCount = insts.filter((i: any) => i.status === 'paid').length;
        const nextUnpaid = [...insts]
          .filter((i: any) => i.status !== 'paid')
          .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];

        const currentNumber = nextUnpaid ? nextUnpaid.number : totalCount;
        const parcelaLabel = nextUnpaid
          ? `${currentNumber}/${totalCount}`
          : `QUITADA (${totalCount}/${totalCount})`;

        const valorParcela = nextUnpaid ? Number(nextUnpaid.amount) : (insts[0] ? Number(insts[0].amount) : 0);
        const restanteValor = insts
          .filter((i: any) => i.status !== 'paid')
          .reduce((s: number, i: any) => s + Number(i.amount), 0);
        openTotal += restanteValor;

        const proxMes = nextUnpaid
          ? format(new Date(nextUnpaid.due_date), "MMM/yyyy", { locale: ptBR }).replace('.', '')
          : '';

        body.push([
          (l.store_name || '').toUpperCase(),
          fmtMoney(l.total_amount || 0),
          parcelaLabel,
          nextUnpaid
            ? `${fmtMoney(valorParcela)}\nprox pagamento ${proxMes}`
            : 'PAGA',
        ]);
      });

      body.push([
        { content: 'TOTAL EM ABERTO', colSpan: 3, styles: { fontStyle: 'bold', halign: 'right', fillColor: brandPrimary, textColor: [255, 255, 255] } },
        { content: fmtMoney(openTotal), styles: { fontStyle: 'bold', fillColor: brandPrimary, textColor: [255, 255, 255] } },
      ]);

      autoTable(doc, {
        startY: noteY + 15,
        theme: 'grid',
        styles: {
          font: 'helvetica',
          fontSize: 13,
          textColor: brandDeep,
          lineColor: brandPrimary,
          lineWidth: 0.15,
          halign: 'center',
          valign: 'middle',
          cellPadding: 4,
        },
        alternateRowStyles: { fillColor: brandCream },
        headStyles: { fillColor: brandDeep, textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center', lineColor: brandDeep, fontSize: 13 },
        head: [['LOJA', 'VALOR DA COMPRA', 'PARCELA ATUAL', 'PRÓXIMA A PAGAR']],
        columnStyles: {
          0: { halign: 'left', cellWidth: 50, fontStyle: 'bold' },
          1: { cellWidth: 40, fontStyle: 'bold' },
          2: { cellWidth: 40, fontStyle: 'bold' },
          3: { cellWidth: 'auto', fontStyle: 'bold' },
        },
        body,
        margin: { left: 14, right: 14 },
      });

      // Summary for consolidated view
      if (!loan) {
        const summaryY = (doc as any).lastAutoTable.finalY + 6;
        autoTable(doc, {
          startY: summaryY,
          theme: 'grid',
          styles: { font: 'helvetica', fontSize: 12, textColor: brandDeep, lineColor: brandPrimary, lineWidth: 0.2, cellPadding: 3 },
          columnStyles: {
            0: { fontStyle: 'bold', cellWidth: 60, fillColor: brandSoft },
            1: { halign: 'right', fillColor: [255, 255, 255], fontStyle: 'bold' },
          },
          body: [
            ['TOTAL CONTRATADO', fmtMoney(totalBorrowed)],
            ['TOTAL PAGO', fmtMoney(totalPaid)],
            ['SALDO DEVEDOR', fmtMoney(totalBorrowed - totalPaid)],
          ],
          margin: { left: 14, right: 14 },
        });
      }

      // Footer branded
      const pageHeight = doc.internal.pageSize.height;
      const pageCount = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFillColor(...brandSoft);
        doc.rect(14, pageHeight - 18, 182, 10, 'F');
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(...brandDeep);
        doc.text(
          `VeraPay  •  Gerado em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}  •  Página ${i} de ${pageCount}`,
          105, pageHeight - 12, { align: "center" }
        );
      }

      doc.save(`VeraPay_${(customer?.name || 'cliente').replace(/\s+/g, '_')}_${format(new Date(), "ddMMyyyy")}.pdf`);
      toast.success("PDF gerado com sucesso!");
    } catch (error) {
      console.error("PDF Error:", error);
      toast.error("Erro ao gerar o PDF");
    }
  };

  const loansByStore = (customer?.loans || []).reduce((acc: any, loan: any) => {
    if (!acc[loan.store_name]) {
      acc[loan.store_name] = {
        total_borrowed: 0,
        total_paid: 0,
        loans_count: 0,
        last_loan_date: loan.loan_date
      };
    }
    acc[loan.store_name].total_borrowed += Number(loan.total_amount);
    acc[loan.store_name].loans_count += 1;
    
    const loanPaid = (loan.installments || [])
      .filter((i: any) => i.status === 'paid')
      .reduce((s: number, i: any) => s + Number(i.amount), 0);
    
    acc[loan.store_name].total_paid += loanPaid;
    
    if (new Date(loan.loan_date) > new Date(acc[loan.store_name].last_loan_date)) {
      acc[loan.store_name].last_loan_date = loan.loan_date;
    }
    
    return acc;
  }, {});

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-6">
          <Link to="/clientes" className="p-3 rounded-2xl bg-[#FFFFFF] text-[#6B6B6B] hover:text-[#C84D8A] border border-[#EAEAEA] transition-all shadow-xl">
            <ArrowLeft size={24} />
          </Link>
          <div>
            <h1 className="text-4xl font-black text-[#2A2A2A] tracking-tight uppercase">{customer?.name}</h1>
            <div className="flex flex-col gap-2 mt-2">
               <div className="flex items-center gap-4">
                  <Badge className="bg-[#C84D8A]/10 text-[#C84D8A] border-none font-black uppercase text-[10px] tracking-widest px-3 py-1">
                    Score: {customer?.credit_score || 'N/A'}
                  </Badge>
                  <Badge className={`${customer?.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'} border-none font-black uppercase text-[10px] tracking-widest px-3 py-1`}>
                    {customer?.status === 'active' ? 'Perfil Ativo' : 'Perfil Bloqueado'}
                  </Badge>
               </div>
               <div className="flex items-center gap-4 text-[#6B6B6B] font-medium text-sm">
                  <span className="flex items-center gap-2"><Smartphone size={14}/> {customer?.phone || "Sem contato"}</span>
               </div>
               {customer?.cep && (
                 <p className="text-[#6B6B6B] text-xs flex items-center gap-2 font-medium">
                   <AlertCircle size={12} className="text-[#C84D8A]" />
                   {customer.address_street}, {customer.address_number}{customer.address_complement ? ` (${customer.address_complement})` : ''} - {customer.address_neighborhood}, {customer.address_city}/{customer.address_state}
                 </p>
               )}
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <Button 
            onClick={() => generatePDF()}
            className="bg-[#C84D8A] hover:bg-[#C84D8A]/80 text-[#7D2958] font-black rounded-2xl h-14 px-8 flex items-center gap-3 shadow-xl"
          >
            <FileText size={20} />
            GERAR EXTRATO
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full bg-blue-400/5 group-hover:scale-150 transition-transform duration-500" />
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <p className="text-[10px] font-black uppercase text-[#6B6B6B] tracking-[0.2em]">Volume de Nota Promissória</p>
              <div className="p-2 rounded-xl bg-blue-400/10 text-blue-400">
                <TrendingUp size={18} />
              </div>
            </div>
            <div className="mt-6">
              <p className="text-3xl font-black text-[#2A2A2A]">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalBorrowed)}
              </p>
              <p className="text-[10px] text-[#6B6B6B] mt-1 uppercase font-bold italic">Total histórico aprovado</p>
            </div>
          </div>
        </Card>

        <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full bg-emerald-400/5 group-hover:scale-150 transition-transform duration-500" />
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <p className="text-[10px] font-black uppercase text-[#6B6B6B] tracking-[0.2em]">Total Amortizado</p>
              <div className="p-2 rounded-xl bg-emerald-400/10 text-emerald-400">
                <Wallet size={18} />
              </div>
            </div>
            <div className="mt-6">
              <p className="text-3xl font-black text-emerald-400">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalPaid)}
              </p>
              <p className="text-[10px] text-[#6B6B6B] mt-1 uppercase font-bold italic">Pagamentos confirmados</p>
            </div>
          </div>
        </Card>

        <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full bg-rose-400/5 group-hover:scale-150 transition-transform duration-500" />
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <p className="text-[10px] font-black uppercase text-[#6B6B6B] tracking-[0.2em]">Saldo em Aberto</p>
              <div className="p-2 rounded-xl bg-rose-400/10 text-rose-400">
                <AlertCircle size={18} />
              </div>
            </div>
            <div className="mt-6">
              <p className="text-3xl font-black text-rose-400">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(totalBorrowed - totalPaid)}
              </p>
              <p className="text-[10px] text-[#6B6B6B] mt-1 uppercase font-bold italic">Pendência atualizada</p>
            </div>
          </div>
        </Card>

        <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] p-8 shadow-2xl relative overflow-hidden group">
          <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full bg-[#C84D8A]/10 group-hover:scale-150 transition-transform duration-500" />
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <p className="text-[10px] font-black uppercase text-[#6B6B6B] tracking-[0.2em]">A Pagar Este Mês</p>
              <div className="p-2 rounded-xl bg-[#C84D8A]/10 text-[#C84D8A]">
                <Calendar size={18} />
              </div>
            </div>
            <div className="mt-6">
              <p className="text-3xl font-black text-[#7D2958]">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(monthTotal)}
              </p>
              <p className="text-[10px] text-[#6B6B6B] mt-1 uppercase font-bold italic">
                {monthInstallments.length > 0
                  ? `${monthInstallments.length} parcela${monthInstallments.length > 1 ? 's' : ''} em ${now.toLocaleDateString('pt-BR', { month: 'long' })}`
                  : 'Nada a vencer este mês'}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="installments" className="space-y-6">
        <TabsList className="bg-[#FFFFFF] h-14 p-1 rounded-2xl border border-[#EAEAEA] overflow-x-auto overflow-y-hidden max-w-full justify-start md:justify-center">
          <TabsTrigger value="installments" className="rounded-xl px-8 font-black uppercase text-[10px] tracking-widest flex gap-2">
            <History size={14} /> Histórico de Parcelas
          </TabsTrigger>
          <TabsTrigger value="loans" className="rounded-xl px-8 font-black uppercase text-[10px] tracking-widest flex gap-2">
            <ShoppingBag size={14} /> Compras Realizadas
          </TabsTrigger>
          <TabsTrigger value="stores" className="rounded-xl px-8 font-black uppercase text-[10px] tracking-widest flex gap-2">
            <MapPin size={14} /> Relatório por Loja
          </TabsTrigger>
        </TabsList>

        <TabsContent value="installments" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h2 className="text-xl font-black text-[#2A2A2A] tracking-tight uppercase flex items-center gap-3">
              <div className="h-1.5 w-1.5 rounded-full bg-[#C84D8A]" />
              Linha do Tempo de Cobranças
            </h2>
          </div>

          {/* Filtros */}
          <Card className="border-none bg-[#FFFFFF] rounded-2xl border border-[#EAEAEA] p-4 shadow-md">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Mês</p>
                <Select value={filterMonth} onValueChange={setFilterMonth}>
                  <SelectTrigger className="h-10 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os meses</SelectItem>
                    {availableMonths.map((m) => {
                      const [y, mo] = m.split("-");
                      const label = new Date(Number(y), Number(mo) - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
                      return <SelectItem key={m} value={m}>{label}</SelectItem>;
                    })}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Loja</p>
                <Select value={filterStore} onValueChange={setFilterStore}>
                  <SelectTrigger className="h-10 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as lojas</SelectItem>
                    {availableStores.map((s: any) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Parcela</p>
                <Select value={filterParcela} onValueChange={setFilterParcela}>
                  <SelectTrigger className="h-10 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as parcelas</SelectItem>
                    {availableParcelas.map((n: any) => <SelectItem key={n} value={String(n)}>{n}ª parcela</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Status</p>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="h-10 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="paid">Liquidada</SelectItem>
                    <SelectItem value="pending">Pendente</SelectItem>
                    <SelectItem value="overdue">Atrasada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {(filterMonth !== "all" || filterStore !== "all" || filterStatus !== "all" || filterParcela !== "all") && (
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-[#EAEAEA]">
                <p className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest">
                  {filteredInstallments.length} resultado{filteredInstallments.length !== 1 ? "s" : ""}
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => { setFilterMonth("all"); setFilterStore("all"); setFilterStatus("all"); setFilterParcela("all"); }}
                  className="text-[10px] font-black uppercase tracking-widest text-[#C84D8A]"
                >
                  Limpar filtros
                </Button>
              </div>
            )}
          </Card>

          <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] overflow-hidden shadow-2xl">
            <Table>
              <TableHeader className="bg-[#F5EBEF]">
                <TableRow className="border-[#EAEAEA] hover:bg-transparent">
                  <TableHead className="font-bold py-5 pl-8 text-[#6B6B6B] uppercase text-[10px] tracking-widest">Vencimento</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Estabelecimento</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Parcela</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Valor Nominal</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Status</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest pr-8 text-right">Liquidação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredInstallments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-20 text-[#6B6B6B] italic">
                      Nenhum registro encontrado com os filtros aplicados.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInstallments.map((inst: any) => (

                    <TableRow key={inst.id} className="hover:bg-[#F5EBEF]/80 border-[#EAEAEA] transition-colors">
                      <TableCell className="py-5 pl-8 font-bold text-[#2A2A2A]">
                        {format(new Date(inst.due_date), "dd/MM/yyyy")}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-[#2A2A2A] font-medium">
                          <ShoppingBag size={14} className="text-[#C84D8A]" />
                          {inst.store_name}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-black border-[#EAEAEA] bg-[#F5EBEF] text-[#6B6B6B] text-[10px] uppercase">
                          {inst.number}ª Parc
                        </Badge>
                      </TableCell>
                      <TableCell className="font-black text-[#C84D8A] text-lg">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(inst.amount)}
                      </TableCell>
                      <TableCell>
                        {inst.status === 'paid' ? (
                          <Badge className="bg-emerald-500/10 text-emerald-400 border-none font-black uppercase text-[9px] tracking-widest px-3">
                            LIQUIDADA
                          </Badge>
                        ) : inst.status === 'overdue' ? (
                          <Badge className="bg-rose-500/10 text-rose-400 border-none font-black uppercase text-[9px] tracking-widest px-3">
                            ATRASADA
                          </Badge>
                        ) : (
                          <Badge className="bg-slate-500/10 text-[#6B6B6B] border-none font-black uppercase text-[9px] tracking-widest px-3">
                            PENDENTE
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="pr-8 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {inst.status === 'paid' ? (
                            <div className="flex flex-col items-end mr-4">
                              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-tighter">{inst.payment_method}</span>
                              <span className="text-[9px] font-bold text-[#6B6B6B] uppercase tracking-widest">{format(new Date(inst.paid_at), "dd/MM/yy HH:mm")}</span>
                            </div>
                          ) : (() => {
                            const paidSum = (inst.payment_records || []).reduce((s: number, r: any) => s + Number(r.amount || 0), 0);
                            const remaining = Math.max(0, Number(inst.amount) - paidSum);
                            return remaining > 0 ? (
                              <ReceivePaymentDialog
                                installment={inst}
                                remaining={remaining}
                                customerName={customer?.name}
                              />
                            ) : (
                              <span className="text-[#2A2A2A] text-[10px] font-black italic mr-4">AGUARDANDO</span>
                            );
                          })()}

                          {(() => {
                            const loan = customer?.loans?.find((l: any) => l.id === inst.loan_id);
                            return loan?.attachment_url && (
                              <Button 
                                variant="ghost" 
                                size="icon"
                                className="h-8 w-8 rounded-lg bg-blue-500/10 text-blue-400 hover:text-blue-300 hover:bg-blue-500/20"
                                onClick={() => window.open(loan.attachment_url, '_blank')}
                                title="Ver anexo"
                              >
                                <ImageIcon size={14} />
                              </Button>
                            );
                          })()}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="loans" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black text-[#2A2A2A] tracking-tight uppercase flex items-center gap-3">
              <div className="h-1.5 w-1.5 rounded-full bg-[#C84D8A]" />
              Contratos de Venda
            </h2>
          </div>
          <div className="grid gap-6">
            {customer?.loans?.length === 0 ? (
              <Card className="border-none bg-[#FFFFFF] rounded-[32px] p-12 text-center text-[#6B6B6B] italic">
                Nenhum contrato registrado para este cliente.
              </Card>
            ) : (
              customer?.loans?.map((loan: any) => (
                <Card key={loan.id} className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] overflow-hidden shadow-2xl group transition-all hover:bg-[#142352]">
                  <div className="p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 rounded-2xl bg-[#F5EBEF] flex items-center justify-center text-[#C84D8A] border border-[#EAEAEA]">
                        <ShoppingBag size={28} />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-[#2A2A2A] uppercase tracking-tight">{loan.store_name}</h3>
                        <p className="text-[#6B6B6B] text-[10px] font-bold uppercase tracking-widest mt-1">
                          Pedido: {loan.order_number || "#---"} • {format(new Date(loan.loan_date), "dd/MM/yyyy")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-[10px] font-black text-[#6B6B6B] uppercase tracking-widest">Valor do Contrato</p>
                        <p className="text-2xl font-black text-[#C84D8A]">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(loan.total_amount)}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-12 w-12 rounded-xl bg-[#F5EBEF] text-[#6B6B6B] hover:text-[#C84D8A] border border-[#EAEAEA]"
                          onClick={() => generatePDF(loan)}
                          title="Gerar PDF do contrato"
                        >
                          <FileText size={20} />
                        </Button>
                        {loan.attachment_url && (
                          <Button 
                            variant="ghost" 
                            size="icon"
                            className="h-12 w-12 rounded-xl bg-blue-500/10 text-blue-400 hover:text-blue-300 border border-blue-500/10"
                            onClick={() => window.open(loan.attachment_url, '_blank')}
                            title="Ver anexo da venda"
                          >
                            <ImageIcon size={20} />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                  {loan.notes && (
                    <div className="px-8 pb-6 border-t border-[#EAEAEA] pt-4">
                      <p className="text-xs text-[#6B6B6B] italic flex gap-2">
                        <Info size={14} className="text-[#C84D8A]" />
                        {loan.notes}
                      </p>
                    </div>
                  )}
                </Card>
              ))
            )}
          </div>
        </TabsContent>
        <TabsContent value="stores" className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-black text-[#2A2A2A] tracking-tight uppercase flex items-center gap-3">
              <div className="h-1.5 w-1.5 rounded-full bg-[#C84D8A]" />
              Resumo Consolidado por Loja
            </h2>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {Object.entries(loansByStore).length === 0 ? (
              <Card className="col-span-2 border-none bg-[#FFFFFF] rounded-[32px] p-12 text-center text-[#6B6B6B] italic">
                Nenhum dado por loja disponível.
              </Card>
            ) : (
              Object.entries(loansByStore).map(([storeName, stats]: [string, any]) => (
                <Card key={storeName} className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] overflow-hidden shadow-2xl p-8 space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#C84D8A]/10 flex items-center justify-center text-[#C84D8A]">
                      <ShoppingBag size={24} />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-[#2A2A2A] uppercase tracking-tight">{storeName}</h3>
                      <p className="text-[#6B6B6B] text-[10px] font-bold uppercase tracking-widest">
                        {stats.loans_count} {stats.loans_count === 1 ? 'Compra' : 'Compras'} • Última em {format(new Date(stats.last_loan_date), "dd/MM/yyyy")}
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-[#F5EBEF] p-4 rounded-2xl border border-[#EAEAEA]">
                      <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Total Comprado</p>
                      <p className="text-xl font-black text-[#2A2A2A]">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.total_borrowed)}
                      </p>
                    </div>
                    <div className="bg-[#F5EBEF] p-4 rounded-2xl border border-[#EAEAEA]">
                      <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest mb-1">Total Pago</p>
                      <p className="text-xl font-black text-emerald-400">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.total_paid)}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#EAEAEA] flex items-center justify-between">
                    <div>
                      <p className="text-[9px] font-black text-[#6B6B6B] uppercase tracking-widest">Saldo Devedor na Loja</p>
                      <p className="text-2xl font-black text-[#C84D8A]">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.total_borrowed - stats.total_paid)}
                      </p>
                    </div>
                    <div className="h-12 w-12 rounded-full border-4 border-[#C84D8A]/20 flex items-center justify-center relative">
                      <div 
                        className="absolute inset-0 border-4 border-[#C84D8A] rounded-full" 
                        style={{ 
                          clipPath: `inset(${100 - (stats.total_paid / stats.total_borrowed * 100)}% 0 0 0)` 
                        }} 
                      />
                      <span className="text-[10px] font-black text-[#C84D8A]">
                        {Math.round((stats.total_paid / stats.total_borrowed) * 100)}%
                      </span>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
