import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Lock, Unlock, CheckCircle2, ShoppingBag, ChevronDown, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { listStorePurchasesByMonth, closeStoreMonth, reopenStoreMonth } from "@/lib/fechamento.functions";

export const Route = createFileRoute("/_authenticated/fechamento")({
  component: FechamentoPage,
});

const MONTHS = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

const PAYMENT_METHODS = [
  { value: "cartao", label: "Cartão" },
  { value: "pix", label: "PIX" },
  { value: "cheque", label: "Cheque" },
];

const METHOD_LABEL: Record<string, string> = {
  cartao: "Cartão",
  pix: "PIX",
  cheque: "Cheque",
};

const fmt = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function FechamentoPage() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);

  const years = useMemo(() => {
    const ys = [];
    for (let y = now.getFullYear() + 1; y >= now.getFullYear() - 4; y--) ys.push(y);
    return ys;
  }, [now]);

  return (
    <div className="space-y-6 p-6 lg:p-10 max-w-7xl mx-auto">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Fechamento por Loja</h1>
          <p className="text-muted-foreground mt-1">
            Total cheio de compras do mês por loja — marque como paga ao quitar.
          </p>
        </div>
        <div className="flex gap-2 items-center">
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {MONTHS.map((m, i) => (
                <SelectItem key={i} value={String(i + 1)}>{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
            <SelectTrigger className="w-[110px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {years.map((y) => (
                <SelectItem key={y} value={String(y)}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <StorePurchasesClosingTab year={year} month={month} monthLabel={MONTHS[month - 1]} key={`${year}-${month}`} />
    </div>
  );
}

function StorePurchasesClosingTab({ year, month, monthLabel }: { year: number; month: number; monthLabel: string }) {
  const list = useServerFn(listStorePurchasesByMonth);
  const doClose = useServerFn(closeStoreMonth);
  const doReopen = useServerFn(reopenStoreMonth);
  const qc = useQueryClient();
  const queryKey = ["store-purchases-closing", year, month];
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [closeFor, setCloseFor] = useState<any | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>("pix");
  const [commission, setCommission] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [selectedStore, setSelectedStore] = useState<string>("");

  const { data: allRows = [], isLoading } = useQuery({
    queryKey,
    queryFn: () => list({ data: { year, month } }),
  });

  const storeOptions = useMemo(
    () => Array.from(new Set((allRows as any[]).map((r) => r.storeName))).sort(),
    [allRows]
  );

  const rows = selectedStore === "__all__"
    ? allRows
    : selectedStore
      ? (allRows as any[]).filter((r) => r.storeName === selectedStore)
      : [];

  // Card-specific fields
  const [cardInstallments, setCardInstallments] = useState<string>("1");
  const [cardInterest, setCardInterest] = useState<string>("");
  // Check-specific fields
  const [checkCount, setCheckCount] = useState<string>("1");
  const [checkTerms, setCheckTerms] = useState<string>("30");
  // Commission mode
  const [commissionMode, setCommissionMode] = useState<"manual" | "percent">("manual");
  const [commissionPercent, setCommissionPercent] = useState<string>("");

  const computedCommission = useMemo(() => {
    if (commissionMode === "percent") {
      const p = Number(commissionPercent.replace(",", ".")) || 0;
      return ((closeFor?.totalAmount || 0) * p) / 100;
    }
    return Number(commission.replace(",", ".")) || 0;
  }, [commissionMode, commission, commissionPercent, closeFor]);

  const resetDialog = () => {
    setCloseFor(null);
    setCommission("");
    setNotes("");
    setPaymentMethod("pix");
    setCardInstallments("1");
    setCardInterest("");
    setCheckCount("1");
    setCheckTerms("30");
    setCommissionMode("manual");
    setCommissionPercent("");
  };

  const closeMut = useMutation({
    mutationFn: () => {
      const details: any = { commissionMode };
      if (commissionMode === "percent") details.commissionPercent = Number(commissionPercent.replace(",", ".")) || 0;
      if (paymentMethod === "cartao") {
        details.installments = Number(cardInstallments) || 1;
        details.interestAmount = Number(cardInterest.replace(",", ".")) || 0;
      } else if (paymentMethod === "cheque") {
        details.checkCount = Number(checkCount) || 1;
        details.checkTerms = checkTerms;
      }
      return doClose({
        data: {
          storeName: closeFor.storeName,
          year,
          month,
          totalAmount: closeFor.totalAmount,
          purchasesCount: closeFor.purchases.length,
          paymentMethod,
          commissionAmount: computedCommission,
          paymentDetails: details,
          notes: notes || undefined,
        },
      });
    },
    onSuccess: () => {
      toast.success("Loja fechada no mês");
      qc.invalidateQueries({ queryKey });
      qc.invalidateQueries({ queryKey: ["all-store-closings"] });
      resetDialog();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const reopenMut = useMutation({
    mutationFn: (storeName: string) => doReopen({ data: { storeName, year, month } }),
    onSuccess: () => {
      toast.success("Loja reaberta");
      qc.invalidateQueries({ queryKey });
      qc.invalidateQueries({ queryKey: ["all-store-closings"] });
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Selecione a Loja — {monthLabel}/{year}</CardTitle>
          <CardDescription>
            Escolha a loja para ver o total comprado no mês e marcar como paga.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-muted-foreground">Carregando...</p>
          ) : storeOptions.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <ShoppingBag className="size-10 mx-auto mb-2" />
              Nenhuma compra registrada neste mês
            </div>
          ) : (
            <div className="flex flex-wrap gap-3 items-center">
              <Label className="text-sm">Loja:</Label>
              <Select value={selectedStore} onValueChange={setSelectedStore}>
                <SelectTrigger className="w-[260px]"><SelectValue placeholder="Selecione uma loja..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todas as lojas</SelectItem>
                  {storeOptions.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      {selectedStore && rows.length > 0 && (
      <Card>
        <CardHeader>
          <CardTitle>Compras — {selectedStore === "__all__" ? "Todas as lojas" : selectedStore}</CardTitle>
          <CardDescription>
            Total cheio das compras do mês. Clique na linha para ver o histórico.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {(
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Loja</TableHead>
                  <TableHead className="text-right">Total Comprado</TableHead>
                  <TableHead className="text-right">Qtd</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Pagamento</TableHead>
                  <TableHead className="text-right">Comissão</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((s: any) => {
                  const closed = !!s.closing;
                  const isOpen = !!expanded[s.storeName];
                  const closedTotal = closed ? Number(s.closing.total_amount || 0) : 0;
                  const mismatch = closed && Math.abs(closedTotal - s.totalAmount) > 0.01;
                  return (
                    <>
                      <TableRow
                        key={s.storeName}
                        className="cursor-pointer hover:bg-muted/30"
                        onClick={() => setExpanded((e) => ({ ...e, [s.storeName]: !e[s.storeName] }))}
                      >
                        <TableCell>
                          {isOpen ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                        </TableCell>
                        <TableCell className="font-bold">{s.storeName}</TableCell>
                        <TableCell className="text-right font-mono font-bold">{fmt(s.totalAmount)}</TableCell>
                        <TableCell className="text-right">{s.purchases.length}</TableCell>
                        <TableCell>
                          {closed ? (
                            <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                              <CheckCircle2 className="size-3 mr-1" /> Paga
                            </Badge>
                          ) : (
                            <Badge className="bg-amber-500/15 text-amber-600 border-amber-500/30">
                              <Unlock className="size-3 mr-1" /> Em aberto
                            </Badge>
                          )}
                          {mismatch && (
                            <Badge variant="outline" className="ml-2 text-rose-500 border-rose-500/40">
                              ⚠ {fmt(closedTotal)} fechado
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {closed && s.closing.payment_method
                            ? METHOD_LABEL[s.closing.payment_method] || s.closing.payment_method
                            : "—"}
                        </TableCell>
                        <TableCell className="text-right font-mono text-primary">
                          {closed && s.closing.commission_amount ? fmt(Number(s.closing.commission_amount)) : "—"}
                        </TableCell>
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          {closed ? (
                            <Button size="sm" variant="outline"
                              onClick={() => reopenMut.mutate(s.storeName)}
                              disabled={reopenMut.isPending}>
                              <Unlock className="size-3 mr-1" /> Reabrir
                            </Button>
                          ) : (
                            <Button size="sm" className="gold-gradient text-[#7D2958]"
                              onClick={() => {
                                resetDialog();
                                setCloseFor(s);
                              }}
                              disabled={s.purchases.length === 0}>
                              <Lock className="size-3 mr-1" /> Marcar como paga
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                      {isOpen && (
                        <TableRow key={s.storeName + "-detail"}>
                          <TableCell colSpan={8} className="bg-muted/20 p-4">
                            {s.purchases.length === 0 ? (
                              <p className="text-sm text-muted-foreground">Sem compras neste mês.</p>
                            ) : (
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Data</TableHead>
                                    <TableHead>Cliente</TableHead>
                                    <TableHead>Nº Pedido</TableHead>
                                    <TableHead>Nº Romaneio</TableHead>
                                    <TableHead>Obs</TableHead>
                                    <TableHead className="text-right">Valor</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {s.purchases.map((p: any) => (
                                    <TableRow key={p.id}>
                                      <TableCell className="text-xs">
                                        {new Date(p.loanDate).toLocaleDateString("pt-BR")}
                                      </TableCell>
                                      <TableCell>{p.customerName}</TableCell>
                                      <TableCell className="text-xs">{p.orderNumber || "—"}</TableCell>
                                      <TableCell className="text-xs">{p.deliveryNote || "—"}</TableCell>
                                      <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{p.notes || "—"}</TableCell>
                                      <TableCell className="text-right font-mono">{fmt(p.totalAmount)}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            )}
                          </TableCell>
                        </TableRow>
                      )}
                    </>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      )}



      <Dialog open={!!closeFor} onOpenChange={(o) => !o && resetDialog()}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Marcar {closeFor?.storeName} como paga</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Total: <strong className="text-foreground">{fmt(closeFor?.totalAmount || 0)}</strong> • {closeFor?.purchases.length} compras
            </div>

            <div className="space-y-2">
              <Label>Forma de pagamento</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {paymentMethod === "cartao" && (
              <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-muted/30 border">
                <div className="space-y-2">
                  <Label>Parcelas</Label>
                  <Input type="number" min="1" max="24" value={cardInstallments}
                    onChange={(e) => setCardInstallments(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Juros (R$) — opcional</Label>
                  <Input type="text" inputMode="decimal" placeholder="0,00"
                    value={cardInterest} onChange={(e) => setCardInterest(e.target.value)} />
                </div>
              </div>
            )}

            {paymentMethod === "cheque" && (
              <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-muted/30 border">
                <div className="space-y-2">
                  <Label>Qtd. de cheques</Label>
                  <Input type="number" min="1" max="12" value={checkCount}
                    onChange={(e) => setCheckCount(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Prazos (dias)</Label>
                  <Select value={checkTerms} onValueChange={setCheckTerms}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30</SelectItem>
                      <SelectItem value="30/60">30/60</SelectItem>
                      <SelectItem value="30/60/90">30/60/90</SelectItem>
                      <SelectItem value="30/60/90/120">30/60/90/120</SelectItem>
                      <SelectItem value="60">60</SelectItem>
                      <SelectItem value="90">90</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-2 p-3 rounded-lg bg-muted/30 border">
              <Label>Comissão</Label>
              <div className="flex gap-2">
                <Button type="button" size="sm" variant={commissionMode === "manual" ? "default" : "outline"}
                  onClick={() => setCommissionMode("manual")}>Manual (R$)</Button>
                <Button type="button" size="sm" variant={commissionMode === "percent" ? "default" : "outline"}
                  onClick={() => setCommissionMode("percent")}>Por %</Button>
              </div>
              {commissionMode === "manual" ? (
                <Input type="text" inputMode="decimal" placeholder="0,00"
                  value={commission} onChange={(e) => setCommission(e.target.value)} />
              ) : (
                <div className="flex items-center gap-2">
                  <Input type="text" inputMode="decimal" placeholder="Ex: 10"
                    value={commissionPercent} onChange={(e) => setCommissionPercent(e.target.value)} />
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
              )}
              <p className="text-xs text-muted-foreground">
                Comissão calculada: <strong className="text-primary">{fmt(computedCommission)}</strong>
              </p>
            </div>

            <div className="space-y-2">
              <Label>Observações (opcional)</Label>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)}
                placeholder="Detalhes do pagamento..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={resetDialog}>Cancelar</Button>
            <Button onClick={() => closeMut.mutate()} disabled={closeMut.isPending}>
              {closeMut.isPending ? "Salvando..." : "Confirmar pagamento"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
