import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCustomers, createCustomer, updateCustomer, deleteCustomer, setClientAccess, removeClientAccess } from "../serverFunctions";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, UserPlus, Loader2, Edit, Trash2, User, Phone, Users as UsersIcon, Star, ShieldAlert, CheckCircle, Smartphone, MapPin, KeyRound, Lock, Link2, Copy } from "lucide-react";
import { getMySignupToken } from "../serverFunctions";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { requireAdminPassword } from "@/lib/admin-password";
import { cleanCpf, formatCpf, isValidCpf } from "@/lib/cpf";

export const Route = createFileRoute("/_authenticated/clientes")({
  component: Clientes,
});

function Clientes() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<any>(null);
  const [formData, setFormData] = useState({ 
    name: "", 
    phone: "", 
    secondary_phone: "", 
    cpf: "",
    credit_limit: 0, 
    status: "active",
    cep: "",
    address_street: "",
    address_number: "",
    address_complement: "",
    address_neighborhood: "",
    address_city: "",
    address_state: ""
  });
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [clientPassword, setClientPassword] = useState("");

  const { data: customers, isLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => getCustomers(),
  });

  const emptyForm = { 
    name: "", 
    phone: "", 
    secondary_phone: "", 
    cpf: "",
    credit_limit: 0, 
    status: "active",
    cep: "",
    address_street: "",
    address_number: "",
    address_complement: "",
    address_neighborhood: "",
    address_city: "",
    address_state: ""
  };

  const createMutation = useMutation({
    mutationFn: (data: any) => createCustomer({ data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      setIsDialogOpen(false);
      setFormData(emptyForm);
      toast.success("Cliente criado com sucesso!");
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: any) => updateCustomer({ data }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      setIsDialogOpen(false);
      setEditingCustomer(null);
      setFormData(emptyForm);
      toast.success("Cliente atualizado!");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteCustomer({ data: { id } } as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      toast.success("Cliente removido!");
    },
  });

  const accessMutation = useMutation({
    mutationFn: (vars: { customerId: string; password: string }) =>
      setClientAccess({ data: vars } as any),
    onSuccess: (res: any) => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      toast.success(res?.reset ? "Senha do cliente atualizada!" : "Acesso do cliente criado!");
      setClientPassword("");
    },
    onError: (e: any) => toast.error(e?.message || "Erro ao salvar acesso"),
  });

  const removeAccessMutation = useMutation({
    mutationFn: (customerId: string) => removeClientAccess({ data: { customerId } } as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      toast.success("Acesso do cliente removido.");
    },
    onError: (e: any) => toast.error(e?.message || "Erro ao remover acesso"),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: any = { ...formData };
    if (payload.cpf) {
      const c = cleanCpf(payload.cpf);
      if (!isValidCpf(c)) {
        toast.error("CPF inválido. Verifique os números.");
        return;
      }
      payload.cpf = c;
    } else {
      payload.cpf = null;
    }
    if (editingCustomer) {
      updateMutation.mutate({ id: editingCustomer.id, ...payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleEdit = (customer: any) => {
    if (!requireAdminPassword("editar este cliente")) return;
    setEditingCustomer(customer);
    setClientPassword("");
    setFormData({ 
      name: customer.name, 
      phone: customer.phone || "", 
      secondary_phone: customer.secondary_phone || "",
      cpf: customer.cpf ? formatCpf(customer.cpf) : "",
      credit_limit: customer.credit_limit || 0,
      status: customer.status || "active",
      cep: customer.cep || "",
      address_street: customer.address_street || "",
      address_number: customer.address_number || "",
      address_complement: customer.address_complement || "",
      address_neighborhood: customer.address_neighborhood || "",
      address_city: customer.address_city || "",
      address_state: customer.address_state || ""
    });
    setIsDialogOpen(true);
  };

  const handleCepSearch = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      setIsSearchingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
        const data = await response.json();
        if (!data.erro) {
          setFormData(prev => ({
            ...prev,
            cep: cleanCep,
            address_street: data.logradouro,
            address_neighborhood: data.bairro,
            address_city: data.localidade,
            address_state: data.uf
          }));
          toast.success("Endereço preenchido!");
        } else {
          toast.error("CEP não encontrado.");
        }
      } catch (error) {
        toast.error("Erro ao buscar CEP.");
      } finally {
        setIsSearchingCep(false);
      }
    }
  };

  const filteredCustomers = customers?.filter((c: any) => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.phone?.includes(search)
  );

  if (isLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="animate-spin text-primary" size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight text-[#2A2A2A]">Meus <span className="gold-text">Clientes</span></h1>
          <p className="text-sm md:text-base text-[#6B6B6B] font-medium mt-1">Gerencie sua base de clientes.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <Button
            variant="outline"
            onClick={async () => {
              try {
                const { token } = await getMySignupToken();
                const url = `${window.location.origin}/cadastro-cliente/${token}`;
                await navigator.clipboard.writeText(url);
                toast.success("Link copiado!", { description: url });
              } catch {
                toast.error("Erro ao gerar link");
              }
            }}
            className="flex gap-2 h-12"
          >
            <Link2 size={18} />
            Link de auto-cadastro
          </Button>
          <Button onClick={() => {
            setEditingCustomer(null);
            setFormData(emptyForm);
            setClientPassword("");
            setIsDialogOpen(true);
          }} className="btn-primary flex gap-2 justify-center h-12">
            <UserPlus size={20} />
            Novo Cliente
          </Button>
        </div>
      </header>

      <div className="flex items-center gap-4 luxury-card !p-2">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
          <Input 
            className="pl-12 h-12 bg-transparent border-none focus-visible:ring-0 text-base text-[#2A2A2A]" 
            placeholder="Buscar por nome ou telefone..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Mobile: card list */}
      <div className="grid gap-3 md:hidden">
        {filteredCustomers?.length === 0 ? (
          <div className="text-center py-12 luxury-card">
            <div className="h-14 w-14 bg-[#F5EBEF] rounded-full flex items-center justify-center mx-auto text-[#C84D8A] mb-2">
              <UsersIcon size={28} />
            </div>
            <p className="text-[#6B6B6B] font-medium italic">Nenhum cliente encontrado.</p>
          </div>
        ) : (
          filteredCustomers?.map((customer: any) => (
            <div
              key={customer.id}
              onClick={() => navigate({ to: "/clientes/$customerId", params: { customerId: customer.id } } as any)}
              className="bg-white rounded-2xl border border-[#EAEAEA] p-4 shadow-sm active:scale-[0.99] transition-transform"
            >
              <div className="flex items-start gap-3">
                <div className="h-12 w-12 shrink-0 rounded-2xl bg-[#C84D8A]/10 flex items-center justify-center text-[#C84D8A] font-bold text-lg">
                  {customer.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-[#2A2A2A] truncate">{customer.name}</h3>
                    {customer.is_favorite && <Star size={14} className="text-yellow-500 shrink-0" fill="currentColor" />}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-[#6B6B6B] mt-0.5">
                    <Phone size={12} /> {customer.phone || "-"}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap mt-2">
                    <Badge className="bg-[#C84D8A]/10 text-[#C84D8A] border-none text-[10px] font-bold px-2 py-0.5">
                      {customer.activeLoans} ativ{customer.activeLoans === 1 ? "o" : "os"}
                    </Badge>
                    {customer.status === 'blocked' && (
                      <Badge className="bg-rose-500/10 text-rose-500 border-none text-[10px] font-bold px-2 py-0.5">
                        Bloqueado
                      </Badge>
                    )}
                    <span className="text-xs font-black text-[#C84D8A] ml-auto">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(customer.totalBorrowed)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-3 pt-3 border-t border-[#EAEAEA]">
                <Button asChild variant="outline" size="sm" className="flex-1 min-w-0 h-10 px-2 rounded-xl text-[#C84D8A] border-[#C84D8A]/20 text-xs whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                  <Link to="/clientes/$customerId" params={{ customerId: customer.id }} className="flex items-center justify-center gap-1">
                    <User size={14} className="shrink-0" /> <span className="truncate">Ver</span>
                  </Link>
                </Button>
                <Button
                  variant="outline" size="sm" className="flex-1 min-w-0 h-10 px-2 rounded-xl text-blue-500 border-blue-200 text-xs whitespace-nowrap"
                  onClick={(e) => { e.stopPropagation(); handleEdit(customer); }}
                >
                  <Edit size={14} className="mr-1 shrink-0" /> <span className="truncate">Editar</span>
                </Button>
                <Button
                  variant="outline" size="sm" className="h-10 w-10 shrink-0 rounded-xl text-destructive border-destructive/30 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!requireAdminPassword("excluir este cliente")) return;
                    if (confirm("Excluir cliente?")) deleteMutation.mutate(customer.id);
                  }}
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Desktop: table */}
      <Card className="hidden md:block border-none luxury-card !p-0 overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/30">
            <TableRow className="hover:bg-transparent border-none">
              <TableHead className="py-5 pl-8 font-bold text-[#6B6B6B]">Cliente</TableHead>
              <TableHead className="font-bold text-[#6B6B6B]">Contato</TableHead>
              <TableHead className="font-bold text-[#6B6B6B]">Status</TableHead>
              <TableHead className="font-bold text-[#6B6B6B]">Limite / Utilizado</TableHead>
              <TableHead className="text-right pr-8 font-bold text-[#6B6B6B]">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence mode="popLayout">
              {filteredCustomers?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-20">
                    <div className="space-y-3">
                      <div className="h-16 w-16 bg-muted/50 rounded-full flex items-center justify-center mx-auto text-muted-foreground">
                        <UsersIcon size={32} />
                      </div>
                      <p className="text-muted-foreground font-medium italic">Nenhum cliente encontrado.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredCustomers?.map((customer: any) => (
                  <motion.tr 
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    key={customer.id} 
                    className="group hover:bg-muted/30 transition-colors border-b last:border-none cursor-pointer"
                  >
                    <TableCell className="py-5 pl-8" onClick={() => navigate({ to: "/clientes/$customerId", params: { customerId: customer.id } } as any)}>
                      <div className="flex items-center gap-4">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            updateMutation.mutate({ id: customer.id, is_favorite: !customer.is_favorite });
                          }}
                          className={`transition-colors ${customer.is_favorite ? "text-yellow-500" : "text-[#2A2A2A] hover:text-yellow-500"}`}
                        >
                          <Star size={18} fill={customer.is_favorite ? "currentColor" : "none"} />
                        </button>
                        <div className="h-12 w-12 rounded-2xl bg-[#C84D8A]/10 flex items-center justify-center text-[#C84D8A] font-bold text-lg group-hover:scale-110 transition-transform border border-[#C84D8A]/10">
                          {customer.name.charAt(0)}
                        </div>
                        <div className="flex flex-col">
                          <span className="font-bold text-lg text-[#2A2A2A]">{customer.name}</span>
                          {customer.status === 'blocked' && (
                            <span className="text-[10px] text-rose-400 font-bold uppercase flex items-center gap-1"><ShieldAlert size={10}/> Bloqueado</span>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-muted-foreground font-medium">
                        <Phone size={14} />
                        {customer.phone || "-"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${customer.activeLoans > 0 ? "bg-[#C84D8A]/10 text-[#C84D8A]" : "bg-[#F5EBEF] text-[#6B6B6B]"} border-none px-3 py-1 font-bold`}>
                        {customer.activeLoans} Empréstimos Ativos
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="font-black text-[#C84D8A] text-lg">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(customer.totalBorrowed)}
                        </span>
                        {customer.credit_limit > 0 && (
                          <span className="text-[10px] text-[#6B6B6B] font-bold uppercase">
                            de {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(customer.credit_limit)}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right pr-8">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" asChild className="h-10 w-10 rounded-xl text-[#C84D8A] hover:bg-[#C84D8A]/10">
                          <Link to="/clientes/$customerId" params={{ customerId: customer.id }}>
                            <User size={18} />
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(customer)} className="h-10 w-10 rounded-xl text-blue-400 hover:bg-blue-400/10">
                          <Edit size={18} />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={(e) => {
                          e.stopPropagation();
                          if (!requireAdminPassword("excluir este cliente")) return;
                          if (confirm("Tem certeza que deseja excluir este cliente?")) {
                            deleteMutation.mutate(customer.id);
                          }
                        }} className="h-10 w-10 rounded-xl text-destructive hover:bg-destructive/10">
                          <Trash2 size={18} />
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                ))
              )}
            </AnimatePresence>
          </TableBody>
        </Table>
      </Card>


      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px] max-h-[90vh] overflow-y-auto bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              {editingCustomer ? "Editar Cliente" : "Novo Cliente"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-bold uppercase text-[#6B6B6B]">Nome Completo</Label>
                <Input 
                  id="name" 
                  placeholder="Ex: João Silva" 
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-sm font-bold uppercase text-[#6B6B6B]">Telefone Principal</Label>
                <Input 
                  id="phone" 
                  placeholder="(00) 00000-0000" 
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cpf" className="text-sm font-bold uppercase text-[#6B6B6B]">CPF</Label>
                <Input
                  id="cpf"
                  placeholder="000.000.000-00"
                  value={formData.cpf}
                  onChange={(e) => setFormData({ ...formData, cpf: formatCpf(e.target.value) })}
                  maxLength={14}
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                />
                <p className="text-xs text-[#6B6B6B]">Necessário para criar acesso do cliente.</p>
              </div>
              <div className="space-y-2">
                <Label className="text-sm font-bold uppercase text-[#6B6B6B] flex items-center gap-1">
                  <KeyRound size={12} /> Acesso do Cliente
                </Label>
                {editingCustomer?.client_user_id ? (
                  <div className="flex items-center gap-2">
                    <Badge className="bg-emerald-500/10 text-emerald-600 border border-emerald-500/30">
                      <CheckCircle size={12} className="mr-1" /> Acesso ativo
                    </Badge>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-9 text-xs"
                      onClick={() => {
                        if (confirm("Remover acesso do cliente? Ele não conseguirá mais entrar.")) {
                          removeAccessMutation.mutate(editingCustomer.id);
                        }
                      }}
                    >
                      Remover
                    </Button>
                  </div>
                ) : (
                  <p className="text-xs text-[#6B6B6B] pt-3">
                    Salve o cliente e use o campo abaixo para criar uma senha.
                  </p>
                )}
              </div>
            </div>

            {editingCustomer && (
              <div className="luxury-card !p-4 border border-[#EAEAEA] space-y-3 bg-[#FAF6F7]">
                <div className="flex items-center gap-2 text-[#C84D8A]">
                  <Lock size={16} />
                  <span className="font-bold uppercase text-xs tracking-wider">
                    {editingCustomer.client_user_id ? "Redefinir Senha do Cliente" : "Criar Senha de Acesso"}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Mínimo 6 caracteres"
                    value={clientPassword}
                    onChange={(e) => setClientPassword(e.target.value)}
                    className="h-11 bg-white border-[#EAEAEA] text-[#2A2A2A]"
                  />
                  <Button
                    type="button"
                    className="h-11 btn-primary whitespace-nowrap"
                    disabled={accessMutation.isPending || clientPassword.length < 6}
                    onClick={() => {
                      if (!editingCustomer.cpf && !cleanCpf(formData.cpf)) {
                        toast.error("Cadastre o CPF antes de criar o acesso.");
                        return;
                      }
                      accessMutation.mutate({
                        customerId: editingCustomer.id,
                        password: clientPassword,
                      });
                    }}
                  >
                    {accessMutation.isPending ? <Loader2 className="animate-spin" size={16} /> : (editingCustomer.client_user_id ? "Atualizar" : "Criar Acesso")}
                  </Button>
                </div>
                <p className="text-[11px] text-[#6B6B6B]">
                  O cliente entrará em <strong>/cliente/login</strong> com o CPF e esta senha.
                </p>
              </div>
            )}


            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="secondary_phone" className="text-sm font-bold uppercase text-[#6B6B6B]">Telefone Secundário</Label>
                <Input 
                  id="secondary_phone" 
                  placeholder="(00) 00000-0000" 
                  value={formData.secondary_phone}
                  onChange={(e) => setFormData({ ...formData, secondary_phone: e.target.value })}
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="credit_limit" className="text-sm font-bold uppercase text-[#6B6B6B]">Limite de Crédito</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B] text-sm">R$</span>
                  <Input 
                    id="credit_limit" 
                    type="number"
                    placeholder="0,00" 
                    value={formData.credit_limit}
                    onChange={(e) => setFormData({ ...formData, credit_limit: Number(e.target.value) })}
                    className="h-12 pl-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                  />
                </div>
              </div>
            </div>

            <div className="luxury-card !p-4 border border-[#EAEAEA] space-y-4">
              <div className="flex items-center gap-2 text-[#C84D8A] mb-2">
                <MapPin size={18} />
                <span className="font-bold uppercase text-xs tracking-wider">Endereço</span>
              </div>
              
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="cep" className="text-[10px] font-bold uppercase text-[#6B6B6B]">CEP</Label>
                  <div className="relative">
                    <Input 
                      id="cep" 
                      placeholder="00000-000" 
                      value={formData.cep}
                      onChange={(e) => {
                        const val = e.target.value;
                        setFormData({ ...formData, cep: val });
                        if (val.replace(/\D/g, '').length === 8) handleCepSearch(val);
                      }}
                      className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-sm"
                    />
                    {isSearchingCep && <Loader2 className="absolute right-2 top-1/2 -translate-y-1/2 animate-spin text-primary" size={14} />}
                  </div>
                </div>
                <div className="col-span-2 space-y-1">
                  <Label htmlFor="street" className="text-[10px] font-bold uppercase text-[#6B6B6B]">Rua/Logradouro</Label>
                  <Input 
                    id="street" 
                    value={formData.address_street}
                    onChange={(e) => setFormData({ ...formData, address_street: e.target.value })}
                    className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="number" className="text-[10px] font-bold uppercase text-[#6B6B6B]">Número</Label>
                  <Input 
                    id="number" 
                    value={formData.address_number}
                    onChange={(e) => setFormData({ ...formData, address_number: e.target.value })}
                    className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-sm"
                  />
                </div>
                <div className="col-span-3 space-y-1">
                  <Label htmlFor="complement" className="text-[10px] font-bold uppercase text-[#6B6B6B]">Complemento</Label>
                  <Input 
                    id="complement" 
                    placeholder="Apto, Bloco..." 
                    value={formData.address_complement}
                    onChange={(e) => setFormData({ ...formData, address_complement: e.target.value })}
                    className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label htmlFor="neighborhood" className="text-[10px] font-bold uppercase text-[#6B6B6B]">Bairro</Label>
                  <Input 
                    id="neighborhood" 
                    value={formData.address_neighborhood}
                    onChange={(e) => setFormData({ ...formData, address_neighborhood: e.target.value })}
                    className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="city" className="text-[10px] font-bold uppercase text-[#6B6B6B]">Cidade/UF</Label>
                  <Input 
                    id="city" 
                    value={`${formData.address_city}${formData.address_state ? ` - ${formData.address_state}` : ''}`}
                    readOnly
                    className="h-10 bg-[#F5EBEF] border-[#EAEAEA] text-[#6B6B6B] text-sm cursor-not-allowed"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-bold uppercase text-[#6B6B6B]">Status do Cliente</Label>
              <div className="flex gap-2">
                <Button 
                  type="button"
                  variant="outline" 
                  className={`flex-1 h-12 gap-2 border-[#EAEAEA] ${formData.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-[#F5EBEF] text-[#6B6B6B]'}`}
                  onClick={() => setFormData({ ...formData, status: 'active' })}
                >
                  <CheckCircle size={16} /> Ativo
                </Button>
                <Button 
                  type="button"
                  variant="outline" 
                  className={`flex-1 h-12 gap-2 border-[#EAEAEA] ${formData.status === 'blocked' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' : 'bg-[#F5EBEF] text-[#6B6B6B]'}`}
                  onClick={() => setFormData({ ...formData, status: 'blocked' })}
                >
                  <ShieldAlert size={16} /> Bloqueado
                </Button>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" className="w-full h-12 text-lg font-bold btn-primary" disabled={createMutation.isPending || updateMutation.isPending}>
                {createMutation.isPending || updateMutation.isPending ? <Loader2 className="animate-spin mr-2" /> : null}
                {editingCustomer ? "Salvar Alterações" : "Cadastrar Cliente"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
