import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getPagamentosData, createPaymentRecord, updatePaymentRecord, deletePaymentRecord } from "../serverFunctions";
import { supabase } from "@/integrations/supabase/client";
import { PaymentMethod } from "@/types/finance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Receipt, 
  Loader2, 
  CreditCard, 
  Landmark, 
  Zap, 
  Banknote, 
  Plus, 
  History, 
  QrCode, 
  Search, 
  MessageSquare, 
  TrendingUp, 
  AlertCircle,
  Smartphone,
  Store,
  User,
  ChevronDown,
  ChevronUp,
  FileText,
  Image as ImageIcon,
  PlusCircle,
  Pencil,
  Trash2
} from "lucide-react";

import { Switch } from "@/components/ui/switch";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { jsPDF } from "jspdf";
import { brand, drawVeraPayFooter, fmtMoneyBR } from "@/lib/pdfBranding";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { requireAdminPassword } from "@/lib/admin-password";

export const Route = createFileRoute("/_authenticated/parcelas")({
  component: Pagamentos,
});

function Pagamentos() {
  const queryClient = useQueryClient();
  const formatDateOnly = (date: string, pattern = "dd/MM/yyyy") => {
    const [year, month, day] = date.split("-").map(Number);
    return format(new Date(year, month - 1, day), pattern, { locale: ptBR });
  };
  const [selectedInst, setSelectedInst] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [amount, setAmount] = useState<number>(0);
  const [cardFee, setCardFee] = useState<number>(0);
  const [chequeNumber, setChequeNumber] = useState("");
  const [chequeBank, setChequeBank] = useState("");
  const [chequeDate, setChequeDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [createNextInstallment, setCreateNextInstallment] = useState(true);
  const [nextDueDate, setNextDueDate] = useState<string>(new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [showHistory, setShowHistory] = useState<string | null>(null);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [paidAt, setPaidAt] = useState<string>(new Date().toISOString().split('T')[0]);
  const [proofUrl, setProofUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [search, setSearch] = useState("");
  const [storeFilter, setStoreFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "paid" | "overdue">("all");
  const [monthFilter, setMonthFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState<"all" | "next">("all");

  const getMonthValue = (iso?: string | null) => {
    if (!iso) return "";
    const m = String(iso).match(/^(\d{4})-(\d{2})/);
    return m ? `${m[1]}-${m[2]}` : "";
  };
  const formatMonth = (value: string) => {
    const [y, mo] = value.split("-").map(Number);
    if (!y || !mo) return value;
    return new Date(y, mo - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  };

  const { data: installments, isLoading } = useQuery({
    queryKey: ["pagamentos-data"],
    queryFn: () => getPagamentosData(),
    staleTime: 1000 * 30, // 30 seconds
  });

  const stores = useMemo<string[]>(() => {
    if (!installments) return [];
    const rawStores = installments.map((i: any) => i.loan?.store_name).filter((s: any): s is string => typeof s === 'string') as string[];
    return Array.from(new Set(rawStores)).sort();
  }, [installments]);

  const monthOptions = useMemo<string[]>(() => {
    if (!installments) return [];
    const months = installments.map((i: any) => getMonthValue(i.due_date)).filter((m: string) => Boolean(m)) as string[];
    return Array.from(new Set(months)).sort();
  }, [installments]);

  const filteredInstallments = useMemo(() => {
    if (!installments) return [];
    let list = installments.filter((i: any) => {
      const matchesSearch = i.customer?.name?.toLowerCase().includes(search.toLowerCase());
      const matchesStore = storeFilter === "all" || i.loan?.store_name === storeFilter;
      const matchesMonth = monthFilter === "all" || getMonthValue(i.due_date) === monthFilter;
      const matchesStatus =
        statusFilter === "all" ? true :
        statusFilter === "pending" ? i.status === "pending" :
        statusFilter === "overdue" ? i.status === "overdue" :
        i.status === "paid";
      return matchesSearch && matchesStore && matchesMonth && matchesStatus;
    });
    if (paymentFilter === "next") {
      // Only the nearest pending installment per customer
      const byCustomer: Record<string, any> = {};
      for (const i of list) {
        if (i.status === "paid") continue;
        const cid = i.customer?.id || "u";
        if (!byCustomer[cid] || String(i.due_date) < String(byCustomer[cid].due_date)) byCustomer[cid] = i;
      }
      list = Object.values(byCustomer);
    }
    return list;
  }, [installments, search, storeFilter, monthFilter, statusFilter, paymentFilter]);

  const filteredTotals = useMemo(() => {
    let total = 0, open = 0;
    for (const i of filteredInstallments) {
      total += Number(i.amount || 0);
      if (i.status !== "paid") open += Number(i.amount || 0);
    }
    return { total, open, count: filteredInstallments.length };
  }, [filteredInstallments]);

  const groupedByCustomer = useMemo(() => {
    const groups: Record<string, { customer: any, installments: any[] }> = {};
    
    filteredInstallments.forEach((inst: any) => {
      const customerId = inst.customer?.id || "unknown";
      if (!groups[customerId]) {
        groups[customerId] = {
          customer: inst.customer || { id: "unknown", name: "Cliente Desconhecido" },
          installments: []
        };
      }
      groups[customerId].installments.push(inst);
    });

    return Object.values(groups).sort((a, b) => 
      (a.customer?.name || "").localeCompare(b.customer?.name || "")
    );
  }, [filteredInstallments]);

  const stats = useMemo(() => {
    if (!installments) return { pending: 0, overdue: 0, received: 0 };
    return installments.reduce((acc: any, i: any) => {
      const totalPaid = i.payment_records?.reduce((sum: number, r: any) => sum + Number(r.amount), 0) || 0;
      const remaining = Number(i.amount) - totalPaid;
      
      acc.received += totalPaid;
      if (remaining > 0) {
        acc.pending += remaining;
        if (i.status === "overdue") acc.overdue += remaining;
      }
      return acc;
    }, { pending: 0, overdue: 0, received: 0 });
  }, [installments]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `payments/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('loan-attachments')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('loan-attachments')
        .getPublicUrl(filePath);

      setProofUrl(publicUrl);
      toast.success("Comprovante anexado!");
    } catch (error: any) {
      toast.error("Erro ao fazer upload: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const payMutation = useMutation({
    mutationFn: (vars: any) => createPaymentRecord({ data: vars }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pagamentos-data"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      toast.success("Pagamento registrado!");
      resetForm();
    },
    onError: (e: any) => toast.error(e.message)
  });

  const updateRecordMutation = useMutation({
    mutationFn: (vars: any) => updatePaymentRecord({ data: vars } as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pagamentos-data"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      toast.success("Pagamento atualizado!");
      setEditingRecord(null);
    },
    onError: (e: any) => toast.error(e.message)
  });

  const deleteRecordMutation = useMutation({
    mutationFn: (id: string) => deletePaymentRecord({ data: { id } } as any),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pagamentos-data"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      toast.success("Pagamento removido!");
    },
    onError: (e: any) => toast.error(e.message)
  });

  const resetForm = () => {
    setSelectedInst(null);
    setPaymentMethod(null);
    setAmount(0);
    setCardFee(0);
    setChequeNumber("");
    setChequeBank("");
    setProofUrl("");
    setPaidAt(new Date().toISOString().split('T')[0]);
  };

  const handlePay = () => {
    if (!selectedInst || !paymentMethod || amount <= 0) return;
    payMutation.mutate({ 
      installmentId: selectedInst.id, 
      amount,
      paymentMethod,
      cardFee: paymentMethod === 'card' ? cardFee : undefined,
      chequeNumber: paymentMethod === 'cheque' ? chequeNumber : undefined,
      chequeBank: paymentMethod === 'cheque' ? chequeBank : undefined,
      chequeDate: paymentMethod === 'cheque' ? chequeDate : undefined,
      proofUrl,
      paidAt: paidAt ? new Date(paidAt).toISOString() : undefined,
      createNextInstallment,
      nextDueDate
    });
  };

  const generateReceiptPDF = (inst: any) => {
    try {
      const doc = new jsPDF({ format: 'a5', orientation: 'landscape' });
      const customerName = (inst.customer?.name || "Cliente").toUpperCase();

      const totalPaid = inst.payment_records?.reduce((sum: number, r: any) => sum + Number(r.amount), 0) || 0;
      const latestPayment = inst.payment_records && inst.payment_records.length > 0
        ? [...inst.payment_records].sort((a: any, b: any) => new Date(b.paid_at).getTime() - new Date(a.paid_at).getTime())[0]
        : null;

      const amountToDisplay = totalPaid > 0 ? totalPaid : Number(inst.amount);
      const paidAt = latestPayment ? new Date(latestPayment.paid_at) : (inst.paid_at ? new Date(inst.paid_at) : new Date());
      const method = latestPayment?.payment_method || inst.payment_method || 'SISTEMA';

      const pageWidth = doc.internal.pageSize.width;

      // Branded header banner (VeraPay)
      doc.setFillColor(brand.deep[0], brand.deep[1], brand.deep[2]);
      doc.rect(0, 0, pageWidth, 28, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(20);
      doc.text("RECIBO DE PAGAMENTO", pageWidth / 2, 18, { align: "center" });

      // Soft accent stripe
      doc.setFillColor(brand.soft[0], brand.soft[1], brand.soft[2]);
      doc.rect(0, 28, pageWidth, 4, 'F');

      doc.setTextColor(brand.deep[0], brand.deep[1], brand.deep[2]);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(12);

      let y = 50;
      doc.text(`Recebemos de ${customerName}`, 15, y);
      y += 9;
      doc.setFont("helvetica", "bold");
      doc.text(`A quantia de ${fmtMoneyBR(amountToDisplay)}`, 15, y);
      doc.setFont("helvetica", "normal");
      y += 9;
      doc.text(`Referente à ${inst.number}ª parcela da loja ${inst.loan?.store_name || 'VeraPay'}`, 15, y);
      y += 9;
      doc.text(`Pagamento realizado via ${String(method).toUpperCase()}`, 15, y);

      y += 18;
      doc.text(`${format(paidAt, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}`, pageWidth / 2, y, { align: "center" });

      y += 18;
      doc.setDrawColor(brand.primary[0], brand.primary[1], brand.primary[2]);
      doc.line(55, y, pageWidth - 55, y);
      doc.setFontSize(10);
      doc.text("VERAPAY — SISTEMA DE GESTÃO", pageWidth / 2, y + 5, { align: "center" });

      drawVeraPayFooter(doc);
      doc.save(`VeraPay_Recibo_${customerName.replace(/\s+/g, '_')}_P${inst.number}.pdf`);
      toast.success("Recibo gerado com sucesso!");
    } catch (error) {
      console.error("PDF Error:", error);
      toast.error("Erro ao gerar recibo");
    }
  };


  if (isLoading) return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="h-20 w-full bg-[#F5EBEF] animate-pulse rounded-[32px]" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="h-32 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
        <div className="h-32 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
        <div className="h-32 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
      </div>
      <div className="h-96 w-full bg-[#F5EBEF] animate-pulse rounded-[40px]" />
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col gap-6 md:flex-row md:items-center justify-between">
        <div>
          <h1 className="text-4xl font-black tracking-tighter text-[#2A2A2A] uppercase">
            Gestão de <span className="gold-text">Pagamentos</span>
          </h1>
          <p className="text-[#6B6B6B] font-medium italic">Interface premium para controle total de recebimentos.</p>
        </div>
        
        <div className="flex flex-wrap gap-4">
           <Card className="bg-[#F5EBEF] border-[#EAEAEA] p-4 min-w-[140px]">
             <div className="flex items-center gap-2 mb-1">
               <Clock className="text-[#C84D8A]" size={14} />
               <span className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest">À Receber</span>
             </div>
             <div className="text-xl font-black text-[#2A2A2A]">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.pending)}</div>
           </Card>
           
           <Card className="bg-[#F5EBEF] border-[#EAEAEA] p-4 min-w-[140px]">
             <div className="flex items-center gap-2 mb-1">
               <AlertCircle className="text-rose-400" size={14} />
               <span className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest">Atrasado</span>
             </div>
             <div className="text-xl font-black text-rose-400">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.overdue)}</div>
           </Card>

           <Card className="bg-[#F5EBEF] border-[#EAEAEA] p-4 min-w-[140px]">
             <div className="flex items-center gap-2 mb-1">
               <TrendingUp className="text-emerald-400" size={14} />
               <span className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest">Recebido Total</span>
             </div>
             <div className="text-xl font-black text-emerald-400">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.received)}</div>
           </Card>
        </div>
      </div>

      <div className="flex flex-col md:flex-row flex-wrap gap-4 items-stretch md:items-center justify-between bg-[#F5EBEF] p-4 rounded-3xl border border-[#EAEAEA] shadow-2xl">
         <div className="flex flex-col md:flex-row flex-wrap gap-4 w-full md:w-auto flex-1 min-w-0">

           <div className="relative w-full md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6B6B6B]" size={18} />
              <Input 
                className="pl-12 h-12 bg-[#FFFFFF] border-[#EAEAEA] rounded-2xl focus:ring-2 ring-[#C84D8A]/20 transition-all" 
                placeholder="Pesquisar cliente por nome..." 
                value={search} 
                onChange={(e) => setSearch(e.target.value)} 
              />
           </div>
           
           <div className="w-full md:w-64">
             <Select value={storeFilter} onValueChange={setStoreFilter}>
               <SelectTrigger className="h-12 bg-[#FFFFFF] border-[#EAEAEA] rounded-2xl text-[#6B6B6B] font-bold uppercase text-[10px] tracking-widest">
                 <div className="flex items-center gap-2">
                   <Store size={14} className="text-[#C84D8A]" />
                   <SelectValue placeholder="Filtrar por Loja" />
                 </div>
               </SelectTrigger>
               <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                 <SelectItem value="all">Todas as Lojas</SelectItem>
                  {stores.map((store: string) => (
                    <SelectItem key={store} value={store}>{store}</SelectItem>
                  ))}
               </SelectContent>
             </Select>
           </div>

           <div className="w-full md:w-56">
             <Select value={monthFilter} onValueChange={setMonthFilter}>
               <SelectTrigger className="h-12 bg-[#FFFFFF] border-[#EAEAEA] rounded-2xl text-[#6B6B6B] font-bold uppercase text-[10px] tracking-widest">
                 <div className="flex items-center gap-2">
                   <Clock size={14} className="text-[#C84D8A]" />
                   <SelectValue placeholder="Mês" />
                 </div>
               </SelectTrigger>
               <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                 <SelectItem value="all">Todos os meses</SelectItem>
                 {monthOptions.map((m) => (
                   <SelectItem key={m} value={m} className="capitalize">{formatMonth(m)}</SelectItem>
                 ))}
               </SelectContent>
             </Select>
           </div>

           <div className="w-full md:w-56">
             <Select value={paymentFilter} onValueChange={(v: any) => setPaymentFilter(v)}>
               <SelectTrigger className="h-12 bg-[#FFFFFF] border-[#EAEAEA] rounded-2xl text-[#6B6B6B] font-bold uppercase text-[10px] tracking-widest">
                 <SelectValue placeholder="Pagamento" />
               </SelectTrigger>
               <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                 <SelectItem value="all">Todos os pagamentos</SelectItem>
                 <SelectItem value="next">Próximo pagamento</SelectItem>
               </SelectContent>
             </Select>
           </div>
         </div>

         <Tabs value={statusFilter} onValueChange={(v: any) => setStatusFilter(v)} className="w-full md:w-auto">
           <TabsList className="bg-[#FFFFFF] h-12 p-1 rounded-2xl border border-[#EAEAEA]">
             <TabsTrigger value="all" className="rounded-xl px-6 font-bold uppercase text-[10px] tracking-widest">Todos</TabsTrigger>
             <TabsTrigger value="pending" className="rounded-xl px-6 font-bold uppercase text-[10px] tracking-widest">Pendentes</TabsTrigger>
             <TabsTrigger value="overdue" className="rounded-xl px-6 font-bold uppercase text-[10px] tracking-widest">Atrasados</TabsTrigger>
             <TabsTrigger value="paid" className="rounded-xl px-6 font-bold uppercase text-[10px] tracking-widest">Pagos</TabsTrigger>
           </TabsList>
         </Tabs>
      </div>

      {/* Resumo do filtro */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-2xl bg-white border border-[#EAEAEA] px-5 py-4 shadow-sm">
          <div className="text-[10px] uppercase tracking-widest font-bold text-[#6B6B6B]">Total do período</div>
          <div className="text-xl font-extrabold text-[#2A2A2A] mt-1">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(filteredTotals.total)}</div>
        </div>
        <div className="rounded-2xl bg-white border border-[#EAEAEA] px-5 py-4 shadow-sm">
          <div className="text-[10px] uppercase tracking-widest font-bold text-[#6B6B6B]">Em aberto no filtro</div>
          <div className="text-xl font-extrabold text-[#7D2958] mt-1">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(filteredTotals.open)}</div>
        </div>
        <div className="rounded-2xl bg-white border border-[#EAEAEA] px-5 py-4 shadow-sm">
          <div className="text-[10px] uppercase tracking-widest font-bold text-[#6B6B6B]">Parcelas encontradas</div>
          <div className="text-xl font-extrabold text-[#2A2A2A] mt-1">{filteredTotals.count}</div>
        </div>
      </div>

      <div className="space-y-4">
        {groupedByCustomer.length === 0 ? (
          <Card className="glass-card shadow-3xl border-none overflow-hidden bg-[#FFFFFF] rounded-[40px] border border-[#EAEAEA] py-20">
            <div className="flex flex-col items-center gap-4">
              <Receipt size={48} className="text-[#2A2A2A]" />
              <p className="text-[#6B6B6B] font-bold uppercase tracking-widest text-sm">Nenhum registro encontrado</p>
            </div>
          </Card>
        ) : (
          <Accordion type="multiple" defaultValue={groupedByCustomer.map(g => g.customer?.id)} className="space-y-4">
            {groupedByCustomer.map((group) => (
              <AccordionItem 
                key={group.customer?.id} 
                value={group.customer?.id}
                className="border-none bg-[#FFFFFF] rounded-[32px] overflow-hidden border border-[#EAEAEA] shadow-xl"
              >
                <AccordionTrigger className="hover:no-underline px-8 py-6 group">
                  <div className="flex items-center gap-4 text-left">
                    <div className="w-12 h-12 rounded-2xl bg-[#F5EBEF] flex items-center justify-center text-[#C84D8A] border border-[#EAEAEA] group-hover:scale-110 transition-transform">
                      <User size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-[#2A2A2A] uppercase tracking-tight">
                        {group.customer?.name || "Cliente Desconhecido"}
                      </h3>
                      <div className="flex items-center gap-3 text-[10px] text-[#6B6B6B] font-bold uppercase tracking-widest mt-0.5">
                        <span className="flex items-center gap-1"><Smartphone size={10} /> {group.customer?.phone || "--"}</span>
                        <span className="w-1 h-1 rounded-full bg-slate-700" />
                        <span className="text-[#C84D8A]">{group.installments.length} {group.installments.length === 1 ? 'Parcela' : 'Parcelas'}</span>
                      </div>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-0 pb-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader className="bg-[#F5EBEF]">
                        <TableRow className="border-[#EAEAEA] hover:bg-transparent">
                          <TableHead className="font-bold pl-8 text-[#6B6B6B] uppercase text-[10px] tracking-widest">Loja / Ref</TableHead>
                          <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Vencimento</TableHead>
                          <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Valor</TableHead>
                          <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest text-center">Parcela</TableHead>
                          <TableHead className="font-bold text-[#6B6B6B] uppercase text-[10px] tracking-widest">Status</TableHead>
                          <TableHead className="text-right font-bold pr-8 text-[#6B6B6B] uppercase text-[10px] tracking-widest">Ações</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {group.installments.map((inst: any) => {
                          const totalPaid = inst.payment_records?.reduce((sum: number, r: any) => sum + Number(r.amount), 0) || 0;
                          const remaining = Number(inst.amount) - totalPaid;
                          
                          return (
                            <TableRow key={inst.id} className="hover:bg-[#F5EBEF]/80 border-[#EAEAEA] h-20 transition-colors">
                              <TableCell className="pl-8">
                                <div className="font-bold text-[#2A2A2A] flex items-center gap-2">
                                  <Store size={14} className="text-[#6B6B6B]" />
                                  {inst.loan?.store_name || "Venda Direta"}
                                </div>
                                {inst.loan?.order_number && (
                                  <div className="text-[9px] font-bold text-[#6B6B6B] uppercase mt-0.5">Ref: {inst.loan.order_number}</div>
                                )}
                              </TableCell>
                              <TableCell className="font-medium italic text-[#6B6B6B]">
                                {formatDateOnly(inst.due_date)}
                              </TableCell>
                              <TableCell>
                                <div className="font-black text-[#C84D8A]">
                                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(inst.amount))}
                                </div>
                                {totalPaid > 0 && remaining > 0 && (
                                  <div className="text-[9px] font-black text-rose-400 uppercase">Falta: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(remaining)}</div>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <Badge variant="outline" className="bg-[#F5EBEF] border-[#EAEAEA] text-[#6B6B6B] font-black">
                                  {inst.number}ª / {inst.loan?.installments_count || "?"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                 {inst.status === "paid" ? (
                                   <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-2 py-0.5 rounded-lg text-[9px] font-black">
                                     PAGO
                                   </Badge>
                                 ) : inst.status === "overdue" ? (
                                   <Badge className="bg-rose-500/10 text-rose-400 border-rose-500/20 px-2 py-0.5 rounded-lg text-[9px] font-black animate-pulse">
                                     ATRASADO
                                   </Badge>
                                 ) : (
                                   <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20 px-2 py-0.5 rounded-lg text-[9px] font-black">
                                     PENDENTE
                                   </Badge>
                                 )}
                              </TableCell>
                              <TableCell className="text-right pr-8">
                                <div className="flex justify-end gap-2">
                                  {group.customer?.phone && remaining > 0 && (
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="h-8 w-8 text-emerald-500 hover:bg-emerald-500/10 rounded-lg" 
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        const phone = group.customer.phone.replace(/\D/g, '');
                                        const text = `Ol%C3%A1%20${group.customer.name}!%20Lembrete%20VeraPay:%20Sua%20parcela%20no%20valor%20de%20${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(inst.amount))}%20vence%20em%20${formatDateOnly(inst.due_date, 'dd/MM')}.%20Pode%20confirmar%20o%20pagamento?`;
                                        window.open(`https://wa.me/55${phone}?text=${text}`, '_blank');
                                      }}
                                    >
                                       <MessageSquare size={14} />
                                    </Button>
                                  )}
                                  
                                  {remaining > 0 && (
                                     <Button 
                                       size="sm"
                                       className="bg-[#C84D8A] text-[#7D2958] hover:bg-[#C84D8A]/90 font-black uppercase text-[9px] tracking-widest h-8 px-4 rounded-lg" 
                                       onClick={(e) => { 
                                         e.stopPropagation();
                                         setSelectedInst(inst); 
                                         setAmount(remaining); 
                                       }}
                                     >
                                       Receber
                                     </Button>
                                  )}
                                    <Button 
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 text-[#6B6B6B] hover:text-[#C84D8A]"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        generateReceiptPDF(inst);
                                      }}
                                    >
                                      <Receipt size={14} />
                                    </Button>
                                    {(inst.payment_records?.length ?? 0) > 0 && (
                                      <Button 
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 text-blue-400 hover:bg-blue-400/10"
                                        onClick={(e) => { e.stopPropagation(); setShowHistory(inst.id); }}
                                        title="Histórico / Editar pagamentos"
                                      >
                                        <History size={14} />
                                      </Button>
                                    )}
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}
      </div>
      
      {/* Payment Dialog */}
      <Dialog open={!!selectedInst} onOpenChange={(open) => !open && resetForm()}>
        <DialogContent className="sm:max-w-[480px] max-h-[90vh] overflow-y-auto bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] rounded-[40px] p-6 sm:p-8 shadow-4xl">
          <DialogHeader>
            <DialogTitle className="text-3xl font-black text-[#C84D8A] uppercase tracking-tighter">Registrar Pagamento</DialogTitle>
            <p className="text-[#6B6B6B] font-medium italic">Confirmando recebimento de {selectedInst?.customer?.name}</p>
          </DialogHeader>
          
          <div className="grid gap-8 py-6">
            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Valor do Recebimento</Label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-2xl text-[#C84D8A]">R$</span>
                <Input 
                  type="number" 
                  className="pl-14 h-16 text-3xl font-black text-[#2A2A2A] border-[#EAEAEA] bg-[#F5EBEF] rounded-2xl shadow-inner" 
                  value={amount || ""}
                  onChange={(e) => setAmount(Number(e.target.value))}
                />
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Data do Pagamento</Label>
              <Input 
                type="date" 
                className="h-12 text-base font-bold text-[#2A2A2A] border-[#EAEAEA] bg-[#F5EBEF] rounded-2xl"
                value={paidAt}
                onChange={(e) => setPaidAt(e.target.value)}
              />
            </div>
            
            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Método de Pagamento</Label>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">

                {[
                  { id: 'pix', label: 'PIX', icon: Zap, color: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/20' },
                  { id: 'cash', label: 'Dinheiro', icon: Banknote, color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20' },
                  { id: 'card', label: 'Cartão', icon: CreditCard, color: 'text-purple-400 bg-purple-400/10 border-purple-400/20' },
                  { id: 'cheque', label: 'Cheque', icon: Landmark, color: 'text-orange-400 bg-orange-400/10 border-orange-400/20' },
                  { id: 'nota_promissoria', label: 'Promissória', icon: FileText, color: 'text-rose-400 bg-rose-400/10 border-rose-400/20' }
                ].map((method) => (

                  <Button 
                    key={method.id}
                    variant="outline" 
                    className={`h-24 flex flex-col items-center justify-center gap-3 border-2 transition-all rounded-2xl ${
                      paymentMethod === method.id 
                        ? `${method.color} border-current ring-4 ring-current/10` 
                        : 'border-[#EAEAEA] bg-[#F5EBEF] hover:bg-[#F5EBEF]/80'
                    }`}
                    onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                  >
                    <method.icon size={28} />
                    <span className="text-[11px] font-black uppercase tracking-widest">{method.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            {paymentMethod === 'card' && (
              <div className="space-y-2 p-5 bg-purple-500/5 rounded-2xl border border-purple-500/20 animate-in zoom-in duration-300">
                <Label className="text-[10px] font-black text-purple-400 uppercase">Taxa / Acréscimo</Label>
                <Input 
                  type="number" 
                  className="h-12 border-purple-500/20 bg-[#F5EBEF] font-bold text-[#2A2A2A] rounded-xl" 
                  placeholder="R$ 0,00"
                  value={cardFee || ""}
                  onChange={(e) => setCardFee(Number(e.target.value))}
                />
              </div>
            )}

            {paymentMethod === 'cheque' && (
              <div className="space-y-4 p-5 bg-orange-500/5 rounded-2xl border border-orange-500/20 animate-in zoom-in duration-300">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-[10px] font-black text-orange-400 uppercase">Nº Cheque</Label>
                    <Input className="h-10 border-orange-500/30 bg-white text-[#2A2A2A] rounded-xl focus:border-orange-400 transition-colors !placeholder-slate-700" value={chequeNumber} onChange={(e) => setChequeNumber(e.target.value)} placeholder="000000" />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[10px] font-black text-orange-400 uppercase">Banco</Label>
                    <Input className="h-10 border-orange-500/30 bg-white text-[#2A2A2A] rounded-xl focus:border-orange-400 transition-colors !placeholder-slate-700" value={chequeBank} onChange={(e) => setChequeBank(e.target.value)} placeholder="Ex: Itaú" />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Comprovante (Opcional)</Label>
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleFileUpload}
              />
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`flex items-center justify-center w-full h-20 border-2 border-dashed rounded-2xl transition-colors cursor-pointer group ${
                  proofUrl 
                    ? "border-green-500/50 bg-green-500/5" 
                    : "border-[#EAEAEA] bg-[#F5EBEF] hover:border-[#C84D8A]/30"
                }`}
              >
                <div className="text-center">
                  {uploading ? (
                    <Loader2 size={24} className="mx-auto text-[#C84D8A] animate-spin" />
                  ) : proofUrl ? (
                    <div className="flex items-center gap-2 text-green-500">
                      <CheckCircle2 size={20} />
                      <span className="text-xs font-bold uppercase">Foto Anexada!</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-[#6B6B6B] group-hover:text-[#C84D8A]">
                      <PlusCircle size={20} />
                      <span className="text-xs font-bold uppercase">Anexar Foto</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button 
              className="w-full h-16 text-lg font-black shadow-2xl btn-primary uppercase tracking-[0.2em] text-[#7D2958] rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98]" 
              onClick={handlePay} 
              disabled={!paymentMethod || amount <= 0 || payMutation.isPending}
            >
              {payMutation.isPending ? <Loader2 className="animate-spin mr-2" /> : <CheckCircle2 className="mr-2" />}
              Confirmar Recebimento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Dialog */}
      <Dialog open={!!showHistory} onOpenChange={(open) => !open && setShowHistory(null)}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] rounded-[40px] p-6 sm:p-8 shadow-4xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase tracking-tighter">Histórico de Amortização</DialogTitle>
            <p className="text-[#6B6B6B] font-medium italic">Registros de pagamentos efetuados nesta parcela.</p>
          </DialogHeader>
          <div className="py-6 space-y-4">
            {installments?.find((i: any) => i.id === showHistory)?.payment_records?.length === 0 ? (
              <div className="text-center py-10 text-[#6B6B6B] font-bold uppercase text-[10px]">Nenhum pagamento registrado</div>
            ) : (
              installments?.find((i: any) => i.id === showHistory)?.payment_records?.map((r: any) => (
                <div key={r.id} className="flex justify-between items-center p-5 rounded-2xl border border-[#EAEAEA] bg-[#F5EBEF] transition-all hover:border-[#C84D8A]/30">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-3">
                      <span className="font-black text-[#2A2A2A] text-xl">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(r.amount))}</span>
                      <Badge variant="outline" className="text-[9px] uppercase font-black tracking-[0.2em] bg-emerald-500/10 text-emerald-400 border-emerald-500/20">{r.payment_method}</Badge>
                    </div>
                    <div className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest flex items-center gap-1.5">
                      <Clock size={10} />
                      {format(new Date(r.paid_at), "dd/MM/yyyy 'às' HH:mm")}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {r.proof_url && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-blue-400 hover:bg-blue-400/10 rounded-xl"
                        onClick={() => window.open(r.proof_url, '_blank')}
                        title="Ver comprovante"
                      >
                        <ImageIcon size={20} />
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-[#C84D8A] hover:bg-[#C84D8A]/10 rounded-xl"
                      onClick={() => { if (requireAdminPassword("editar este pagamento")) setEditingRecord(r); }}
                      title="Editar pagamento"
                    >
                      <Pencil size={18} />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-rose-400 hover:bg-rose-400/10 rounded-xl"
                      onClick={() => { if (requireAdminPassword("excluir este pagamento") && confirm("Excluir este pagamento?")) deleteRecordMutation.mutate(r.id); }}
                      title="Excluir pagamento"
                    >
                      <Trash2 size={18} />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Payment Dialog */}
      <Dialog open={!!editingRecord} onOpenChange={(open) => !open && setEditingRecord(null)}>
        <DialogContent className="sm:max-w-[440px] max-h-[90vh] overflow-y-auto bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] rounded-[40px] p-6 sm:p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase">Editar Pagamento</DialogTitle>
          </DialogHeader>
          {editingRecord && (
            <div className="space-y-5 py-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-[#C84D8A]">Valor</Label>
                <Input
                  type="number"
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 text-lg font-bold rounded-xl"
                  value={editingRecord.amount || ""}
                  onChange={(e) => setEditingRecord({ ...editingRecord, amount: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-[#C84D8A]">Data do Pagamento</Label>
                <Input
                  type="date"
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl"
                  value={editingRecord.paid_at ? new Date(editingRecord.paid_at).toISOString().split('T')[0] : ''}
                  onChange={(e) => setEditingRecord({ ...editingRecord, paid_at: new Date(e.target.value).toISOString() })}
                />
              </div>
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-[#C84D8A]">Método</Label>
                <Select value={editingRecord.payment_method} onValueChange={(v) => setEditingRecord({ ...editingRecord, payment_method: v })}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectItem value="pix">PIX</SelectItem>
                    <SelectItem value="cash">Dinheiro</SelectItem>
                    <SelectItem value="card">Cartão</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                    <SelectItem value="nota_promissoria">Promissória</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {editingRecord.payment_method === 'cheque' && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase text-orange-400">Nº Cheque</Label>
                    <Input className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl" value={editingRecord.cheque_number || ''} onChange={(e) => setEditingRecord({ ...editingRecord, cheque_number: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-[10px] font-black uppercase text-orange-400">Banco</Label>
                    <Input className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl" value={editingRecord.cheque_bank || ''} onChange={(e) => setEditingRecord({ ...editingRecord, cheque_bank: e.target.value })} />
                  </div>
                </div>
              )}
              {editingRecord.payment_method === 'card' && (
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase text-purple-400">Taxa Cartão</Label>
                  <Input type="number" className="h-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl" value={editingRecord.card_fee || 0} onChange={(e) => setEditingRecord({ ...editingRecord, card_fee: Number(e.target.value) })} />
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button
              className="w-full h-14 btn-primary font-black uppercase tracking-widest rounded-2xl"
              disabled={updateRecordMutation.isPending}
              onClick={() => updateRecordMutation.mutate({
                id: editingRecord.id,
                amount: editingRecord.amount,
                paidAt: editingRecord.paid_at,
                paymentMethod: editingRecord.payment_method,
                cardFee: editingRecord.card_fee,
                chequeNumber: editingRecord.cheque_number,
                chequeBank: editingRecord.cheque_bank,
              })}
            >
              {updateRecordMutation.isPending ? <Loader2 className="animate-spin mr-2" /> : <CheckCircle2 className="mr-2" />}
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
