import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyClientPortal } from "../serverFunctions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, LogOut, CalendarClock, CheckCircle2, AlertCircle, Wallet, Receipt, User as UserIcon, QrCode, History, Clock, Mail, Phone, RefreshCw, Filter, Store, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { formatCpf } from "@/lib/cpf";
import { QRCodeSVG } from "qrcode.react";

export const Route = createFileRoute("/cliente/")({
  ssr: false,
  component: ClientePortalPage,
});

const brl = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);

const parseDateParts = (iso?: string | null): { year: number; month: number; day: number } | null => {
  if (!iso) return null;
  const match = String(iso).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return { year: Number(match[1]), month: Number(match[2]), day: Number(match[3]) };
  const d = new Date(iso);
  return { year: d.getFullYear(), month: d.getMonth() + 1, day: d.getDate() };
};

const formatDate = (iso?: string | null) => {
  const parts = parseDateParts(iso);
  if (!parts) return "-";
  return `${String(parts.day).padStart(2, "0")}/${String(parts.month).padStart(2, "0")}/${parts.year}`;
};

const getMonthValue = (iso?: string | null) => {
  const parts = parseDateParts(iso);
  if (!parts) return "";
  return `${parts.year}-${String(parts.month).padStart(2, "0")}`;
};

const formatMonth = (value: string) => {
  const [year, month] = value.split("-").map(Number);
  if (!year || !month) return value;
  return new Date(year, month - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
};

function ClientePortalPage() {
  const navigate = useNavigate();
  const [authChecked, setAuthChecked] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [monthFilter, setMonthFilter] = useState("all");
  const [storeFilter, setStoreFilter] = useState("all");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const handledLimitResponsesRef = useRef<Set<string>>(new Set());
  const lastLimitNoticeAtRef = useRef(0);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate({ to: "/cliente/login" as any });
        return;
      }
      setAuthChecked(true);
    })();
  }, [navigate]);

  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ["my-client-portal"],
    queryFn: () => getMyClientPortal(),
    enabled: authChecked,
    retry: false,
    staleTime: 0,
    refetchOnMount: "always",
    refetchOnWindowFocus: true,
    refetchInterval: 30_000,
  });

  // Realtime: notify client when purchases or limit releases affect their account
  const customerId = data?.customer?.id;
  useEffect(() => {
    if (!authChecked || !customerId) return;
    const channel = supabase
      .channel(`client-account-${customerId}-${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "loans", filter: `customer_id=eq.${customerId}` },
        (payload: any) => {
          const total = Number(payload?.new?.total_amount || 0);
          const valor = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(total);
          toast.success("Compra realizada!", {
            description: `Uma nova compra de ${valor} foi registrada na sua conta.`,
            duration: 8000,
            icon: <ShoppingBag className="text-[#C84D8A]" />,
          });
          refetch();
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "customers", filter: `id=eq.${customerId}` },
        (payload: any) => {
          const previousLimit = Number(payload.old?.credit_limit || 0);
          const nextLimit = Number(payload.new?.credit_limit || 0);
          if (nextLimit !== previousLimit) {
            const increased = nextLimit > previousLimit;
            if (Date.now() - lastLimitNoticeAtRef.current < 2500) {
              refetch();
              return;
            }
            lastLimitNoticeAtRef.current = Date.now();
            toast.success(increased ? "Seu limite foi liberado!" : "Compra confirmada e limite normalizado.", {
              description: increased
                ? `Limite temporário disponível agora: ${brl(nextLimit)}.`
                : `Após a compra, seu limite voltou para ${brl(nextLimit)}.`,
              duration: 9000,
              icon: <Wallet className="text-[#C84D8A]" />,
            });
          }
          refetch();
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "limit_requests", filter: `customer_id=eq.${customerId}` },
        (payload: any) => {
          const requestId = String(payload.new?.id || "");
          const status = payload.new?.status;
          if (!requestId || handledLimitResponsesRef.current.has(requestId)) return;
          if (status === "approved") {
            handledLimitResponsesRef.current.add(requestId);
            refetch();
            window.setTimeout(() => {
              if (Date.now() - lastLimitNoticeAtRef.current < 1500) return;
              lastLimitNoticeAtRef.current = Date.now();
              toast.success("Liberação aprovada!", {
                description: "A loja já pode consultar seu limite atualizado.",
                duration: 9000,
                icon: <CheckCircle2 className="text-[#C84D8A]" />,
              });
            }, 900);
          } else if (status === "rejected") {
            handledLimitResponsesRef.current.add(requestId);
            toast.error("Liberação de limite não aprovada.", {
              description: payload.new?.response_note || "Fale com a loja para entender a próxima etapa.",
              duration: 9000,
            });
            refetch();
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [authChecked, customerId, refetch]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/cliente/login" as any });
  };

  if (!authChecked || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7]">
        <Loader2 className="animate-spin text-[#C84D8A]" size={32} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#FAF6F7] px-4 text-center">
        <AlertCircle className="text-[#C84D8A] mb-3" size={40} />
        <h2 className="text-xl font-bold text-[#2A2A2A]">Não foi possível carregar seus dados</h2>
        <p className="text-sm text-[#6B6B6B] mt-2 max-w-sm">
          Sua conta ainda não está vinculada a um cliente. Procure a loja para liberar seu acesso.
        </p>
        <Button onClick={handleLogout} className="mt-6 btn-primary">Sair</Button>
      </div>
    );
  }

  const { customer, summary, installments } = data!;
  const sortedInstallments = [...installments].sort((a: any, b: any) => String(a.due_date).localeCompare(String(b.due_date)));
  const monthOptions = Array.from(new Set(sortedInstallments.map((i: any) => getMonthValue(i.due_date)).filter(Boolean))).sort();
  const storeOptions = Array.from(new Set(sortedInstallments.map((i: any) => String(i.loans?.store_name || "")).filter(Boolean))).sort((a, b) => a.localeCompare(b));
  const byMonthAndStore = sortedInstallments.filter((i: any) => {
    const monthMatches = monthFilter === "all" || getMonthValue(i.due_date) === monthFilter;
    const storeMatches = storeFilter === "all" || i.loans?.store_name === storeFilter;
    return monthMatches && storeMatches;
  });
  const nextFilteredInstallment = byMonthAndStore.find((i: any) => i.status !== "paid");
  const noFiltersActive = monthFilter === "all" && storeFilter === "all" && paymentFilter === "all";
  let filteredInstallments: any[];
  if (paymentFilter === "next") {
    filteredInstallments = nextFilteredInstallment ? [nextFilteredInstallment] : [];
  } else if (noFiltersActive) {
    // Padrão: mostrar apenas a próxima parcela em aberto de cada compra
    const seenLoans = new Set<string>();
    const nextPerLoan: any[] = [];
    for (const inst of byMonthAndStore) {
      if (inst.status === "paid") continue;
      const loanId = String(inst.loan_id || inst.loans?.id || "");
      if (seenLoans.has(loanId)) continue;
      seenLoans.add(loanId);
      nextPerLoan.push(inst);
    }
    filteredInstallments = nextPerLoan;
  } else {
    filteredInstallments = byMonthAndStore;
  }
  const filteredTotal = filteredInstallments.reduce((s: number, i: any) => s + Number(i.amount), 0);
  const filteredOpenTotal = filteredInstallments.filter((i: any) => i.status !== "paid").reduce((s: number, i: any) => s + Number(i.amount), 0);
  const groupedInstallments = filteredInstallments.reduce((acc: Record<string, any[]>, item: any) => {
    const key = getMonthValue(item.due_date) || "sem-data";
    acc[key] = acc[key] || [];
    acc[key].push(item);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-[#FAF6F7] pb-12">
      {/* Header */}
      <header className="bg-[#7D2958] text-white px-4 md:px-8 py-5 shadow-lg">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-white/15 flex items-center justify-center ring-2 ring-white/20 shrink-0">
              {(customer as any).avatar_signed_url ? (
                <img src={(customer as any).avatar_signed_url} alt={customer.name} className="w-full h-full object-cover" />
              ) : (
                <span className="font-extrabold text-lg">{customer.name?.[0]?.toUpperCase() ?? "?"}</span>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-[11px] uppercase tracking-wider text-white/70 font-bold">Olá 👋</p>
              <h1 className="text-lg md:text-xl font-bold leading-tight truncate">{customer.name}</h1>
              <p className="text-[11px] text-white/70">CPF {customer.cpf ? formatCpf(customer.cpf) : "-"}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button onClick={() => refetch()} variant="ghost" size="sm" className="text-white hover:bg-white/10" disabled={isFetching} title="Atualizar">
              <RefreshCw size={16} className={isFetching ? "animate-spin" : ""} />
            </Button>
            <Button onClick={handleLogout} variant="ghost" size="sm" className="text-white hover:bg-white/10 gap-1">
              <LogOut size={16} /> Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-8 mt-6 space-y-6">
        {/* Hero — total devido + limite + próxima parcela */}
        <motion.div
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          <Card className="md:col-span-2 bg-gradient-to-br from-[#C84D8A] to-[#7D2958] text-white border-0 shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 text-white/80 text-xs uppercase tracking-wider font-bold">
                <Wallet size={14} /> Total em aberto
              </div>
              <div className="text-4xl md:text-5xl font-extrabold mt-2">{brl(summary.totalOwed)}</div>
              <div className="text-sm text-white/80 mt-2">
                {summary.pendingCount} parcela{summary.pendingCount === 1 ? "" : "s"} pendente{summary.pendingCount === 1 ? "" : "s"} ·
                {" "}{summary.paidCount} já paga{summary.paidCount === 1 ? "" : "s"}
              </div>

              {Number((customer as any).credit_limit) > 0 && (
                <div className="mt-5 pt-5 border-t border-white/15">
                  <div className="flex items-center justify-between text-xs text-white/80 font-bold uppercase tracking-wider">
                    <span>Limite disponível</span>
                    <span>{brl(Math.max(0, Number((customer as any).credit_limit) - summary.totalOwed))} / {brl(Number((customer as any).credit_limit))}</span>
                  </div>
                  <div className="mt-2 h-2 rounded-full bg-white/15 overflow-hidden">
                    <div
                      className="h-full bg-white rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, Math.max(0, ((Number((customer as any).credit_limit) - summary.totalOwed) / Number((customer as any).credit_limit)) * 100))}%`,
                      }}
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-white border-[#EAEAEA] shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 text-[#6B6B6B] text-xs uppercase tracking-wider font-bold">
                <CalendarClock size={14} /> A pagar este mês
              </div>
              {(() => {
                const currentMonth = `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, "0")}`;
                const unpaid = sortedInstallments.filter((i: any) => i.status !== "paid");
                const thisMonth = unpaid.filter((i: any) => getMonthValue(i.due_date) === currentMonth);
                const monthTotal = thisMonth.reduce((s: number, i: any) => s + Number(i.amount), 0);
                const remainingTotal = unpaid.reduce((s: number, i: any) => s + Number(i.amount), 0);
                if (unpaid.length === 0) {
                  return (
                    <div className="mt-4 flex items-center gap-2 text-emerald-600 font-bold">
                      <CheckCircle2 size={18} /> Tudo em dia!
                    </div>
                  );
                }
                return (
                  <>
                    <div className="text-3xl md:text-4xl font-extrabold text-[#C84D8A] mt-2">{brl(monthTotal)}</div>
                    <div className="text-xs text-[#6B6B6B] mt-1">
                      {thisMonth.length > 0
                        ? <>{thisMonth.length} parcela{thisMonth.length === 1 ? "" : "s"} no mês de {formatMonth(currentMonth)}</>
                        : <>Sem parcelas neste mês{summary.nextInstallment ? <>. Próxima vence em <strong className="text-[#C84D8A]">{formatDate(summary.nextInstallment.due_date)}</strong></> : null}</>}
                    </div>
                    <div className="mt-3 pt-3 border-t border-[#EAEAEA]">
                      <div className="text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">Total restante a pagar</div>
                      <div className="text-xl font-extrabold text-[#7D2958] mt-1">{brl(remainingTotal)}</div>
                      <div className="text-xs text-[#6B6B6B] mt-1">
                        {unpaid.length} parcela{unpaid.length === 1 ? "" : "s"} no total
                      </div>
                    </div>
                  </>
                );
              })()}
            </CardContent>
          </Card>

          
        </motion.div>


        <Tabs defaultValue="historico" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white border border-[#EAEAEA] p-1 h-auto rounded-xl">
            <TabsTrigger value="historico" className="data-[state=active]:bg-[#7D2958] data-[state=active]:text-white rounded-lg py-2.5 gap-2">
              <History size={16} /> <span className="hidden sm:inline">Histórico</span>
            </TabsTrigger>
            <TabsTrigger value="qrcode" className="data-[state=active]:bg-[#7D2958] data-[state=active]:text-white rounded-lg py-2.5 gap-2">
              <QrCode size={16} /> <span className="hidden sm:inline">QR Code</span>
            </TabsTrigger>
            <TabsTrigger value="perfil" className="data-[state=active]:bg-[#7D2958] data-[state=active]:text-white rounded-lg py-2.5 gap-2">
              <UserIcon size={16} /> <span className="hidden sm:inline">Meu Perfil</span>
            </TabsTrigger>
          </TabsList>

          {/* HISTÓRICO */}
          <TabsContent value="historico" className="mt-4">
            <Card className="bg-white border-[#EAEAEA] shadow-md">
              <CardContent className="p-0">
                <div className="px-6 py-4 border-b border-[#EAEAEA] flex flex-col gap-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Receipt size={18} className="text-[#C84D8A]" />
                      <h2 className="font-bold text-[#2A2A2A]">Histórico</h2>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFiltersOpen((open) => !open)}
                      className="border-[#EAEAEA] text-[#7D2958] hover:bg-[#FAF6F7] gap-1.5"
                    >
                      <Filter size={15} /> Filtro
                    </Button>
                  </div>

                  {filtersOpen && (
                    <div className="grid gap-3 md:grid-cols-3">
                      <Select value={monthFilter} onValueChange={setMonthFilter}>
                        <SelectTrigger className="h-11 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectValue placeholder="Mês" />
                        </SelectTrigger>
                        <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectItem value="all">Todos os meses</SelectItem>
                          {monthOptions.map((month) => (
                            <SelectItem key={month} value={month}>{formatMonth(month)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={storeFilter} onValueChange={setStoreFilter}>
                        <SelectTrigger className="h-11 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectValue placeholder="Loja" />
                        </SelectTrigger>
                        <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectItem value="all">Todas as lojas</SelectItem>
                          {storeOptions.map((store) => (
                            <SelectItem key={store} value={store}>{store}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                        <SelectTrigger className="h-11 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectValue placeholder="Pagamento" />
                        </SelectTrigger>
                        <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                          <SelectItem value="all">Todos os pagamentos</SelectItem>
                          <SelectItem value="next">Próximo pagamento</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div className="grid gap-3 sm:grid-cols-3">
                    <div className="rounded-xl bg-[#FAF6F7] border border-[#EAEAEA] px-4 py-3">
                      <div className="text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">Total do período</div>
                      <div className="text-xl font-extrabold text-[#2A2A2A] mt-1">{brl(filteredTotal)}</div>
                    </div>
                    <div className="rounded-xl bg-[#FAF6F7] border border-[#EAEAEA] px-4 py-3">
                      <div className="text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">Em aberto no filtro</div>
                      <div className="text-xl font-extrabold text-[#7D2958] mt-1">{brl(filteredOpenTotal)}</div>
                    </div>
                    <div className="rounded-xl bg-[#FAF6F7] border border-[#EAEAEA] px-4 py-3">
                      <div className="text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">Parcelas encontradas</div>
                      <div className="text-xl font-extrabold text-[#2A2A2A] mt-1">{filteredInstallments.length}</div>
                    </div>
                  </div>
                </div>
                {installments.length === 0 ? (
                  <div className="p-10 text-center text-[#6B6B6B]">Nenhuma compra registrada ainda.</div>
                ) : filteredInstallments.length === 0 ? (
                  <div className="p-10 text-center text-[#6B6B6B]">Nenhum pagamento encontrado para esse filtro.</div>
                ) : (
                  <div className="divide-y divide-[#EAEAEA]">
                    {Object.entries(groupedInstallments).map(([month, monthItems]) => (
                      <section key={month} className="px-4 md:px-6 py-5">
                        <div className="flex items-center justify-between gap-3 mb-3">
                          <h3 className="font-extrabold text-[#2A2A2A] capitalize">{month === "sem-data" ? "Sem vencimento" : formatMonth(month)}</h3>
                          <Badge className="bg-[#C84D8A]/10 text-[#7D2958] border border-[#C84D8A]/30">
                            {brl(monthItems.reduce((s: number, i: any) => s + Number(i.amount), 0))}
                          </Badge>
                        </div>
                        <ul className="space-y-3">
                          {monthItems.map((i: any) => {
                            const paid = i.status === "paid";
                            const overdue = !paid && new Date(i.due_date) < new Date();
                            const installmentTotal = i.loans?.installments_count || i.number;
                            return (
                              <li key={i.id} className="rounded-xl border border-[#EAEAEA] bg-[#FAF6F7] px-4 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                                <div className="min-w-0 space-y-1">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="font-extrabold text-[#2A2A2A]">Parcela {i.number}/{installmentTotal}</span>
                                    {paid ? (
                                      <Badge className="bg-emerald-500/10 text-emerald-700 border border-emerald-500/30">
                                        <CheckCircle2 size={12} className="mr-1" /> Paga
                                      </Badge>
                                    ) : overdue ? (
                                      <Badge className="bg-red-500/10 text-red-700 border border-red-500/30">
                                        <AlertCircle size={12} className="mr-1" /> Atrasada
                                      </Badge>
                                    ) : (
                                      <Badge className="bg-[#C84D8A]/10 text-[#7D2958] border border-[#C84D8A]/30">
                                        Em aberto
                                      </Badge>
                                    )}
                                  </div>
                                  <div className="text-xs text-[#6B6B6B] flex flex-wrap items-center gap-x-3 gap-y-1">
                                    <span className="inline-flex items-center gap-1"><CalendarClock size={12} /> Vence {formatDate(i.due_date)}</span>
                                    {i.loans?.store_name ? <span className="inline-flex items-center gap-1"><Store size={12} /> {i.loans.store_name}</span> : null}
                                    {paid && i.paid_at ? <span>Paga em {formatDate(i.paid_at)}</span> : null}
                                  </div>
                                </div>
                                <div className="text-left sm:text-right shrink-0">
                                  <div className="text-lg font-extrabold text-[#2A2A2A]">{brl(Number(i.amount))}</div>
                                  <div className="text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">Valor da parcela</div>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </section>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* QR CODE */}
          <TabsContent value="qrcode" className="mt-4">
            <Card className="bg-white border-[#EAEAEA] shadow-md">
              <CardContent className="p-8 flex flex-col items-center text-center">
                <h3 className="text-xl font-bold text-[#2A2A2A]">QR Code de autorização</h3>
                <p className="text-sm text-[#6B6B6B] mt-2 max-w-sm">
                  Mostre este código para a loja escanear no momento da compra.
                </p>
                <div className="mt-6 p-5 bg-white rounded-2xl border-2 border-[#C84D8A]/30 shadow-sm">
                  <QRCodeSVG
                    value={`vp:cust:${customer.id}`}
                    size={240}
                    level="H"
                    bgColor="#FFFFFF"
                    fgColor="#7D2958"
                  />
                </div>
                <div className="mt-4 text-[11px] uppercase tracking-wider text-[#6B6B6B] font-bold">
                  Código do cliente
                </div>
                <div className="text-xs text-[#2A2A2A] font-mono break-all max-w-xs mt-1">
                  {customer.id}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* PERFIL */}
          <TabsContent value="perfil" className="mt-4">
            <Card className="bg-white border-[#EAEAEA] shadow-md">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center gap-4 pb-4 border-b border-[#EAEAEA]">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden bg-gradient-to-br from-[#C84D8A] to-[#7D2958] flex items-center justify-center text-white font-extrabold text-2xl shrink-0">
                    {(customer as any).avatar_signed_url ? (
                      <img src={(customer as any).avatar_signed_url} alt={customer.name} className="w-full h-full object-cover" />
                    ) : (
                      customer.name?.[0]?.toUpperCase() ?? "?"
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-lg font-bold text-[#2A2A2A] truncate">{customer.name}</div>
                    <div className="text-xs text-[#6B6B6B]">Cliente VeraPay</div>
                  </div>
                  <Link
                    to={"/cliente/perfil" as any}
                    className="text-xs font-bold text-[#C84D8A] hover:text-[#7D2958] hover:underline shrink-0"
                  >
                    Editar perfil
                  </Link>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <ProfileRow icon={<UserIcon size={14} />} label="CPF" value={customer.cpf ? formatCpf(customer.cpf) : "-"} />
                  <ProfileRow icon={<Mail size={14} />} label="E-mail" value={(customer as any).email || "-"} />
                  <ProfileRow icon={<Phone size={14} />} label="Telefone" value={(customer as any).phone || "-"} />
                  <ProfileRow icon={<Wallet size={14} />} label="Limite total" value={brl(Number((customer as any).credit_limit) || 0)} />
                  <ProfileRow icon={<Wallet size={14} />} label="Total em aberto" value={brl(summary.totalOwed)} />
                  <ProfileRow icon={<CheckCircle2 size={14} />} label="Limite disponível" value={brl(Math.max(0, (Number((customer as any).credit_limit) || 0) - summary.totalOwed))} />
                </div>

                <p className="text-[11px] text-[#6B6B6B] pt-2">
                  Para alterar CPF ou limite, fale com a loja onde você fez a compra.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <p className="text-[11px] text-center text-[#6B6B6B]">
          Pago algo e não apareceu aqui? Avise a loja — eles atualizam para você.
        </p>
      </main>
    </div>
  );
}

function ProfileRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-[#FAF6F7] border border-[#EAEAEA] px-4 py-3">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold text-[#6B6B6B]">
        {icon} {label}
      </div>
      <div className="text-sm font-bold text-[#2A2A2A] mt-1 truncate">{value}</div>
    </div>
  );
}

function ClienteFechamentoCard({ customerId }: { customerId: string }) {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;
  const monthLabel = now.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });

  const { data: closing, refetch } = useQuery({
    queryKey: ["cliente-closing", customerId, year, month],
    queryFn: async () => {
      const { data } = await supabase
        .from("customer_month_closings")
        .select("*")
        .eq("customer_id", customerId)
        .eq("year", year)
        .eq("month", month)
        .maybeSingle();
      return data;
    },
  });

  const [busy, setBusy] = useState(false);
  const isClosed = !!closing;

  const handleClose = async () => {
    if (!confirm(`Fechar sua nota de ${monthLabel}? Você só poderá fazer novas compras no próximo mês.`)) return;
    setBusy(true);
    const { error } = await supabase.from("customer_month_closings").insert({
      customer_id: customerId,
      user_id: (closing as any)?.user_id ?? undefined,
      year,
      month,
      closed_by_role: "client",
    } as any);
    setBusy(false);
    if (error) {
      toast.error("Não foi possível fechar: " + error.message);
      return;
    }
    toast.success("Sua nota foi fechada!");
    refetch();
  };

  return (
    <Card className="bg-white border-[#EAEAEA] shadow-md mt-4">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 text-[#6B6B6B] text-xs uppercase tracking-wider font-bold">
          <Receipt size={14} /> Fechamento da Nota — {monthLabel}
        </div>
        {isClosed ? (
          <div className="mt-3 space-y-2">
            <Badge className="bg-rose-500/15 text-rose-600 border-rose-500/30">
              <CheckCircle2 className="size-3 mr-1" /> Nota fechada
            </Badge>
            <p className="text-xs text-[#6B6B6B]">
              Fechada em {new Date(closing!.closed_at).toLocaleDateString("pt-BR")}.
              Para reabrir, peça à loja ou faça uma nova compra no próximo mês.
            </p>
          </div>
        ) : (
          <div className="mt-3 space-y-3">
            <p className="text-sm text-[#2A2A2A]">
              Quer encerrar sua nota deste mês? Faça o pagamento na loja e depois clique em "Fechar minha nota".
            </p>
            <Button
              onClick={handleClose}
              disabled={busy}
              className="bg-[#7D2958] hover:bg-[#7D2958]/90 text-white"
            >
              {busy ? <Loader2 className="size-4 mr-2 animate-spin" /> : <CheckCircle2 className="size-4 mr-2" />}
              Fechar minha nota deste mês
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
