import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listStores, createStore, updateStore, deleteStore, getStoreReport, createStoreLogin, removeStoreLogin, updateStoreLoginPassword } from "../serverFunctions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Store, Plus, Loader2, BarChart3, Pencil, Trash2, Percent, FileText, TrendingUp, AlertCircle, Wallet, KeyRound, LogIn, Copy } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/lojas")({
  component: LojasPage,
});

const brl = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(n) || 0);

function LojasPage() {
  const qc = useQueryClient();
  const { data: stores, isLoading } = useQuery({
    queryKey: ["stores-list"],
    queryFn: () => listStores(),
  });

  const [openForm, setOpenForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [name, setName] = useState("");
  const [commission, setCommission] = useState<number>(0);

  const [reportFor, setReportFor] = useState<string | null>(null);
  const { data: report, isFetching: loadingReport } = useQuery({
    queryKey: ["store-report", reportFor],
    queryFn: () => getStoreReport({ data: { storeName: reportFor! } }),
    enabled: !!reportFor,
  });

  const createMut = useMutation({
    mutationFn: (vars: any) => createStore({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stores-list"] });
      toast.success("Loja cadastrada!");
      closeForm();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const updateMut = useMutation({
    mutationFn: (vars: any) => updateStore({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stores-list"] });
      toast.success("Loja atualizada!");
      closeForm();
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteStore({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stores-list"] });
      toast.success("Loja removida!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  // Login management
  const [loginFor, setLoginFor] = useState<any>(null);
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const createLoginMut = useMutation({
    mutationFn: (vars: any) => createStoreLogin({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stores-list"] });
      toast.success("Acesso da loja criado!");
      setLoginFor(null);
      setLoginUsername("");
      setLoginPassword("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const removeLoginMut = useMutation({
    mutationFn: (storeId: string) => removeStoreLogin({ data: { storeId } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["stores-list"] });
      toast.success("Acesso removido.");
    },
    onError: (e: any) => toast.error(e.message),
  });

  // Reset password
  const [pwdFor, setPwdFor] = useState<any>(null);
  const [newPassword, setNewPassword] = useState("");
  const resetPwdMut = useMutation({
    mutationFn: (vars: { storeId: string; password: string }) => updateStoreLoginPassword({ data: vars }),
    onSuccess: () => {
      toast.success("Senha atualizada com sucesso!");
      setPwdFor(null);
      setNewPassword("");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const openCreate = () => {
    setEditing(null);
    setName("");
    setCommission(0);
    setOpenForm(true);
  };

  const openEdit = (s: any) => {
    setEditing(s);
    setName(s.name);
    setCommission(Number(s.commission_percent || 0));
    setOpenForm(true);
  };

  const closeForm = () => {
    setOpenForm(false);
    setEditing(null);
    setName("");
    setCommission(0);
  };

  const submit = () => {
    if (!name.trim()) {
      toast.error("Informe o nome da loja");
      return;
    }
    if (editing) {
      updateMut.mutate({ id: editing.id, name: name.trim(), commissionPercent: commission });
    } else {
      createMut.mutate({ name: name.trim(), commissionPercent: commission });
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-black tracking-tighter text-[#2A2A2A] uppercase">
            Minhas <span className="gold-text">Lojas</span>
          </h1>
          <p className="text-[#6B6B6B] font-medium italic">Cadastre lojas e gerencie comissões.</p>
        </div>
        <Button onClick={openCreate} className="btn-primary uppercase font-black text-[11px] tracking-widest h-12 px-6 rounded-2xl text-[#7D2958]">
          <Plus className="mr-2" size={16} /> Cadastrar Loja
        </Button>
      </div>

      {isLoading ? (
        <div className="h-40 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
      ) : (stores || []).length === 0 ? (
        <Card className="rounded-[32px] border-[#EAEAEA] bg-white p-16 text-center">
          <Store className="mx-auto text-[#C84D8A] mb-4" size={48} />
          <p className="text-[#6B6B6B] font-bold uppercase tracking-widest text-sm">Nenhuma loja cadastrada</p>
          <p className="text-[#6B6B6B] text-sm mt-2">Clique em "Cadastrar Loja" para começar.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(stores || []).map((s: any) => (
            <Card key={s.id} className="rounded-[28px] border-[#EAEAEA] bg-white shadow-md hover:shadow-xl transition-shadow">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-12 h-12 rounded-2xl bg-[#F5EBEF] flex items-center justify-center text-[#C84D8A] shrink-0">
                      <Store size={22} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-black text-[#2A2A2A] truncate">{s.name}</h3>
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        <Badge className="bg-[#C84D8A]/10 text-[#7D2958] border border-[#C84D8A]/30">
                          <Percent size={10} className="mr-1" />
                          {Number(s.commission_percent || 0).toFixed(2)}%
                        </Badge>
                        {s.username ? (
                          <Badge className="bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <LogIn size={10} className="mr-1" /> {s.username}
                          </Badge>
                        ) : (
                          <Badge className="bg-amber-50 text-amber-700 border border-amber-200">sem acesso</Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 pt-2 border-t border-[#EAEAEA]">
                  <Button size="sm" variant="outline" className="rounded-xl border-[#EAEAEA] text-[#7D2958]" onClick={() => setReportFor(s.name)}>
                    <BarChart3 size={14} className="mr-1.5" /> Relatório
                  </Button>
                  {s.username ? (
                    <>
                      <Button size="sm" variant="ghost" className="rounded-xl text-[#7D2958] hover:bg-[#F5EBEF]"
                        onClick={() => { setPwdFor(s); setNewPassword(""); }}>
                        <KeyRound size={14} className="mr-1" /> Trocar senha
                      </Button>
                      <Button size="sm" variant="ghost" className="rounded-xl text-amber-600 hover:bg-amber-50"
                        onClick={() => {
                          if (confirm(`Remover o acesso da loja "${s.name}"?`)) removeLoginMut.mutate(s.id);
                        }}>
                        <KeyRound size={14} className="mr-1" /> Remover acesso
                      </Button>
                    </>
                  ) : (
                    <Button size="sm" variant="ghost" className="rounded-xl text-emerald-700 hover:bg-emerald-50"
                      onClick={() => { setLoginFor(s); setLoginUsername(s.name.toLowerCase().replace(/[^a-z0-9]+/g, "")); setLoginPassword(""); }}>
                      <KeyRound size={14} className="mr-1" /> Criar acesso
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="rounded-xl text-[#6B6B6B]" onClick={() => openEdit(s)}>
                    <Pencil size={14} />
                  </Button>
                  <Button size="sm" variant="ghost" className="rounded-xl text-rose-500 hover:bg-rose-500/10"
                    onClick={() => {
                      if (confirm(`Remover a loja "${s.name}"?`)) deleteMut.mutate(s.id);
                    }}>
                    <Trash2 size={14} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create / Edit dialog */}
      <Dialog open={openForm} onOpenChange={(o) => !o && closeForm()}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[420px] bg-white border-[#EAEAEA] text-[#2A2A2A] rounded-[32px] p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase tracking-tighter">
              {editing ? "Editar Loja" : "Cadastrar Loja"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-4">
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Nome da loja</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Colmeia" className="h-12 bg-[#F5EBEF] border-[#EAEAEA] rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Comissão % (opcional)</Label>
              <div className="relative">
                <Input type="number" step="0.01" min="0" max="100" value={commission || ""}
                  onChange={(e) => setCommission(Number(e.target.value))}
                  placeholder="0" className="h-12 bg-[#F5EBEF] border-[#EAEAEA] rounded-xl pr-10" />
                <Percent className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" size={16} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeForm} className="rounded-xl">Cancelar</Button>
            <Button onClick={submit} disabled={createMut.isPending || updateMut.isPending} className="btn-primary text-[#7D2958] rounded-xl font-black uppercase">
              {(createMut.isPending || updateMut.isPending) && <Loader2 className="animate-spin mr-2" size={16} />}
              {editing ? "Salvar" : "Cadastrar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Report dialog */}
      <Dialog open={!!reportFor} onOpenChange={(o) => !o && setReportFor(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[560px] bg-white border-[#EAEAEA] text-[#2A2A2A] rounded-[32px] p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase tracking-tighter">
              Relatório · {reportFor}
            </DialogTitle>
          </DialogHeader>
          {loadingReport || !report ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="animate-spin text-[#C84D8A]" size={32} />
            </div>
          ) : (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <Stat icon={FileText} label="Vendas" value={report.loansCount} />
                <Stat icon={Wallet} label="Total Vendido" value={brl(report.totalSold)} />
                <Stat icon={TrendingUp} label="Recebido" value={brl(report.totalReceived)} accent="emerald" />
                <Stat icon={AlertCircle} label="Pendente" value={brl(report.totalPending)} accent="amber" />
                <Stat icon={AlertCircle} label="Atrasado" value={brl(report.totalOverdue)} accent="rose" />
                <Stat icon={Wallet} label="Taxa Cartão" value={brl(report.totalCardFee)} />
              </div>
              <div className="rounded-2xl bg-[#F5EBEF] border border-[#EAEAEA] p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-black uppercase tracking-widest text-[#6B6B6B]">Comissão ({Number(report.commissionPercent).toFixed(2)}%)</div>
                    <div className="text-2xl font-extrabold text-[#7D2958] mt-1">{brl(report.commissionValue)}</div>
                  </div>
                  <Badge className="bg-white border border-[#EAEAEA] text-[#2A2A2A] px-3 py-2">
                    Líquido: {brl(report.netReceived)}
                  </Badge>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setReportFor(null)} className="rounded-xl">Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create login dialog */}
      <Dialog open={!!loginFor} onOpenChange={(o) => !o && setLoginFor(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[440px] bg-white border-[#EAEAEA] text-[#2A2A2A] rounded-[32px] p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase tracking-tighter">
              Criar acesso · {loginFor?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-4">
            <div className="rounded-2xl bg-[#F5EBEF] border border-[#C84D8A]/20 p-4 text-xs text-[#7D2958]">
              A loja entra em <strong>/loja/login</strong> com este usuário e senha. Só conseguirá <strong>adicionar compras</strong> aos seus clientes.
              <button
                type="button"
                onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/loja/login`); toast.success("Link copiado"); }}
                className="ml-2 inline-flex items-center gap-1 underline font-bold"
              ><Copy size={11} /> copiar link</button>
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Usuário</Label>
              <Input
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, ""))}
                placeholder="ex: colmeia"
                className="h-12 bg-[#F5EBEF] border-[#EAEAEA] rounded-xl"
              />
              <p className="text-[10px] text-[#6B6B6B]">Só letras e números, sem espaço.</p>
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Senha (mín. 6)</Label>
              <Input
                type="text"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="senha123"
                className="h-12 bg-[#F5EBEF] border-[#EAEAEA] rounded-xl"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLoginFor(null)} className="rounded-xl">Cancelar</Button>
            <Button
              onClick={() => createLoginMut.mutate({ storeId: loginFor.id, username: loginUsername, password: loginPassword })}
              disabled={createLoginMut.isPending}
              className="btn-primary text-[#7D2958] rounded-xl font-black uppercase"
            >
              {createLoginMut.isPending && <Loader2 className="animate-spin mr-2" size={16} />}
              Criar acesso
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset password dialog */}
      <Dialog open={!!pwdFor} onOpenChange={(o) => { if (!o) { setPwdFor(null); setNewPassword(""); } }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[420px] bg-white border-[#EAEAEA] text-[#2A2A2A] rounded-[32px] p-8">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black text-[#C84D8A] uppercase tracking-tighter">
              Trocar senha · {pwdFor?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5 py-4">
            <div className="rounded-2xl bg-[#F5EBEF] border border-[#C84D8A]/20 p-4 text-xs text-[#7D2958]">
              A nova senha substitui a atual imediatamente. Usuário <strong>{pwdFor?.username}</strong> continua o mesmo.
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">Nova senha (mín. 6)</Label>
              <Input
                type="text"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="novasenha123"
                className="h-12 bg-[#F5EBEF] border-[#EAEAEA] rounded-xl"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setPwdFor(null); setNewPassword(""); }} className="rounded-xl">Cancelar</Button>
            <Button
              onClick={() => resetPwdMut.mutate({ storeId: pwdFor.id, password: newPassword })}
              disabled={resetPwdMut.isPending || newPassword.length < 6}
              className="btn-primary text-[#7D2958] rounded-xl font-black uppercase"
            >
              {resetPwdMut.isPending && <Loader2 className="animate-spin mr-2" size={16} />}
              Salvar nova senha
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stat({ icon: Icon, label, value, accent }: { icon: any; label: string; value: any; accent?: string }) {
  const color =
    accent === "emerald" ? "text-emerald-600" :
    accent === "amber" ? "text-amber-600" :
    accent === "rose" ? "text-rose-500" :
    "text-[#2A2A2A]";
  return (
    <div className="rounded-2xl bg-[#FAF6F7] border border-[#EAEAEA] p-4">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-bold text-[#6B6B6B]">
        <Icon size={12} /> {label}
      </div>
      <div className={`text-lg font-extrabold mt-1 ${color}`}>{value}</div>
    </div>
  );
}
