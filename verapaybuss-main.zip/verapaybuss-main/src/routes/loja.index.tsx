import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getMyStore, storeFindCustomer, storeCreatePurchase, storeListRecentPurchases, storeListMonthlyPurchases, storeRequestLimit } from "../serverFunctions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Store, LogOut, ScanLine, Loader2, ShoppingBag, Check, X, User as UserIcon, Camera, AlertTriangle, Send, CalendarDays } from "lucide-react";
import { formatCpf } from "@/lib/cpf";

export const Route = createFileRoute("/loja/")({
  ssr: false,
  component: LojaDashboard,
});

const brl = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(n) || 0);

function LojaDashboard() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate({ to: "/loja/login" as any });
        return;
      }
      setReady(true);
    })();
  }, [navigate]);

  const storeQuery = useQuery({
    queryKey: ["my-store"],
    queryFn: () => getMyStore(),
    enabled: ready,
    retry: false,
  });

  const recentQuery = useQuery({
    queryKey: ["store-recent"],
    queryFn: () => storeListRecentPurchases(),
    enabled: ready && !!storeQuery.data,
  });

  const monthlyQuery = useQuery({
    queryKey: ["store-monthly"],
    queryFn: () => storeListMonthlyPurchases(),
    enabled: ready && !!storeQuery.data,
  });


  const [scanning, setScanning] = useState(false);
  const [customer, setCustomer] = useState<any>(null);
  const [amount, setAmount] = useState<string>("");
  const [orderNumber, setOrderNumber] = useState("");
  const [deliveryNote, setDeliveryNote] = useState("");
  const [notes, setNotes] = useState("");
  const [manualId, setManualId] = useState("");
  const scannerRef = useRef<any>(null);
  const scannerDivId = "loja-qr-scanner";
  const activeStoreId = (storeQuery.data as { id?: string } | undefined)?.id;

  const findMut = useMutation({
    mutationFn: (customerId: string) => storeFindCustomer({ data: { customerId } }),
    onSuccess: (res: any) => {
      setCustomer({ ...res.customer, _limits: { creditLimit: res.creditLimit, usedAmount: res.usedAmount, availableLimit: res.availableLimit } });
      toast.success(`Cliente: ${res.customer.name}`, {
        description: `Limite disponível: ${brl(res.availableLimit)}`,
      });
    },
    onError: (e: any) => toast.error(e?.message || "Cliente não encontrado."),
  });

  const handledLimitResponsesRef = useRef<Set<string>>(new Set());

  // Realtime: when admin responds to a limit request, refresh the active customer's limits instantly
  useEffect(() => {
    if (!customer?.id) return;
    let active = true;
    const activeCustomerId = customer.id;

    const refreshActiveCustomer = async (message?: string) => {
      try {
        const res: any = await storeFindCustomer({ data: { customerId: activeCustomerId } });
        if (!active) return;
        setCustomer((prev: any) => {
          if (!prev || prev.id !== activeCustomerId) return prev;
          return {
            ...res.customer,
            _limits: {
              creditLimit: res.creditLimit,
              usedAmount: res.usedAmount,
              availableLimit: res.availableLimit,
            },
          };
        });
        if (message) {
          toast.success(message, {
            description: `Disponível agora: ${brl(Number(res.availableLimit || 0))}`,
            duration: 9000,
          });
        }
      } catch (error: any) {
        if (active) toast.error(error?.message || "Não foi possível atualizar o limite do cliente.");
      }
    };

    const channel = supabase
      .channel(`store-customer-${activeCustomerId}-${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "customers", filter: `id=eq.${activeCustomerId}` },
        (payload: any) => {
          const previousLimit = Number(payload.old?.credit_limit || 0);
          const nextLimit = Number(payload.new?.credit_limit || 0);
          if (nextLimit !== previousLimit) {
            refreshActiveCustomer();
          } else {
            refreshActiveCustomer();
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "limit_requests", filter: `customer_id=eq.${activeCustomerId}` },
        (payload: any) => {
          const requestId = String(payload.new?.id || "");
          const status = payload.new?.status;
          if (!requestId || handledLimitResponsesRef.current.has(requestId)) return;
          if (status === "approved") {
            handledLimitResponsesRef.current.add(requestId);
            refreshActiveCustomer("Solicitação aprovada — limite atualizado!");
          } else if (status === "rejected") {
            handledLimitResponsesRef.current.add(requestId);
            refreshActiveCustomer();
            toast.error("Solicitação de limite rejeitada pelo administrador.", {
              description: payload.new?.response_note || "Confira com a administradora antes de concluir a venda.",
              duration: 9000,
            });
          }
        }
      )
      .subscribe();
    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [customer?.id]);

  // Realtime: notify the store about approved/rejected requests even when no customer is open
  useEffect(() => {
    if (!activeStoreId || customer?.id) return;
    const channel = supabase
      .channel(`store-limit-requests-${activeStoreId}-${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "limit_requests", filter: `store_id=eq.${activeStoreId}` },
        (payload: any) => {
          const requestId = String(payload.new?.id || "");
          const status = payload.new?.status;
          if (!requestId || handledLimitResponsesRef.current.has(requestId)) return;
          if (status === "approved") {
            handledLimitResponsesRef.current.add(requestId);
            toast.success("Liberação de limite aprovada!", {
              description: "Identifique o cliente novamente para ver o limite atualizado.",
              duration: 9000,
            });
          } else if (status === "rejected") {
            handledLimitResponsesRef.current.add(requestId);
            toast.error("Solicitação de limite rejeitada pelo administrador.", {
              description: payload.new?.response_note || "Confira com a administradora antes de concluir a venda.",
              duration: 9000,
            });
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeStoreId, customer?.id]);


  const [requestOpen, setRequestOpen] = useState(false);
  const [requestAmount, setRequestAmount] = useState("");
  const [requestReason, setRequestReason] = useState("");
  const requestMut = useMutation({
    mutationFn: (vars: { customerId: string; requestedAmount: number; purchaseAmount?: number; reason?: string }) =>
      storeRequestLimit({ data: vars }),
    onSuccess: () => {
      toast.success("Solicitação enviada ao administrador!");
      setRequestOpen(false);
      setRequestAmount("");
      setRequestReason("");
    },
    onError: (e: any) => toast.error(e?.message || "Falha ao enviar solicitação."),
  });

  const purchaseMut = useMutation({
    mutationFn: (vars: { customerId: string; totalAmount: number; orderNumber?: string; deliveryNote?: string; notes?: string }) =>
      storeCreatePurchase({ data: vars }),
    onSuccess: (res: any) => {
      toast.success("Compra realizada com sucesso!", {
        description: res?.temporaryReleaseConsumed
          ? "A liberação temporária foi usada e o limite base voltou ao normal."
          : "O cliente já pode conferir em Histórico.",
        duration: 9000,
      });
      setCustomer(null);
      setAmount("");
      setOrderNumber("");
      setDeliveryNote("");
      setNotes("");
      qc.invalidateQueries({ queryKey: ["store-recent"] });
      qc.invalidateQueries({ queryKey: ["store-monthly"] });

    },
    onError: (e: any) => toast.error(e?.message || "Falha ao cadastrar compra."),
  });

  const stopScanner = async () => {
    if (scannerRef.current) {
      try { await scannerRef.current.stop(); } catch {}
      try { await scannerRef.current.clear(); } catch {}
      scannerRef.current = null;
    }
    setScanning(false);
  };

  const startScanner = async () => {
    setScanning(true);
    setTimeout(async () => {
      try {
        const { Html5Qrcode } = await import("html5-qrcode");
        const h = new Html5Qrcode(scannerDivId);
        scannerRef.current = h;
        await h.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: { width: 240, height: 240 } },
          (decodedText: string) => {
            // Accept either plain UUID or vp:cust:<id>
            const m = decodedText.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
            const id = m ? m[1] : decodedText.trim();
            stopScanner();
            findMut.mutate(id);
          },
          () => {}
        );
      } catch (err: any) {
        toast.error("Câmera indisponível", { description: err?.message || "" });
        setScanning(false);
      }
    }, 100);
  };

  useEffect(() => {
    return () => { stopScanner(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogout = async () => {
    await stopScanner();
    await supabase.auth.signOut();
    qc.clear();
    navigate({ to: "/loja/login" as any });
  };

  const submitPurchase = () => {
    const n = Number(String(amount).replace(",", "."));
    if (!customer) return toast.error("Identifique o cliente primeiro.");
    if (!(n > 0)) return toast.error("Informe um valor válido.");
    purchaseMut.mutate({
      customerId: customer.id,
      totalAmount: n,
      orderNumber: orderNumber.trim() || undefined,
      deliveryNote: deliveryNote.trim() || undefined,
      notes: notes.trim() || undefined,
    });
  };

  if (!ready || storeQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7]">
        <Loader2 className="animate-spin text-[#C84D8A]" size={32} />
      </div>
    );
  }

  if (storeQuery.error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7] px-4">
        <Card className="max-w-md border-[#EAEAEA]">
          <CardContent className="p-6 text-center space-y-3">
            <p className="font-bold text-[#2A2A2A]">{(storeQuery.error as any)?.message}</p>
            <Button onClick={handleLogout} variant="outline">Sair</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const store = storeQuery.data as any;
  const installment = Number(String(amount).replace(",", ".")) / 3;

  return (
    <div className="min-h-screen bg-[#FAF6F7] pb-12">
      <header className="bg-[#7D2958] text-white px-4 md:px-8 py-5 shadow-lg">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center"><Store size={18} /></div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest opacity-80">Loja</div>
              <div className="font-black text-lg">{store.name}</div>
            </div>
          </div>
          <Button variant="ghost" onClick={handleLogout} className="text-white hover:bg-white/10 gap-1.5">
            <LogOut size={16} /> Sair
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 md:px-8 mt-6 space-y-6">
        <Card className="bg-white border-[#EAEAEA] shadow-md rounded-3xl">
          <CardContent className="p-6 md:p-8 space-y-6">
            <div>
              <h2 className="text-xl font-black text-[#2A2A2A] uppercase tracking-tighter">Nova compra</h2>
              <p className="text-sm text-[#6B6B6B]">Escaneie o QR code do cliente ou cole o código.</p>
            </div>

            {!customer ? (
              <div className="space-y-4">
                {!scanning ? (
                  <Button onClick={startScanner} className="w-full h-14 btn-primary text-base font-bold flex items-center justify-center gap-2">
                    <Camera size={18} /> Abrir câmera para escanear
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <div id={scannerDivId} className="rounded-2xl overflow-hidden bg-black" />
                    <Button onClick={stopScanner} variant="outline" className="w-full"><X size={16} className="mr-1" /> Cancelar leitura</Button>
                  </div>
                )}

                <div className="flex items-center gap-3 text-xs text-[#6B6B6B]">
                  <div className="h-px flex-1 bg-[#EAEAEA]" /> ou digite o código <div className="h-px flex-1 bg-[#EAEAEA]" />
                </div>
                <div className="flex gap-2">
                  <Input
                    value={manualId}
                    onChange={(e) => setManualId(e.target.value)}
                    placeholder="Cole o ID do cliente"
                    className="h-12 bg-[#FAF6F7] border-[#EAEAEA]"
                  />
                  <Button
                    onClick={() => {
                      const m = manualId.match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
                      const id = m ? m[1] : manualId.trim();
                      if (!id) return toast.error("Informe um ID.");
                      findMut.mutate(id);
                    }}
                    disabled={findMut.isPending}
                    className="h-12 btn-primary px-5"
                  >
                    {findMut.isPending ? <Loader2 className="animate-spin" size={16} /> : <ScanLine size={16} />}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                <div className="rounded-2xl border-2 border-[#C84D8A]/30 bg-[#F5EBEF] p-4 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#7D2958] flex items-center justify-center text-white font-black">
                    {customer.name?.[0]?.toUpperCase() ?? <UserIcon size={18} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-black text-[#2A2A2A] truncate">{customer.name}</div>
                    <div className="text-xs text-[#6B6B6B]">CPF {customer.cpf ? formatCpf(customer.cpf) : "—"}</div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setCustomer(null)} className="text-[#6B6B6B]"><X size={16} /></Button>
                </div>

                {(() => {
                  const lim = customer._limits || { creditLimit: 0, usedAmount: 0, availableLimit: 0 };
                  const purchaseVal = Number(String(amount).replace(",", ".")) || 0;
                  const exceeds = purchaseVal > lim.availableLimit;
                  const noLimit = lim.creditLimit <= 0;
                  return (
                    <div className={`rounded-2xl p-4 border-2 ${exceeds || noLimit ? "border-red-300 bg-red-50" : "border-green-300 bg-green-50"}`}>
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <div className="text-[10px] font-bold uppercase tracking-widest text-[#6B6B6B]">Limite disponível</div>
                          <div className={`text-xl font-black ${exceeds || noLimit ? "text-red-700" : "text-green-700"}`}>{brl(lim.availableLimit)}</div>
                          <div className="text-[11px] text-[#6B6B6B] mt-0.5">de {brl(lim.creditLimit)} · em uso {brl(lim.usedAmount)}</div>
                        </div>
                        {(exceeds || noLimit) && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const neededRelease = Math.max(0, purchaseVal - Number(lim.availableLimit || 0));
                              setRequestAmount(String(neededRelease || purchaseVal || 500));
                              setRequestOpen(true);
                            }}
                            className="gap-1 border-red-300 text-red-700 hover:bg-red-100"
                          >
                            <AlertTriangle size={14} /> Solicitar liberação
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })()}

                <div className="space-y-1.5">
                  <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Valor total da compra</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B] font-bold">R$</span>
                    <Input
                      type="number"
                      inputMode="decimal"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0,00"
                      className="h-14 pl-10 text-2xl font-black text-[#C84D8A] bg-[#FAF6F7] border-[#EAEAEA]"
                    />
                  </div>
                  {Number(amount) > 0 && (
                    <p className="text-xs text-[#6B6B6B]">3x de <span className="font-bold text-[#7D2958]">{brl(installment)}</span> — primeira parcela dia 10 do próximo mês.</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Nº da nota / pedido (opcional)</Label>
                  <Input value={orderNumber} onChange={(e) => setOrderNumber(e.target.value)} placeholder="#0001" className="h-12 bg-[#FAF6F7] border-[#EAEAEA]" />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Nº do romaneio (opcional)</Label>
                  <Input value={deliveryNote} onChange={(e) => setDeliveryNote(e.target.value)} placeholder="Ex: R-1234" className="h-12 bg-[#FAF6F7] border-[#EAEAEA]" />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Observação (opcional)</Label>
                  <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Detalhes adicionais sobre a compra…" rows={3} className="bg-[#FAF6F7] border-[#EAEAEA]" />
                </div>

                <Button
                  onClick={submitPurchase}
                  disabled={purchaseMut.isPending || Number(String(amount).replace(",", ".")) > (customer._limits?.availableLimit ?? 0)}
                  className="w-full h-14 btn-primary text-base font-bold flex items-center justify-center gap-2"
                >
                  {purchaseMut.isPending ? <Loader2 className="animate-spin" size={18} /> : <Check size={18} />}
                  Confirmar compra em 3x
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-white border-[#EAEAEA] shadow-md rounded-3xl">
          <CardContent className="p-6 md:p-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-black text-[#2A2A2A] uppercase tracking-tight flex items-center gap-2">
                <CalendarDays size={18} className="text-[#C84D8A]" /> Compras por mês
              </h3>
              <Badge className="bg-[#F5EBEF] text-[#7D2958] border border-[#C84D8A]/30">{monthlyQuery.data?.length || 0}</Badge>
            </div>
            {monthlyQuery.isLoading ? (
              <div className="h-20 bg-[#F5EBEF] animate-pulse rounded-2xl" />
            ) : !monthlyQuery.data?.length ? (
              <p className="text-sm text-[#6B6B6B] text-center py-6">Nenhuma compra registrada ainda.</p>
            ) : (
              <ul className="divide-y divide-[#EAEAEA]">
                {monthlyQuery.data.map((m: any) => {
                  const [y, mo] = m.month.split("-");
                  const label = new Date(Number(y), Number(mo) - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
                  return (
                    <li key={m.month} className="py-3 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-bold text-[#2A2A2A] capitalize truncate">{label}</div>
                        <div className="text-xs text-[#6B6B6B]">{m.count} {m.count === 1 ? "compra" : "compras"}</div>
                      </div>
                      <div className="font-black text-[#7D2958]">{brl(m.total)}</div>
                    </li>
                  );
                })}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card className="bg-white border-[#EAEAEA] shadow-md rounded-3xl">

          <CardContent className="p-6 md:p-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-black text-[#2A2A2A] uppercase tracking-tight flex items-center gap-2">
                <ShoppingBag size={18} className="text-[#C84D8A]" /> Últimas compras
              </h3>
              <Badge className="bg-[#F5EBEF] text-[#7D2958] border border-[#C84D8A]/30">{recentQuery.data?.length || 0}</Badge>
            </div>
            {recentQuery.isLoading ? (
              <div className="h-20 bg-[#F5EBEF] animate-pulse rounded-2xl" />
            ) : !recentQuery.data?.length ? (
              <p className="text-sm text-[#6B6B6B] text-center py-6">Nenhuma compra ainda.</p>
            ) : (
              <ul className="divide-y divide-[#EAEAEA]">
                {recentQuery.data.map((l: any) => (
                  <li key={l.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-bold text-[#2A2A2A] truncate">{l.customer?.name || "—"}</div>
                      <div className="text-xs text-[#6B6B6B]">{new Date(l.loan_date).toLocaleDateString("pt-BR")} · {l.installments_count}x{l.order_number ? ` · ${l.order_number}` : ""}</div>
                    </div>
                    <div className="font-black text-[#7D2958]">{brl(l.total_amount)}</div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </main>

      <Dialog open={requestOpen} onOpenChange={setRequestOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto bg-white">
          <DialogHeader>
            <DialogTitle className="text-[#7D2958] font-black">Solicitar liberação de limite</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-[#6B6B6B]">
              Cliente: <span className="font-bold text-[#2A2A2A]">{customer?.name}</span><br/>
              Limite atual: <span className="font-bold">{brl(customer?._limits?.creditLimit ?? 0)}</span> · Disponível: <span className="font-bold">{brl(customer?._limits?.availableLimit ?? 0)}</span>
            </p>
            <div className="rounded-xl bg-[#FFF7EB] border border-amber-200 p-3 text-xs text-amber-900">
              A solicitação será enviada ao administrador, que vai analisar o histórico do cliente e definir o valor a liberar.
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-bold uppercase text-[#6B6B6B]">Motivo / observação (opcional)</Label>
              <Input value={requestReason} onChange={(e) => setRequestReason(e.target.value)} placeholder="Ex: cliente bom pagador, compra urgente…" className="h-12 bg-[#FAF6F7] border-[#EAEAEA]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRequestOpen(false)}>Cancelar</Button>
            <Button
              onClick={() => {
                if (!customer) return;
                requestMut.mutate({
                  customerId: customer.id,
                  requestedAmount: 0,
                  purchaseAmount: Number(String(amount).replace(",", ".")) || undefined,
                  reason: requestReason || undefined,
                });
              }}
              disabled={requestMut.isPending}
              className="btn-primary gap-2"
            >
              {requestMut.isPending ? <Loader2 className="animate-spin" size={16} /> : <Send size={16} />}
              Enviar solicitação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
