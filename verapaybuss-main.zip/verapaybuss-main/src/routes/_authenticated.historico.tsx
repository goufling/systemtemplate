import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { getFullPaymentHistory, getCustomers, getActivityLogs } from "../serverFunctions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  Loader2, 
  Search, 
  Calendar, 
  ShoppingBag, 
  User, 
  FileSpreadsheet, 
  FilterX, 
  ArrowRight, 
  UserSearch, 
  History, 
  ShieldCheck, 
  Activity, 
  Eye,
  FileText,
  Image as ImageIcon
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import * as XLSX from "xlsx";
import { motion, AnimatePresence } from "framer-motion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/historico")({
  component: Historico,
});

function Historico() {
  const [search, setSearch] = useState("");
  const [monthFilter, setMonthFilter] = useState<string>("all");
  const [yearFilter, setYearFilter] = useState<string>(format(new Date(), "yyyy"));
  const [selectedCustomerId, setSelectedCustomerId] = useState("all");
  const [authReady, setAuthReady] = useState(false);
  const [hasSession, setHasSession] = useState(false);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!mounted) return;
      setHasSession(Boolean(session));
      setAuthReady(true);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setHasSession(Boolean(session));
      setAuthReady(true);
    });
    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const { data: history, isLoading: historyLoading } = useQuery({
    queryKey: ["fullHistory"],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Não autorizado");
      return getFullPaymentHistory();
    },
    enabled: authReady && hasSession,
    retry: false,
  });

  const { data: customers, isLoading: customersLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Não autorizado");
      return getCustomers();
    },
    enabled: authReady && hasSession,
  });

  const { data: activityLogs, isLoading: logsLoading } = useQuery({
    queryKey: ["activityLogs"],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Não autorizado");
      return getActivityLogs();
    },
    enabled: authReady && hasSession,
  });

  const filteredHistory = useMemo(() => {
    if (!history) return [];
    return history.filter((item: any) => {
      const matchesSearch = !search || item.storeName?.toLowerCase().includes(search.toLowerCase());
      const itemDate = new Date(item.paidAt);
      const matchesMonth = !monthFilter || monthFilter === "all" || format(itemDate, "MM") === monthFilter;
      const matchesYear = !yearFilter || yearFilter === "all" || format(itemDate, "yyyy") === yearFilter;
      const selectedCustomer = customers?.find((c: any) => c.id === selectedCustomerId);
      const matchesCustomer = selectedCustomerId === "all" || item.customerName === selectedCustomer?.name;
      return matchesSearch && matchesMonth && matchesYear && matchesCustomer;
    });
  }, [history, search, monthFilter, yearFilter, selectedCustomerId, customers]);

  const exportToExcel = () => {
    if (!filteredHistory.length) return;
    const dataToExport = filteredHistory.map((item: any) => ({
      "Data Pagamento": format(new Date(item.paidAt), "dd/MM/yyyy HH:mm"),
      "Cliente": item.customerName,
      "Loja": item.storeName,
      "Parcela": item.installmentNumber,
      "Valor": item.amount,
      "Método": item.paymentMethod === 'nota_promissoria' ? 'NOTA PROMISSÓRIA' : item.paymentMethod.toUpperCase(),
      "Detalhes Cheque": item.chequeDetails ? `${item.chequeDetails.bank} - #${item.chequeDetails.number}` : "-"
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Pagamentos");
    XLSX.writeFile(workbook, `Relatorio_VeraPay_${format(new Date(), "ddMMyyyy")}.xlsx`);
  };

  const handleClearFilters = () => {
    setSearch("");
    setMonthFilter("all");
    setYearFilter(format(new Date(), "yyyy"));
    setSelectedCustomerId("all");
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-[#2A2A2A]">Central de <span className="gold-text">Auditoria</span></h1>
          <p className="text-[#6B6B6B] font-medium italic mt-1">Rastreabilidade completa de todas as movimentações do sistema.</p>
        </div>
      </header>

      <Tabs defaultValue="payments" className="w-full">
        <TabsList className="bg-[#FFFFFF] border border-[#EAEAEA] p-1 rounded-2xl h-14 mb-8">
          <TabsTrigger value="payments" className="rounded-xl px-8 data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958] gap-2 font-bold transition-all">
            <History size={18} /> Pagamentos
          </TabsTrigger>
          <TabsTrigger value="activity" className="rounded-xl px-8 data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958] gap-2 font-bold transition-all">
            <Activity size={18} /> Logs do Sistema
          </TabsTrigger>
        </TabsList>

        <TabsContent value="payments" className="space-y-8 animate-in slide-in-from-left-2 duration-300">
          <div className="flex justify-end">
            {filteredHistory.length > 0 && (
              <div className="flex gap-3">
                <Button 
                  onClick={() => {
                    const customer = customers?.find((c: any) => c.id === selectedCustomerId);
                    if (customer) {
                      window.location.href = `/relatorios?customerId=${selectedCustomerId}`;
                    } else {
                      toast.error("Selecione um cliente específico para o relatório");
                    }
                  }}
                  size="lg" 
                  className="bg-[#C84D8A] hover:bg-[#C84D8A]/80 text-[#7D2958] font-bold rounded-xl shadow-lg gap-2 h-12"
                >
                  <FileText size={20} />
                  Puxar Relatório
                </Button>
                <Button onClick={exportToExcel} size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/20 gap-2 h-12">
                  <FileSpreadsheet size={20} />
                  Exportar Excel
                </Button>
              </div>
            )}
          </div>

          <Card className="luxury-card border-none bg-[#FFFFFF] border-[#EAEAEA]">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 items-end">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-[#6B6B6B] ml-1">Cliente</label>
                <Select value={selectedCustomerId} onValueChange={setSelectedCustomerId}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl" disabled={!authReady || customersLoading}>
                    <SelectValue placeholder={customersLoading ? "Carregando..." : "Todos os clientes"} />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectItem value="all">Todos os clientes</SelectItem>
                    {customers?.map((c: any) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-[#6B6B6B] ml-1">Mês</label>
                <Select value={monthFilter} onValueChange={setMonthFilter}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl">
                    <SelectValue placeholder="Mês" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectItem value="all">Todos os meses</SelectItem>
                    {Array.from({ length: 12 }, (_, i) => {
                      const m = (i + 1).toString().padStart(2, '0');
                      return <SelectItem key={m} value={m}>{format(new Date(2024, i, 1), "MMMM", { locale: ptBR })}</SelectItem>
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-[#6B6B6B] ml-1">Ano</label>
                <Select value={yearFilter} onValueChange={setYearFilter}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl">
                    <SelectValue placeholder="Ano" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectItem value="all">Todos os anos</SelectItem>
                    {["2024", "2025", "2026"].map(y => (
                      <SelectItem key={y} value={y}>{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-[#6B6B6B] ml-1">Loja / Venda</label>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6B6B6B]" size={18} />
                  <Input 
                    className="pl-12 h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30 rounded-xl" 
                    placeholder="Ex: Magalu" 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </div>

              <Button onClick={handleClearFilters} variant="outline" className="h-12 gap-2 w-full md:col-span-2 lg:col-span-4 mt-2 rounded-xl border-[#EAEAEA] text-[#6B6B6B] hover:bg-[#F5EBEF]">
                <FilterX size={18} />
                Limpar Filtros
              </Button>
            </div>
          </Card>

          {historyLoading ? (
            <div className="flex h-64 items-center justify-center">
              <Loader2 className="animate-spin text-[#C84D8A]" size={48} />
            </div>
          ) : (
            <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] overflow-hidden shadow-2xl">
              <Table>
                <TableHeader className="bg-[#F5EBEF]">
                  <TableRow className="hover:bg-transparent border-[#EAEAEA]">
                    <TableHead className="py-5 pl-8 font-bold text-[#6B6B6B]">Data</TableHead>
                    <TableHead className="font-bold text-[#6B6B6B]">Cliente</TableHead>
                    <TableHead className="font-bold text-[#6B6B6B]">Loja</TableHead>
                    <TableHead className="font-bold text-[#6B6B6B] text-center">Parc.</TableHead>
                    <TableHead className="font-bold text-[#6B6B6B]">Valor</TableHead>
                    <TableHead className="font-bold text-[#6B6B6B] text-right pr-8">Método</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-20 text-[#6B6B6B] italic">
                        Nenhum registro encontrado.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredHistory.map((item: any) => (
                      <TableRow key={item.id} className="hover:bg-[#F5EBEF]/80 border-[#EAEAEA] transition-colors">
                        <TableCell className="py-5 pl-8">
                          <div className="font-bold text-[#2A2A2A]">{format(new Date(item.paidAt), "dd/MM/yyyy")}</div>
                          <div className="text-[10px] text-[#6B6B6B] font-bold">{format(new Date(item.paidAt), "HH:mm")}</div>
                        </TableCell>
                        <TableCell>
                          <span className="font-bold text-[#2A2A2A]">{item.customerName}</span>
                        </TableCell>
                        <TableCell className="text-[#6B6B6B]">{item.storeName}</TableCell>
                        <TableCell className="text-center">
                          <Badge variant="outline" className="bg-[#F5EBEF] border-[#EAEAEA] text-[#6B6B6B] font-black">{item.installmentNumber}ª</Badge>
                        </TableCell>
                        <TableCell className="font-black text-emerald-400 text-lg">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(item.amount)}
                        </TableCell>
                        <TableCell className="text-right pr-8">
                          <div className="flex items-center justify-end gap-2">
                            {item.proofUrl && (
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-blue-400 hover:bg-blue-400/10 rounded-lg"
                                onClick={() => window.open(item.proofUrl, '_blank')}
                                title="Ver comprovante"
                              >
                                <ImageIcon size={14} />
                              </Button>
                            )}
                            <Badge className="bg-emerald-500/10 text-emerald-400 border-none font-bold uppercase text-[10px]">{item.paymentMethod === 'nota_promissoria' ? 'NOTA PROMISSÓRIA' : item.paymentMethod}</Badge>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="activity" className="animate-in slide-in-from-right-2 duration-300">
          <Card className="border-none bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA] overflow-hidden shadow-2xl">
            <Table>
              <TableHeader className="bg-[#F5EBEF]">
                <TableRow className="border-[#EAEAEA] hover:bg-transparent">
                  <TableHead className="py-5 pl-8 font-bold text-[#6B6B6B]">Data e Hora</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B]">Ação</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B]">Tabela</TableHead>
                  <TableHead className="font-bold text-[#6B6B6B]">ID Registro</TableHead>
                  <TableHead className="text-right pr-8 font-bold text-[#6B6B6B]">VeraPay Security</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logsLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="py-20 text-center">
                      <Loader2 className="animate-spin mx-auto text-[#C84D8A]" size={32} />
                    </TableCell>
                  </TableRow>
                ) : activityLogs?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="py-20 text-center text-[#6B6B6B] italic">
                      Nenhuma atividade registrada ainda.
                    </TableCell>
                  </TableRow>
                ) : (
                  activityLogs?.map((log: any) => (
                    <TableRow key={log.id} className="hover:bg-[#F5EBEF]/80 border-[#EAEAEA] transition-colors">
                      <TableCell className="py-4 pl-8">
                        <div className="font-bold text-[#2A2A2A]">{format(new Date(log.created_at), "dd/MM/yyyy HH:mm:ss")}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${
                          log.action === 'INSERT' ? 'bg-emerald-500/10 text-emerald-400' :
                          log.action === 'UPDATE' ? 'bg-blue-500/10 text-blue-400' :
                          'bg-rose-500/10 text-rose-400'
                        } border-none font-black uppercase text-[10px]`}>
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium text-[#6B6B6B] uppercase tracking-widest text-[10px]">{log.table_name}</TableCell>
                      <TableCell className="font-mono text-[10px] text-[#6B6B6B]">{log.record_id.substring(0, 8)}...</TableCell>
                      <TableCell className="text-right pr-8">
                        <div className="flex justify-end items-center gap-2 text-emerald-500/50">
                          <ShieldCheck size={14} />
                          <span className="text-[9px] font-bold uppercase tracking-widest">Verificado</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
