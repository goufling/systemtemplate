import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getCustomers, getFullPaymentHistory, getPagamentosData, getCustomerDetails } from "../serverFunctions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  FileText, 
  Download, 
  Printer, 
  PieChart, 
  BarChart, 
  TrendingUp, 
  Clock,
  ChevronRight,
  FileSpreadsheet,
  AlertCircle,
  CalendarDays,
  Store,
  User,
  Search,
  MessageCircle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useState, useMemo, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Plus } from "lucide-react";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Check, X } from "lucide-react";

export const Route = createFileRoute("/_authenticated/relatorios")({
  component: Relatorios,
});

function Relatorios() {
  const [isCustomReportOpen, setIsCustomReportOpen] = useState(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>("");
  const [selectedLoanId, setSelectedLoanId] = useState<string>("all");
  const [selectedInstallmentIds, setSelectedInstallmentIds] = useState<string[]>([]);
  const [extraAdjustments, setExtraAdjustments] = useState<{ amount: number; reason: string }[]>([]);
  const [monthFilter, setMonthFilter] = useState<string>("all"); // "all" or "YYYY-MM"
  const [storeFilter, setStoreFilter] = useState<string>("all"); // "all" or store name
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [infoOverrides, setInfoOverrides] = useState<{ name: string; phone: string; email: string }>({ name: "", phone: "", email: "" });

  const { data: customers } = useQuery({
    queryKey: ["customers"],
    queryFn: () => getCustomers(),
  });

  const { data: installments } = useQuery({
    queryKey: ["pagamentos-data"],
    queryFn: () => getPagamentosData(),
  });

  const { data: history } = useQuery({
    queryKey: ["paymentHistory"],
    queryFn: () => getFullPaymentHistory(),
  });

  const { data: customerDetails, isLoading: isLoadingDetails } = useQuery({
    queryKey: ["customer-details", selectedCustomerId],
    queryFn: () => (getCustomerDetails as any)({ data: { customerId: selectedCustomerId } }),
    enabled: !!selectedCustomerId,
  });

  const selectedCustomer = useMemo(() => {
    return customers?.find((c: any) => c.id === selectedCustomerId);
  }, [customers, selectedCustomerId]);

  const customerLoans = useMemo(() => {
    return (customerDetails?.loans || []).sort((a: any, b: any) => new Date(b.loan_date).getTime() - new Date(a.loan_date).getTime());
  }, [customerDetails]);

  const availableStores = useMemo(() => {
    const set = new Set<string>();
    customerLoans.forEach((l: any) => {
      if (l.store_name) set.add(l.store_name);
    });
    return Array.from(set).sort();
  }, [customerLoans]);

  const allVisibleInstallments = useMemo(() => {
    if (!customerLoans) return [];
    let loans = selectedLoanId !== "all"
      ? customerLoans.filter((l: any) => l.id === selectedLoanId)
      : customerLoans;

    if (storeFilter !== "all") {
      loans = loans.filter((l: any) => l.store_name === storeFilter);
    }

    return loans.flatMap((l: any) =>
      (l.installments || []).map((i: any) => ({
        ...i,
        loan: l
      }))
    )
    .filter((i: any) => {
      if (monthFilter === "all") return true;
      return format(new Date(i.due_date), "yyyy-MM") === monthFilter;
    })
    .sort((a: any, b: any) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
  }, [customerLoans, selectedLoanId, monthFilter, storeFilter]);

  // Meses disponíveis (todos, mesmo que já pagos)
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    customerLoans.forEach((l: any) => {
      (l.installments || []).forEach((i: any) => set.add(format(new Date(i.due_date), "yyyy-MM")));
    });
    return Array.from(set).sort();
  }, [customerLoans]);

  // Auto-select next installments when customer or loan selection changes
  useEffect(() => {
    if (selectedCustomerId && customerLoans.length > 0 && selectedInstallmentIds.length === 0) {
      selectNextInstallments();
    }
  }, [customerLoans, selectedLoanId, selectedCustomerId]);

  // Check for customerId in URL on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const cid = params.get('customerId');
    if (cid && customers) {
      setSelectedCustomerId(cid);
      setIsCustomReportOpen(true);
    }
  }, [customers]);

  const selectAllInstallments = () => {
    setSelectedInstallmentIds(allVisibleInstallments.map((i: any) => i.id));
  };

  const selectNextInstallments = (targetLoans?: any[]) => {
    const nextIds: string[] = [];
    const loans = targetLoans || (selectedLoanId !== "all" 
      ? customerLoans.filter((l: any) => l.id === selectedLoanId)
      : customerLoans);
      
    loans.forEach((loan: any) => {
      const nextOpen = (loan.installments || [])
        .filter((i: any) => i.status !== 'paid')
        .sort((a: any, b: any) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];
      if (nextOpen) nextIds.push(nextOpen.id);
    });
    setSelectedInstallmentIds(nextIds);
  };

  const generatePDF = (shareWhatsApp = false) => {
    if (!selectedCustomerId) {
      toast.error("Selecione um cliente primeiro");
      return;
    }

    try {
      const doc = new jsPDF();
      const customerName = (infoOverrides.name || selectedCustomer?.name || customerDetails?.name || "Cliente").toUpperCase();
      const customerPhone = infoOverrides.phone || customerDetails?.phone || '';
      const customerEmail = infoOverrides.email || customerDetails?.email || '';
      const loans = selectedLoanId !== "all"
        ? customerLoans.filter((l: any) => l.id === selectedLoanId)
        : customerLoans;

      const loansFiltered = storeFilter !== "all"
        ? loans.filter((l: any) => l.store_name === storeFilter)
        : loans;
      // override the variable used below
      const loansToRender = loansFiltered;

      const fmtMoney = (v: number) =>
        new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(v) || 0);
      const fmtLong = (d: string | Date) =>
        format(new Date(d), "dd 'de' MMMM 'de' yyyy", { locale: ptBR }).toUpperCase();
      const fmtShortMonth = (d: string | Date) =>
        format(new Date(d), "MMM/yy", { locale: ptBR });

      // VeraPay system palette
      const brandPrimary: [number, number, number] = [200, 77, 138];     // #C84D8A rosa
      const brandDeep: [number, number, number] = [125, 41, 88];         // #7D2958 vinho
      const brandSoft: [number, number, number] = [245, 235, 239];       // #F5EBEF rosa claro
      const brandCream: [number, number, number] = [250, 246, 247];      // #FAF6F7 creme
      const headerGray: [number, number, number] = [245, 235, 239];      // header tabela

      // Title banner
      doc.setFillColor(...brandDeep);
      doc.rect(14, 14, 182, 14, 'F');
      doc.setFont("helvetica", "bold");
      doc.setFontSize(16);
      doc.setTextColor(255, 255, 255);
      const monthLabel = monthFilter !== "all"
        ? format(new Date(monthFilter + "-01"), "MMMM 'DE' yyyy", { locale: ptBR }).toUpperCase()
        : "";
      const monthReferenceTotal =
        monthFilter !== "all"
          ? loansToRender
              .flatMap((l: any) => l.installments || [])
              .filter((i: any) => format(new Date(i.due_date), "yyyy-MM") === monthFilter)
              .reduce((s: number, i: any) => s + Number(i.amount), 0)
          : null;
      const titleText = monthLabel
        ? `EXTRATO - ${monthLabel} - ${customerName}`
        : `EXTRATO - ${customerName}`;
      doc.text(titleText, 105, 22, { align: "center" });

      // Find next upcoming due date (open installment)
      const allInstallments = loansToRender.flatMap((l: any) => l.installments || []);
      const openInstallments = allInstallments
        .filter((i: any) => i.status !== 'paid')
        .sort((a: any, b: any) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
      const nextDue = openInstallments[0]?.due_date;

      // Customer info table — styled with brand (larger, more legible)
      autoTable(doc, {
        startY: 32,
        theme: 'grid',
        styles: { font: 'helvetica', fontSize: 12, textColor: brandDeep, lineColor: brandPrimary, lineWidth: 0.2, cellPadding: 3 },
        columnStyles: {
          0: { fontStyle: 'bold', cellWidth: 50, fillColor: brandSoft, textColor: brandDeep },
          1: { halign: 'left', fillColor: [255, 255, 255] }
        },
        body: [
          ['CLIENTE', customerName],
          ['CONTATO', customerPhone || '--'],
          ['E-MAIL', customerEmail || '--'],
          ...(storeFilter !== "all" ? [["LOJA", storeFilter.toUpperCase()]] : []),
          ...(monthReferenceTotal !== null ? [["TOTAL DO MÊS", fmtMoney(monthReferenceTotal)]] : []),
          ['PRÓXIMO VENCIMENTO', nextDue ? fmtLong(nextDue) : '--'],
        ],
        margin: { left: 14, right: 14 },
      });

      // Explanatory note (helps clients who have difficulty understanding)
      const noteY = (doc as any).lastAutoTable.finalY + 4;
      doc.setFillColor(...brandSoft);
      doc.rect(14, noteY, 182, 10, 'F');
      doc.setFont("helvetica", "italic");
      doc.setFontSize(10);
      doc.setTextColor(...brandDeep);
      doc.text(
        "Parcelas listadas em ordem do vencimento mais próximo para o mais distante.",
        105, noteY + 6, { align: "center" }
      );

      // Build a global list of installments to render, sorted by due date (next first)
      type Row = { loan: any; inst: any };
      const rows: Row[] = [];
      loansToRender.forEach((loan: any) => {
        let installments = (loan.installments || []).slice();
        if (monthFilter !== "all") {
          installments = installments.filter((i: any) => format(new Date(i.due_date), "yyyy-MM") === monthFilter);
        }
        if (selectedInstallmentIds.length > 0 && monthFilter === "all") {
          installments = installments.filter((i: any) => selectedInstallmentIds.includes(i.id));
        } else if (monthFilter === "all") {
          const sorted = installments.sort((a: any, b: any) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime());
          const nextOpen = sorted.find((i: any) => i.status !== 'paid');
          installments = nextOpen ? [nextOpen] : [];
        }
        installments.forEach((inst: any) => rows.push({ loan, inst }));
      });

      // Sort globally by next due date (ascending)
      rows.sort((a, b) => new Date(a.inst.due_date).getTime() - new Date(b.inst.due_date).getTime());

      const body: any[] = [];
      let subtotalParcelas = 0;

      rows.forEach(({ loan, inst }) => {
        const qtd = loan.installments_count || (loan.installments || []).length;
        const displayAmount = Number(inst.amount);
        subtotalParcelas += displayAmount;
        const statusLabel = inst.status === 'paid' ? 'PAGO' : 'EM ABERTO';
        body.push([
          (loan.store_name || '').toUpperCase(),
          fmtMoney(loan.total_amount),
          `${inst.number}/${qtd}`,
          fmtMoney(displayAmount),
          format(new Date(inst.due_date), "dd/MM/yyyy"),
          statusLabel,
        ]);
      });

      if (body.length === 0) {
        toast.error("Nenhuma parcela selecionada");
        return;
      }

      // Add Additional Values/Adjustments before the total
      if (extraAdjustments.length > 0) {
        extraAdjustments.forEach(adj => {
          if (adj.amount === 0) return;
          body.push([
            { content: (adj.reason || 'VALOR ADICIONAL').toUpperCase(), colSpan: 3, styles: { fontStyle: 'bold', halign: 'right' } },
            { content: fmtMoney(adj.amount), styles: { fontStyle: 'bold' } },
            '', '',
          ]);
          subtotalParcelas += adj.amount;
        });
      }

      // Final Total row
      body.push([
        {
          content: monthFilter !== "all" ? "TOTAL A RECEBER DO MÊS" : "TOTAL A RECEBER",
          colSpan: 3,
          styles: { fontStyle: "bold", halign: "right", fillColor: brandPrimary, textColor: [255, 255, 255] },
        },
        { content: fmtMoney(subtotalParcelas), styles: { fontStyle: 'bold', fillColor: brandPrimary, textColor: [255, 255, 255] } },
        { content: '', colSpan: 2, styles: { fillColor: brandPrimary } }
      ]);

      autoTable(doc, {
        startY: noteY + 14,
        theme: 'grid',
        styles: {
          font: 'helvetica',
          fontSize: 12,
          textColor: brandDeep,
          lineColor: brandPrimary,
          lineWidth: 0.15,
          halign: 'center',
          valign: 'middle',
          cellPadding: 3
        },
        alternateRowStyles: { fillColor: brandCream },
        headStyles: { fillColor: brandDeep, textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center', lineColor: brandDeep, fontSize: 12 },
        head: [[
          'LOJA',
          'VALOR DA COMPRA',
          'PARCELA',
          'VALOR A PAGAR',
          'VENCIMENTO',
          'SITUAÇÃO',
        ]],
        columnStyles: {
          0: { halign: 'left', cellWidth: 34, fontStyle: 'bold' },
          1: { cellWidth: 32 },
          2: { cellWidth: 22 },
          3: { cellWidth: 32, fontStyle: 'bold' },
          4: { cellWidth: 30 },
          5: { cellWidth: 'auto', fontStyle: 'bold' },
        },
        body,
        margin: { left: 14, right: 14 },
      });

      // Footer
      const pageHeight = doc.internal.pageSize.height;
      doc.setFillColor(...brandSoft);
      doc.rect(14, pageHeight - 18, 182, 10, 'F');
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(...brandDeep);
      doc.text(
        `VeraPay  •  Gerado em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}`,
        105,
        pageHeight - 12,
        { align: "center" }
      );

      const fileName = `Nota_${customerName.replace(/\s+/g, '_')}.pdf`;

      const pdfBlob = doc.output('blob');
      const file = new File([pdfBlob], fileName, { type: 'application/pdf' });
      
      const handleOutput = async () => {
        if (shareWhatsApp) {
          if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
            try {
              await navigator.share({
                files: [file],
                title: 'Extrato VeraPay',
                text: `Olá ${customerName}! Segue seu extrato detalhado.\n\nTotal a pagar: ${fmtMoney(subtotalParcelas)}`,
              });
              setIsCustomReportOpen(false);
              return;
            } catch (error) {
              console.error("Share error:", error);
            }
          }
          
          doc.save(fileName);
          const phone = (selectedCustomer?.phone || customerDetails?.phone || '').replace(/\D/g, '');
          const message = `Olá ${customerName}! Segue seu extrato detalhado.\n\nTotal a pagar: ${fmtMoney(subtotalParcelas)}\n\nO PDF foi baixado. Por favor, anexe-o aqui.`;
          const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
          window.open(whatsappUrl, '_blank');
        } else {
          doc.save(fileName);
          toast.success("PDF gerado com sucesso!");
        }
        setIsCustomReportOpen(false);
      };

      handleOutput();

      setIsCustomReportOpen(false);
    } catch (error) {
      console.error("PDF Error:", error);
      toast.error("Erro ao gerar PDF");
    }
  };

  const exportGeneralReport = () => {
    if (!installments || installments.length === 0) {
      toast.error("Nenhum dado disponível para exportar");
      return;
    }

    const data = installments.map((inst: any) => ({
      "Cliente": inst.customer?.name || "Desconhecido",
      "Loja": inst.loan?.store_name || "Venda Direta",
      "Parcela": `${inst.number}ª/${inst.loan?.installments_count || "?"}`,
      "Vencimento": format(new Date(inst.due_date), "dd/MM/yyyy"),
      "Valor": inst.amount,
      "Status": inst.status.toUpperCase(),
      "Observação": inst.notes || "--"
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Relatorio Geral");
    XLSX.writeFile(workbook, `VeraPay_Relatorio_Geral_${format(new Date(), "ddMMyyyy")}.xlsx`);
    toast.success("Relatório Geral exportado com sucesso!");
  };

  const exportAgingReport = () => {
    if (!installments) return;
    
    const overdue = installments.filter((i: any) => i.status === "overdue");
    if (overdue.length === 0) {
      toast.info("Nenhuma inadimplência encontrada no momento.");
      return;
    }

    const data = overdue.map((inst: any) => {
      const daysOverdue = differenceInDays(new Date(), new Date(inst.due_date));
      let range = "0-15 dias";
      if (daysOverdue > 30) range = "30+ dias";
      else if (daysOverdue > 15) range = "15-30 dias";

      return {
        "Cliente": inst.customer?.name,
        "Loja": inst.loan?.store_name,
        "Parcela": `${inst.number}ª/${inst.loan?.installments_count || "?"}`,
        "Vencimento": format(new Date(inst.due_date), "dd/MM/yyyy"),
        "Dias em Atraso": daysOverdue,
        "Faixa": range,
        "Valor": inst.amount,
        "Observação": inst.notes || "--",
        "Telefone": inst.customer?.phone || "--"
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inadimplencia");
    XLSX.writeFile(workbook, `VeraPay_Inadimplencia_${format(new Date(), "ddMMyyyy")}.xlsx`);
    toast.success("Relatório de Inadimplência exportado!");
  };

  const exportHistoryReport = () => {
    if (!history || history.length === 0) {
      toast.error("Nenhum histórico de pagamento encontrado");
      return;
    }

    const data = history.map((item: any) => ({
      "Data Pagamento": format(new Date(item.paidAt), "dd/MM/yyyy HH:mm"),
      "Cliente": item.customerName,
      "Loja": item.storeName,
      "Parcela": item.installmentNumber,
      "Valor": item.amount,
      "Método": item.paymentMethod.toUpperCase()
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Historico de Pagos");
    XLSX.writeFile(workbook, `VeraPay_Historico_${format(new Date(), "ddMMyyyy")}.xlsx`);
    toast.success("Histórico de pagamentos exportado!");
  };

  const exportStoreReport = () => {
    if (!installments || installments.length === 0) {
      toast.error("Sem dados");
      return;
    }

    const storeData: Record<string, { count: number, total: number, paid: number }> = {};
    
    installments.forEach((inst: any) => {
      const store = inst.loan?.store_name || "Venda Direta";
      if (!storeData[store]) storeData[store] = { count: 0, total: 0, paid: 0 };
      
      storeData[store].count++;
      storeData[store].total += Number(inst.amount);
      if (inst.status === 'paid') storeData[store].paid += Number(inst.amount);
    });

    const data = Object.entries(storeData).map(([store, stats]) => ({
      "Loja": store,
      "Qtd Parcelas": stats.count,
      "Total Bruto": stats.total,
      "Total Recebido": stats.paid,
      "Saldo Devedor": stats.total - stats.paid,
      "% Adimplência": ((stats.paid / stats.total) * 100).toFixed(2) + "%"
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Performance Lojas");
    XLSX.writeFile(workbook, `VeraPay_Lojas_${format(new Date(), "ddMMyyyy")}.xlsx`);
    toast.success("Relatório de lojas gerado!");
  };


  const reportTypes = [
    { 
      title: "Extrato Geral", 
      description: "Lista completa de todas as parcelas e situações.",
      icon: FileSpreadsheet,
      color: "text-blue-400",
      bg: "bg-blue-400/10",
      action: exportGeneralReport
    },
    { 
      title: "Inadimplência (Aging)", 
      description: "Clientes com parcelas vencidas por faixa de atraso.",
      icon: AlertCircle,
      color: "text-rose-400",
      bg: "bg-rose-400/10",
      action: exportAgingReport
    },
    { 
      title: "Fluxo de Recebidos", 
      description: "Histórico de tudo que já entrou no caixa.",
      icon: TrendingUp,
      color: "text-emerald-400",
      bg: "bg-emerald-400/10",
      action: exportHistoryReport
    },
    { 
      title: "Performance por Loja", 
      description: "Volume de vendas e recebimentos por parceiro.",
      icon: Store,
      color: "text-[#C84D8A]",
      bg: "bg-[#C84D8A]/10",
      action: () => exportStoreReport()
    },
    { 
      title: "Extrato / Nota Promissória (PDF)", 
      description: "Selecione um cliente e uma compra para gerar a Nota Promissória em PDF.",

      icon: User,
      color: "text-purple-400",
      bg: "bg-purple-400/10",
      action: () => setIsCustomReportOpen(true)
    }
  ];

  // ... keep existing code

  return (
    <div className="space-y-10 animate-in fade-in duration-500 max-w-6xl mx-auto">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b border-[#EAEAEA] pb-8">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-[#2A2A2A]">Central de <span className="gold-text">Relatórios</span></h1>
          <p className="text-[#6B6B6B] font-medium italic mt-1">Gere arquivos Excel profissionais para sua contabilidade.</p>
        </div>

        <div className="flex gap-4">
          <Button 
            onClick={() => {
              const urlParams = new URLSearchParams(window.location.search);
              const cid = urlParams.get('customerId');
              if (cid) {
                setSelectedCustomerId(cid);
                setIsCustomReportOpen(true);
              } else {
                toast.info("Nenhum cliente selecionado. Escolha um na lista.");
                setIsCustomReportOpen(true);
              }
            }}
            className="btn-primary h-12 px-6 gap-2"
          >
            <Plus size={18} /> Novo Relatório Rápido
          </Button>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="h-12 rounded-xl bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] hover:bg-[#FFFFFF]/80 gap-2" 
            onClick={() => window.print()}
          >
            <Printer size={18} /> Imprimir Tela
          </Button>
        </div>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        {reportTypes.map((report, idx) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            key={report.title}
            onClick={report.action}
          >
            <Card className="border-none bg-[#FFFFFF] hover:bg-[#FFFFFF]/80 transition-all rounded-[32px] border border-[#EAEAEA] p-8 group cursor-pointer overflow-hidden relative">
              <div className={`absolute -right-8 -top-8 w-32 h-32 ${report.bg} blur-3xl rounded-full opacity-20 group-hover:opacity-40 transition-opacity`} />
              
              <div className="flex items-start justify-between relative z-10">
                <div className="space-y-4">
                  <div className={`h-14 w-14 rounded-2xl ${report.bg} ${report.color} flex items-center justify-center shadow-lg`}>
                    <report.icon size={28} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-[#2A2A2A] tracking-tight">{report.title}</h3>
                    <p className="text-sm text-[#6B6B6B] mt-1 max-w-[240px] leading-relaxed">{report.description}</p>
                  </div>
                  <div className="flex items-center gap-2 text-[#C84D8A] text-xs font-bold uppercase tracking-widest mt-6 group-hover:translate-x-1 transition-transform">
                    Baixar Excel <ChevronRight size={14} />
                  </div>
                </div>
                
                <div className="h-full flex items-center text-[#2A2A2A]/50">
                  <FileSpreadsheet size={80} strokeWidth={1} />
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="pt-10">
        <Card className="border-none bg-[#F5EBEF] rounded-[40px] border border-[#EAEAEA] overflow-hidden shadow-2xl">
          <CardHeader className="p-10 pb-0">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl font-black text-[#2A2A2A]">Previsão de Recebíveis</CardTitle>
                <p className="text-[#6B6B6B] text-sm mt-1">Baseado no calendário de vencimentos futuros.</p>
              </div>
              <div className="flex items-center gap-2 bg-[#FFFFFF] px-4 py-2 rounded-xl border border-[#EAEAEA]">
                <CalendarDays size={16} className="text-[#C84D8A]" />
                <span className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest">Próximos 30 dias</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="bg-[#FAF6F7] p-6 rounded-[24px] border border-[#EAEAEA]">
                 <p className="text-xs font-bold text-[#6B6B6B] uppercase tracking-widest mb-2">Total a Receber</p>
                 <p className="text-3xl font-black text-[#C84D8A]">
                   {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                     installments?.filter((i: any) => i.status !== 'paid').reduce((acc: number, curr: any) => acc + Number(curr.amount), 0) || 0
                   )}
                 </p>
               </div>
               <div className="bg-[#FAF6F7] p-6 rounded-[24px] border border-[#EAEAEA]">
                 <p className="text-xs font-bold text-[#6B6B6B] uppercase tracking-widest mb-2">Vencidos (Aging)</p>
                 <p className="text-3xl font-black text-rose-400">
                   {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                     installments?.filter((i: any) => i.status === 'overdue').reduce((acc: number, curr: any) => acc + Number(curr.amount), 0) || 0
                   )}
                 </p>
               </div>
               <div className="bg-[#FAF6F7] p-6 rounded-[24px] border border-[#EAEAEA]">
                 <p className="text-xs font-bold text-[#6B6B6B] uppercase tracking-widest mb-2">Total Recebido</p>
                 <p className="text-3xl font-black text-emerald-400">
                   {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                     history?.reduce((acc: number, curr: any) => acc + Number(curr.amount), 0) || 0
                   )}
                 </p>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={isCustomReportOpen} onOpenChange={setIsCustomReportOpen}>
        <DialogContent className="bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black">Gerar Extrato Personalizado</DialogTitle>
            <DialogDescription className="text-[#6B6B6B]">
              Escolha o cliente e opcionalmente uma venda específica para gerar o PDF.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Selecionar Cliente</Label>
              <Select value={selectedCustomerId} onValueChange={(val) => {
                setSelectedCustomerId(val);
                setSelectedLoanId("all");
                setSelectedInstallmentIds([]);
                // The selectNextInstallments will be triggered via useEffect when customerDetails is loaded
              }}>
                <SelectTrigger className="h-14 bg-[#F5EBEF] border-[#EAEAEA] rounded-2xl">
                  <SelectValue placeholder="Selecione um cliente..." />
                </SelectTrigger>
                <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                  {customers?.map((c: any) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <AnimatePresence>
              {selectedCustomerId && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Dados da Nota</Label>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        if (!isEditingInfo) {
                          setInfoOverrides({
                            name: infoOverrides.name || selectedCustomer?.name || customerDetails?.name || "",
                            phone: infoOverrides.phone || customerDetails?.phone || "",
                            email: infoOverrides.email || customerDetails?.email || "",
                          });
                        }
                        setIsEditingInfo((v) => !v);
                      }}
                      className="h-7 text-[10px] text-[#C84D8A] hover:text-[#C84D8A] hover:bg-[#C84D8A]/10 p-0 px-2"
                    >
                      {isEditingInfo ? "Concluir" : "Editar"}
                    </Button>
                  </div>
                  {isEditingInfo && (
                    <div className="space-y-2 p-3 rounded-2xl bg-[#FAF6F7] border border-[#EAEAEA]">
                      <Input
                        placeholder="Nome"
                        value={infoOverrides.name}
                        onChange={(e) => setInfoOverrides({ ...infoOverrides, name: e.target.value })}
                        className="h-10 bg-[#F5EBEF] border-[#EAEAEA] text-sm rounded-lg"
                      />
                      <Input
                        placeholder="Contato"
                        value={infoOverrides.phone}
                        onChange={(e) => setInfoOverrides({ ...infoOverrides, phone: e.target.value })}
                        className="h-10 bg-[#F5EBEF] border-[#EAEAEA] text-sm rounded-lg"
                      />
                      <Input
                        placeholder="E-mail"
                        value={infoOverrides.email}
                        onChange={(e) => setInfoOverrides({ ...infoOverrides, email: e.target.value })}
                        className="h-10 bg-[#F5EBEF] border-[#EAEAEA] text-sm rounded-lg"
                      />
                      <p className="text-[10px] text-[#6B6B6B] italic">Edição aplica-se apenas a este PDF.</p>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {selectedCustomerId && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2"
                >
                  <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Selecionar Venda/Loja (Opcional)</Label>
                  <Select value={selectedLoanId} onValueChange={(val) => {
                    setSelectedLoanId(val);
                    setSelectedInstallmentIds([]);
                  }}>
                    <SelectTrigger className="h-14 bg-[#F5EBEF] border-[#EAEAEA] rounded-2xl">
                      <SelectValue placeholder="Todas as compras" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                      <SelectItem value="all">Todas as compras (Consolidado)</SelectItem>
                      {customerLoans.map((loan: any) => (
                        <SelectItem key={loan.id} value={loan.id}>
                          {loan.store_name} - {format(new Date(loan.loan_date), "dd/MM/yyyy")} {loan.order_number ? `(#${loan.order_number})` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {selectedCustomerId && availableStores.length > 1 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2"
                >
                  <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Filtrar por Loja</Label>
                  <Select value={storeFilter} onValueChange={(val) => {
                    setStoreFilter(val);
                    setSelectedInstallmentIds([]);
                  }}>
                    <SelectTrigger className="h-14 bg-[#F5EBEF] border-[#EAEAEA] rounded-2xl">
                      <SelectValue placeholder="Todas as lojas" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                      <SelectItem value="all">Todas as lojas</SelectItem>
                      {availableStores.map((s) => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {selectedCustomerId && availableMonths.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-2"
                >
                  <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Filtrar por Mês de Vencimento</Label>
                  <Select value={monthFilter} onValueChange={(val) => {
                    setMonthFilter(val);
                    setSelectedInstallmentIds([]);
                  }}>
                    <SelectTrigger className="h-14 bg-[#F5EBEF] border-[#EAEAEA] rounded-2xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                      <SelectItem value="all">Todos os meses (em aberto)</SelectItem>
                      {availableMonths.map((m) => {
                        const [y, mm] = m.split("-");
                        const label = format(new Date(Number(y), Number(mm) - 1, 1), "MMMM 'de' yyyy", { locale: ptBR });
                        return <SelectItem key={m} value={m}>{label.charAt(0).toUpperCase() + label.slice(1)}</SelectItem>;
                      })}
                    </SelectContent>
                  </Select>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {selectedCustomerId && allVisibleInstallments.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="space-y-4 pt-4 border-t border-[#EAEAEA]"
                >
                  <div className="flex flex-col gap-2">
                    <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Selecionar Parcelas</Label>
                    <div className="flex flex-wrap gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 text-[10px] text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10 p-0 px-2"
                        onClick={() => selectNextInstallments()}
                      >
                        Próxima
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 text-[10px] text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10 p-0 px-2"
                        onClick={selectAllInstallments}
                      >
                        Todas
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-7 text-[10px] text-rose-400 hover:text-rose-300 hover:bg-rose-400/10 p-0 px-2"
                        onClick={() => {
                          setSelectedInstallmentIds([]);
                          setExtraAdjustments([]);
                        }}
                      >
                        Limpar
                      </Button>
                    </div>
                  </div>
                  <ScrollArea className="h-[180px] rounded-2xl border border-[#EAEAEA] bg-[#FAF6F7] p-3 shadow-inner">
                    <div className="space-y-3">
                      {allVisibleInstallments.map((inst: any) => (
                        <div key={inst.id} className="flex items-center space-x-3 group py-2 border-b border-[#EAEAEA] last:border-0">
                          <Checkbox 
                            id={inst.id} 
                            checked={selectedInstallmentIds.includes(inst.id)}
                            onCheckedChange={(checked) => {
                              if (checked) setSelectedInstallmentIds(prev => [...prev, inst.id]);
                              else setSelectedInstallmentIds(prev => prev.filter(id => id !== inst.id));
                            }}
                            className="border-[#EAEAEA] data-[state=checked]:bg-[#C84D8A] data-[state=checked]:border-[#C84D8A]"
                          />
                          <label htmlFor={inst.id} className="text-sm font-medium text-[#2A2A2A] cursor-pointer group-hover:text-[#2A2A2A] flex-1 flex justify-between items-center pr-2">
                            <span className="flex flex-col">
                              <span>{inst.number}ª Parcela</span>
                              <span className="text-[10px] text-[#6B6B6B]">{inst.loan?.store_name}</span>
                            </span>
                            <span className="text-xs font-mono text-[#6B6B6B]">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(inst.amount)}
                              <span className="ml-2 opacity-50">({format(new Date(inst.due_date), "dd/MM")})</span>
                            </span>
                          </label>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  
                  <div className="space-y-4 pt-2 border-t border-[#EAEAEA]">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-bold uppercase tracking-widest text-[#6B6B6B]">Ajustes / Valores Adicionais</Label>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setExtraAdjustments([...extraAdjustments, { amount: 0, reason: "" }])}
                        className="h-6 text-[10px] text-emerald-400 hover:text-emerald-300 hover:bg-emerald-400/10 gap-1 p-0 px-2"
                      >
                        <Plus size={10} /> Adicionar
                      </Button>
                    </div>
                    
                    <div className="space-y-2">
                      {extraAdjustments.map((adj, idx) => (
                        <div key={idx} className="flex flex-col sm:flex-row gap-2 p-3 rounded-xl bg-[#F5EBEF] border border-[#EAEAEA] relative group">
                          <div className="flex-1">
                            <Label className="text-[10px] text-[#6B6B6B] mb-1 block">Motivo do Ajuste</Label>
                            <Input 
                              placeholder="Ex: Pendência anterior" 
                              value={adj.reason}
                              onChange={(e) => {
                                const newAdj = [...extraAdjustments];
                                newAdj[idx].reason = e.target.value;
                                setExtraAdjustments(newAdj);
                              }}
                              className="h-9 bg-[#FFFFFF] border-[#EAEAEA] text-sm rounded-lg"
                            />
                          </div>
                          <div className="sm:w-32 relative">
                            <Label className="text-[10px] text-[#6B6B6B] mb-1 block">Valor</Label>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-[#6B6B6B]">R$</span>
                              <Input 
                                type="number"
                                placeholder="0,00"
                                value={adj.amount || ""}
                                onChange={(e) => {
                                  const val = parseFloat(e.target.value);
                                  const newAdj = [...extraAdjustments];
                                  newAdj[idx].amount = isNaN(val) ? 0 : val;
                                  setExtraAdjustments(newAdj);
                                }}
                                className="h-9 pl-8 bg-[#FFFFFF] border-[#EAEAEA] text-sm rounded-lg"
                              />
                            </div>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => setExtraAdjustments(extraAdjustments.filter((_, i) => i !== idx))}
                            className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-rose-500 text-white hover:bg-rose-600 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X size={12} />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  <p className="text-[10px] text-[#6B6B6B] italic">
                    {monthFilter !== "all"
                      ? "Com mês selecionado, o PDF incluirá TODAS as parcelas daquele mês, pagas ou não."
                      : selectedInstallmentIds.length === 0 
                      ? "Nenhuma parcela selecionada. O PDF incluirá automaticamente apenas a PRÓXIMA parcela de cada compra."
                      : `${selectedInstallmentIds.length} parcela(s) selecionada(s).`}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {(() => {
              const currentLoan = selectedLoanId !== "all" ? customerLoans.find((l: any) => l.id === selectedLoanId) : null;
              if (currentLoan?.notes) {
                return (
                  <div className="p-4 rounded-2xl bg-[#F5EBEF] border border-[#EAEAEA]">
                    <p className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest mb-1">Observação da Venda:</p>
                    <p className="text-sm text-[#2A2A2A] italic">{currentLoan.notes}</p>
                  </div>
                );
              }
              return null;
            })()}
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-3 pt-6 border-t border-[#EAEAEA] mt-4">
            <Button 
              variant="outline" 
              onClick={() => setIsCustomReportOpen(false)}
              className="h-12 w-full sm:w-auto rounded-xl border-[#EAEAEA] text-[#6B6B6B] bg-transparent hover:bg-[#F5EBEF]/80"
            >
              Cancelar
            </Button>
            <Button 
              onClick={() => generatePDF(true)}
              disabled={!selectedCustomerId || isLoadingDetails}
              className="h-12 w-full sm:w-auto rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 gap-2 shadow-lg"
            >
              {isLoadingDetails ? <Clock className="animate-spin" size={18} /> : <MessageCircle size={18} />}
              WhatsApp
            </Button>
            <Button 
              onClick={() => generatePDF(false)}
              disabled={!selectedCustomerId || isLoadingDetails}
              className="h-12 w-full sm:flex-1 rounded-xl bg-[#C84D8A] hover:bg-[#C84D8A]/80 text-[#7D2958] font-bold px-8 gap-2 shadow-lg shadow-primary/20"
            >
              {isLoadingDetails ? <Clock className="animate-spin" size={18} /> : <Download size={18} />}
              Gerar PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
