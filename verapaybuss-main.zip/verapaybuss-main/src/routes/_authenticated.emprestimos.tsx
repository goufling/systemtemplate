import { createFileRoute } from "@tanstack/react-router";
import { useState, useMemo, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCustomers, createLoan, listStores, createStore } from "../serverFunctions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  PlusCircle, 
  ShoppingBag, 
  Loader2, 
  Info, 
  Calculator, 
  Trash2,
  FileText,
  ShieldCheck,
  Briefcase,
  TrendingUp,
  Hash,
  Store,
  Receipt,
  CheckCircle2,
  Image as ImageIcon,
  Pencil
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Checkbox } from "@/components/ui/checkbox";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { brand, tableTheme, drawVeraPayHeader, drawVeraPayFooter, fmtMoneyBR } from "@/lib/pdfBranding";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { requireAdminPassword } from "@/lib/admin-password";

export const Route = createFileRoute("/_authenticated/emprestimos")({
  component: Emprestimos,
});

function Emprestimos() {
  const queryClient = useQueryClient();
  const formatDateOnly = (date: string) => {
    const [year, month, day] = date.split("-").map(Number);
    return format(new Date(year, month - 1, day), "dd/MM/yyyy", { locale: ptBR });
  };
  const formatDateOnlyLong = (date: string) => {
    const [year, month, day] = date.split("-").map(Number);
    return format(new Date(year, month - 1, day), "dd 'de' MMMM 'de' yyyy", { locale: ptBR }).toUpperCase();
  };

  const generateLoanPDF = (loan: any, customer: any) => {
    try {
      const doc = new jsPDF();
      const customerName = (customer?.name || "Cliente").toUpperCase();
      const startY = drawVeraPayHeader(doc, `Nota Promissória — ${customerName}`);

      // Customer info table
      autoTable(doc, {
        startY,
        theme: 'grid',
        styles: { ...tableTheme.styles, fontSize: 12 },
        columnStyles: {
          0: { fontStyle: 'bold', cellWidth: 45, fillColor: brand.soft, textColor: brand.deep },
          1: { halign: 'left', fillColor: brand.white },
        },
        body: [
          ['CLIENTE', customerName],
          ['CONTATO', customer?.phone || '--'],
          ['LOJA', (loan.store_name || '').toUpperCase()],
          ['DATA', formatDateOnlyLong(loan.loan_date)],
        ],
        margin: { left: 14, right: 14 },
      });

      // Installments Table
      const body = (loan.installments || []).sort((a: any, b: any) => a.number - b.number).map((inst: any) => [
        `${inst.number}ª PARCELA`,
        fmtMoneyBR(inst.amount),
        formatDateOnly(inst.due_date),
        inst.status === 'paid' ? 'LIQUIDADA' : 'PENDENTE'
      ]);

      autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 8,
        theme: 'grid',
        headStyles: tableTheme.headStyles,
        alternateRowStyles: tableTheme.alternateRowStyles,
        styles: { ...tableTheme.styles, halign: 'center', fontSize: 12 },
        head: [['PARCELA', 'VALOR', 'VENCIMENTO', 'STATUS']],
        body,
        margin: { left: 14, right: 14 },
      });

      const finalY = (doc as any).lastAutoTable.finalY + 20;
      doc.setFontSize(10);
      doc.setTextColor(brand.deep[0], brand.deep[1], brand.deep[2]);
      doc.text("Assinatura do Cliente:", 14, finalY);
      doc.setDrawColor(brand.primary[0], brand.primary[1], brand.primary[2]);
      doc.line(14, finalY + 10, 100, finalY + 10);

      drawVeraPayFooter(doc);
      doc.save(`VeraPay_Nota_${customerName.replace(/\s+/g, '_')}_${loan.id.substring(0, 5)}.pdf`);
      toast.success("Nota Promissória gerada!");
    } catch (error) {
      console.error("PDF Error:", error);
      toast.error("Erro ao gerar PDF");
    }
  };

  const [showForm, setShowForm] = useState(false);
  const today = new Date().toISOString().split('T')[0];
  // Sempre pula 1 mês inteiro e cobra no dia 10 do mês seguinte.
  // Ex: compra em janeiro → primeira cobrança em 10 de março.
  const computePaymentMonth = (purchaseDate: string) => {
    const [year, month] = (purchaseDate || "").split("-").map(Number);
    if (!year || !month || year < 1900) return "";
    const target = new Date(year, month - 1 + 2, 1);
    return `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, "0")}`;
  };
  const formatMonthFull = (ym: string) => {
    const [y, m] = (ym || "").split("-").map(Number);
    if (!y || !m) return "";
    return format(new Date(y, m - 1, 1), "MMMM 'de' yyyy", { locale: ptBR });
  };
  const [formData, setFormData] = useState({
    customerId: "",
    storeName: "",
    orderNumber: "",
    totalAmount: 0,
    purchaseDate: today,
    paymentMonth: computePaymentMonth(today),
    installmentsCount: 1,
    capitalSource: "proprio",
    profitMarginPercent: 0,
    acceptTerms: false,
    notes: "",
    attachmentUrl: "",
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('loan-attachments')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('loan-attachments')
        .getPublicUrl(filePath);

      setFormData(prev => ({ ...prev, attachmentUrl: publicUrl }));
      toast.success("Foto anexada com sucesso!");
    } catch (error: any) {
      toast.error("Erro ao fazer upload da foto: " + error.message);
    } finally {
      setUploading(false);
    }
  };


  const { data: customers, isLoading: customersLoading } = useQuery({
    queryKey: ["customers"],
    queryFn: () => getCustomers(),
  });

  const selectedCustomer = useMemo(() => {
    return customers?.find((c: any) => c.id === formData.customerId);
  }, [customers, formData.customerId]);

  const { data: loans, isLoading: loansLoading } = useQuery({
    queryKey: ["loans"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("loans")
        .select("*, installments(*)")
        .order("loan_date", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: registeredStores } = useQuery({
    queryKey: ["stores-list"],
    queryFn: () => listStores(),
  });

  const uniqueStores = useMemo(() => {
    const fromCatalog = (registeredStores || []).map((s: any) => s.name);
    const fromLoans = (loans || []).map((l: any) => l.store_name).filter(Boolean);
    return Array.from(new Set<string>([...fromCatalog, ...fromLoans])).sort();
  }, [registeredStores, loans]);

  const [quickStoreOpen, setQuickStoreOpen] = useState(false);
  const [quickStoreName, setQuickStoreName] = useState("");
  const [quickStoreCommission, setQuickStoreCommission] = useState<number>(0);
  const quickStoreMut = useMutation({
    mutationFn: (vars: any) => createStore({ data: vars }),
    onSuccess: (row: any) => {
      queryClient.invalidateQueries({ queryKey: ["stores-list"] });
      setFormData(prev => ({ ...prev, storeName: row.name }));
      setQuickStoreOpen(false);
      setQuickStoreName("");
      setQuickStoreCommission(0);
      toast.success("Loja cadastrada e selecionada!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const installmentValue = useMemo(() => {
    if (!formData.totalAmount || formData.installmentsCount <= 0) return 0;
    return formData.totalAmount / formData.installmentsCount;
  }, [formData.totalAmount, formData.installmentsCount]);

  const previewInstallments = useMemo(() => {
    const count = formData.installmentsCount;
    if (!count) return [] as { number: number; dueDate: string; overdue: boolean }[];
    const [y, m] = formData.paymentMonth.split("-").map(Number);
    const todayStr = new Date().toISOString().split("T")[0];
    return Array.from({ length: count }).map((_, i) => {
      const dt = new Date(y, (m - 1) + i, 10);
      const dueDate = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
      return { number: i + 1, dueDate, overdue: dueDate < todayStr };
    });
  }, [formData.paymentMonth, formData.installmentsCount]);

  const overdueCount = previewInstallments.filter(p => p.overdue).length;


  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const { markOverduePaid, ...payload } = data;
      const loan = await createLoan({ data: payload });
      if (markOverduePaid) {
        const todayStr = new Date().toISOString().split("T")[0];
        const { error } = await supabase
          .from("installments")
          .update({ status: "paid", paid_at: new Date().toISOString(), payment_method: "cash" })
          .eq("loan_id", loan.id)
          .lt("due_date", todayStr);
        if (error) console.error("Erro ao marcar parcelas em atraso:", error);
      }
      return loan;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loans"] });
      queryClient.invalidateQueries({ queryKey: ["installments"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      setShowForm(false);
      setFormData({
        customerId: "",
        storeName: "",
        orderNumber: "",
        totalAmount: 0,
        purchaseDate: today,
        paymentMonth: computePaymentMonth(today),
        installmentsCount: 1,
        capitalSource: "proprio",
        profitMarginPercent: 0,
        acceptTerms: false,
        notes: "",
        attachmentUrl: "",
      });

      toast.success("Empréstimo registrado com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao registrar empréstimo", { description: error.message });
    }
  });


  const deleteLoanMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("loans").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loans"] });
      queryClient.invalidateQueries({ queryKey: ["installments"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      toast.success("Empréstimo excluído!");
    }
  });

  const [editingLoan, setEditingLoan] = useState<any>(null);
  const [editForm, setEditForm] = useState({ store_name: "", order_number: "", total_amount: 0, loan_date: "", notes: "" });

  const openEditLoan = (loan: any) => {
    setEditingLoan(loan);
    setEditForm({
      store_name: loan.store_name || "",
      order_number: loan.order_number || "",
      total_amount: Number(loan.total_amount) || 0,
      loan_date: loan.loan_date || "",
      notes: loan.notes || "",
    });
  };

  const updateLoanMutation = useMutation({
    mutationFn: async () => {
      if (!editingLoan) throw new Error("Sem empréstimo");
      const { error } = await supabase
        .from("loans")
        .update({
          store_name: editForm.store_name,
          order_number: editForm.order_number,
          total_amount: editForm.total_amount,
          loan_date: editForm.loan_date,
          notes: editForm.notes,
        })
        .eq("id", editingLoan.id);
      if (error) throw error;

      // Atualizar parcelas automaticamente
      const count = Number(editingLoan.installments_count) || 1;
      const newPerInstallment = Number((editForm.total_amount / count).toFixed(2));

      // Atualiza valor apenas das parcelas pendentes (mantém parcelas pagas)
      const { error: instErr } = await supabase
        .from("installments")
        .update({ amount: newPerInstallment })
        .eq("loan_id", editingLoan.id)
        .neq("status", "paid");
      if (instErr) throw instErr;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loans"] });
      queryClient.invalidateQueries({ queryKey: ["installments"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      toast.success("Nota promissória e parcelas atualizadas!");
      setEditingLoan(null);
    },
    onError: (e: any) => toast.error("Erro ao atualizar", { description: e.message }),
  });



  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerId || !formData.storeName || formData.totalAmount <= 0) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    if (selectedCustomer?.credit_limit > 0) {
      const remainingLimit = selectedCustomer.credit_limit - selectedCustomer.totalBorrowed;
      if (formData.totalAmount > remainingLimit) {
        toast.error("Limite de crédito insuficiente", {
          description: `O cliente possui R$ ${remainingLimit.toLocaleString('pt-BR')} de limite disponível.`,
        });
        return;
      }
    }

    let markOverduePaid = false;
    if (overdueCount > 0) {
      markOverduePaid = confirm(
        `Existem ${overdueCount} parcela(s) com vencimento já em atraso. Deseja marcá-las como PAGAS automaticamente?`
      );
    }

    const payload = {
      ...formData,
      loanDate: formData.purchaseDate,
      firstDueDate: `${formData.paymentMonth}-10`,
      markOverduePaid,
    };
    mutation.mutate(payload);
  };


  if (customersLoading || loansLoading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="animate-spin text-primary" size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:justify-between md:items-center">
        <h1 className="text-2xl md:text-4xl font-black tracking-tight text-[#2A2A2A]">Gestão de <span className="gold-text">Notas Promissórias</span></h1>
        <Button className={`flex gap-2 shadow-xl transition-all h-12 px-6 w-full md:w-auto justify-center ${showForm ? "bg-red-500 hover:bg-red-600" : "btn-primary"}`} onClick={() => setShowForm(!showForm)}>
          <PlusCircle size={18} />
          {showForm ? "Cancelar" : "Nova Operação"}
        </Button>
      </div>

      {showForm && (
        <Card className="border-[#EAEAEA] bg-[#FFFFFF] shadow-2xl animate-in fade-in slide-in-from-top-4 duration-300 rounded-[32px] overflow-hidden">
          <CardHeader className="bg-[#F5EBEF] border-b border-[#EAEAEA]">
            <CardTitle className="flex items-center gap-2 text-[#C84D8A]">
              <Calculator size={20} />
              Registrar Operação
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-8 px-8 pb-8">
            <form onSubmit={handleSubmit} className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <div className="space-y-2 lg:col-span-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Cliente Beneficiário</Label>
                <Select onValueChange={(val) => setFormData({ ...formData, customerId: val })}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectValue placeholder="Selecione o cliente" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    {customers?.map((c: any) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Loja de Origem</Label>
                  <button
                    type="button"
                    onClick={() => setQuickStoreOpen(true)}
                    className="text-[10px] font-black uppercase tracking-widest text-[#C84D8A] hover:text-[#7D2958] flex items-center gap-1"
                  >
                    <PlusCircle size={12} /> Nova loja
                  </button>
                </div>
                <Select value={formData.storeName} onValueChange={(v) => setFormData({ ...formData, storeName: v })}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <div className="flex items-center gap-2">
                      <Store className="text-[#6B6B6B]" size={16} />
                      <SelectValue placeholder="Selecione a loja" />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                    {uniqueStores.length === 0 ? (
                      <div className="px-3 py-4 text-xs text-[#6B6B6B] text-center">Nenhuma loja cadastrada</div>
                    ) : (
                      uniqueStores.map(store => (
                        <SelectItem key={store} value={store}>{store}</SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              {quickStoreOpen && (
                <div className="rounded-2xl border border-[#C84D8A]/30 bg-[#F5EBEF] p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black uppercase tracking-widest text-[#7D2958]">Cadastrar nova loja</span>
                    <button type="button" onClick={() => setQuickStoreOpen(false)} className="text-[#6B6B6B] text-xs">Cancelar</button>
                  </div>
                  <Input
                    placeholder="Nome da loja"
                    value={quickStoreName}
                    onChange={(e) => setQuickStoreName(e.target.value)}
                    className="h-11 bg-white border-[#EAEAEA]"
                  />
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      placeholder="Comissão %"
                      value={quickStoreCommission || ""}
                      onChange={(e) => setQuickStoreCommission(Number(e.target.value))}
                      className="h-11 bg-white border-[#EAEAEA]"
                    />
                    <Button
                      type="button"
                      onClick={() => {
                        if (!quickStoreName.trim()) return toast.error("Informe o nome da loja");
                        quickStoreMut.mutate({ name: quickStoreName.trim(), commissionPercent: quickStoreCommission });
                      }}
                      disabled={quickStoreMut.isPending}
                      className="btn-primary text-[#7D2958] h-11 px-4 rounded-xl font-black uppercase text-xs whitespace-nowrap"
                    >
                      {quickStoreMut.isPending ? <Loader2 className="animate-spin" size={14} /> : "Cadastrar"}
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Nº do Pedido / Nota</Label>
                <div className="relative">
                  <Hash className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" size={16} />
                  <Input 
                    placeholder="Ex: #45882" 
                    className="h-12 pl-10 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                    value={formData.orderNumber}
                    onChange={(e) => setFormData({ ...formData, orderNumber: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Valor Total do Crédito</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B] font-bold">R$</span>
                  <Input 
                    type="number" 
                    placeholder="0,00" 
                    className="h-12 pl-10 text-lg font-bold text-[#C84D8A] bg-[#F5EBEF] border-[#EAEAEA]"
                    value={formData.totalAmount || ""}
                    onChange={(e) => setFormData({ ...formData, totalAmount: Number(e.target.value) })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Parcelamento (Até 5x)</Label>
                <Select defaultValue="1" onValueChange={(val) => setFormData({ ...formData, installmentsCount: Number(val) })}>
                  <SelectTrigger className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30">
                    <SelectValue placeholder="Qtd parcelas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1x (À vista)</SelectItem>
                    <SelectItem value="2">2x</SelectItem>
                    <SelectItem value="3">3x</SelectItem>
                    <SelectItem value="4">4x</SelectItem>
                    <SelectItem value="5">5x</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Data da Compra</Label>
                <Input 
                  type="date" 
                  className="h-12 bg-white border-[#EAEAEA] text-[#2A2A2A] focus:border-[#C84D8A] focus:ring-1 focus:ring-[#C84D8A]/30"
                  value={formData.purchaseDate}
                  onChange={(e) => {
                    const pd = e.target.value;
                    setFormData({ 
                      ...formData, 
                      purchaseDate: pd,
                      paymentMonth: computePaymentMonth(pd)
                    });
                  }}
                />
                <p className="text-[10px] text-[#6B6B6B]">
                  Sempre pula um mês inteiro: compra em janeiro, primeira cobrança em 10 de março.
                </p>
              </div>

              <div className="space-y-2 lg:col-span-2">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">1º Pagamento (Dia 10)</Label>
                <div className="h-12 px-4 flex items-center bg-[#F5EBEF] border border-[#C84D8A]/30 rounded-md">
                  <span className="text-base font-bold text-[#C84D8A] capitalize">
                    Dia 10 de {formatMonthFull(formData.paymentMonth)}
                  </span>
                </div>
                <p className="text-[10px] text-[#6B6B6B]">
                  Calculado automaticamente. Todas as parcelas vencem no dia 10 dos meses seguintes.
                </p>
              </div>

              {previewInstallments.length > 0 && formData.totalAmount > 0 && (
                <div className="lg:col-span-3 space-y-2">
                  <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">
                    Pré-visualização das Parcelas
                  </Label>
                  <div className="bg-[#F5EBEF] border border-[#EAEAEA] rounded-xl divide-y divide-white/5">
                    {previewInstallments.map(p => (
                      <div key={p.number} className={`flex items-center justify-between px-4 py-3 ${p.overdue ? "bg-red-500/10" : ""}`}>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-[#2A2A2A]">{p.number}ª parcela</span>
                          <span className="text-xs text-[#6B6B6B] capitalize">{formatDateOnlyLong(p.dueDate)}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-bold text-[#C84D8A]">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(installmentValue)}
                          </span>
                          {p.overdue && (
                            <span className="text-[10px] font-black uppercase text-red-400 bg-red-500/20 px-2 py-1 rounded">Em atraso</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  {overdueCount > 0 && (
                    <p className="text-[11px] text-red-400">
                      ⚠ {overdueCount} parcela(s) já estão em atraso. Ao salvar, o sistema perguntará se deseja marcá-las como pagas.
                    </p>
                  )}
                </div>
              )}





              {selectedCustomer && (
                <div className="bg-[#F5EBEF] p-4 rounded-xl space-y-2 border border-[#EAEAEA] shadow-inner">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] font-bold text-[#6B6B6B] uppercase">Limite Disponível</p>
                      <p className={`text-sm font-bold ${
                        (selectedCustomer.credit_limit - selectedCustomer.totalBorrowed - formData.totalAmount) < 0 
                        ? "text-red-400" 
                        : "text-green-400"
                      }`}>
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(
                          Math.max(0, selectedCustomer.credit_limit - selectedCustomer.totalBorrowed)
                        )}
                      </p>
                    </div>
                    <ShieldCheck size={20} className="text-[#C84D8A]/40" />
                  </div>
                  {formData.totalAmount > 0 && (
                    <div className="pt-2 border-t border-[#EAEAEA] flex items-center justify-between">
                      <div>
                        <p className="text-[10px] font-bold text-[#C84D8A] uppercase">Valor da Parcela</p>
                        <p className="text-xl font-black text-[#C84D8A]">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(installmentValue)}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}


              <div className="lg:col-span-3 p-6 bg-[#C84D8A]/5 border border-[#C84D8A]/20 rounded-2xl flex items-start gap-4">
                <Checkbox 
                  id="terms" 
                  className="mt-1 border-[#C84D8A]/50 data-[state=checked]:bg-[#C84D8A] data-[state=checked]:text-[#7D2958]" 
                  checked={formData.acceptTerms}
                  onCheckedChange={(val) => setFormData({ ...formData, acceptTerms: !!val })}
                />
                <div className="space-y-1">
                  <label htmlFor="terms" className="text-xs font-bold text-[#2A2A2A] cursor-pointer">
                    Gerar Contrato Jurídico VeraPay Security
                  </label>
                  <p className="text-[10px] text-[#6B6B6B] leading-relaxed">
                    Ao marcar esta opção, o sistema irá gerar um PDF automático com os termos de compromisso financeiro e as parcelas para assinatura eletrônica do cliente.
                  </p>
                </div>
              </div>

              <div className="space-y-2 lg:col-span-3">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Observações da Compra</Label>
                <div className="relative">
                   <FileText className="absolute left-3 top-3 text-[#6B6B6B]" size={16} />
                   <textarea 
                    placeholder="Acrescente detalhes sobre a compra, produtos, ou condições especiais..." 
                    className="w-full min-h-[100px] pl-10 pt-2 bg-[#F5EBEF] border border-[#EAEAEA] rounded-2xl text-[#2A2A2A] focus:ring-[#C84D8A]/20 focus:border-[#C84D8A]/30 outline-none transition-all text-sm"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2 lg:col-span-3">
                <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Documento de Origem (Opcional)</Label>
                <input 
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  ref={fileInputRef} 
                  onChange={handleFileUpload}
                />
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex items-center justify-center w-full h-24 border-2 border-dashed rounded-2xl transition-colors cursor-pointer group ${
                    formData.attachmentUrl 
                      ? "border-green-500/50 bg-green-500/5" 
                      : "border-[#EAEAEA] bg-[#F5EBEF] hover:border-[#C84D8A]/30"
                  }`}
                >
                  <div className="text-center">
                    {uploading ? (
                      <Loader2 size={24} className="mx-auto text-[#C84D8A] animate-spin" />
                    ) : formData.attachmentUrl ? (
                      <>
                        <CheckCircle2 size={24} className="mx-auto text-green-500 mb-1" />
                        <span className="text-[10px] text-green-500 font-bold uppercase block">Foto Anexada!</span>
                      </>
                    ) : (
                      <>
                        <PlusCircle size={24} className="mx-auto text-[#6B6B6B] group-hover:text-[#C84D8A] mb-1" />
                        <span className="text-[10px] text-[#6B6B6B] font-bold uppercase block">Anexar Comprovante / Foto</span>
                      </>
                    )}
                  </div>
                </div>
              </div>


              <div className="flex items-end lg:col-span-3">
                <Button className="w-full h-16 text-lg font-black btn-primary uppercase tracking-[0.2em] shadow-2xl" type="submit" disabled={mutation.isPending || !formData.acceptTerms}>
                  {mutation.isPending ? <Loader2 className="animate-spin mr-2" /> : <FileText className="mr-2" />}
                  Gerar Contrato e Ativar Crédito
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card className="shadow-2xl border-none overflow-hidden bg-[#FFFFFF] rounded-[32px] border border-[#EAEAEA]">
        <CardHeader className="bg-[#F5EBEF] border-b border-[#EAEAEA]">
          <CardTitle className="text-[#2A2A2A]">Histórico de Operações</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {/* Mobile card list */}
          <div className="md:hidden divide-y divide-[#EAEAEA]">
            {!loans || loans.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground italic">Nenhum empréstimo registrado.</div>
            ) : (
              loans.map((loan: any) => {
                const customer = customers?.find((c: any) => c.id === loan.customer_id);
                return (
                  <div key={loan.id} className="p-4 space-y-3">
                    <div className="flex items-start justify-between gap-3 min-w-0">
                      <div className="min-w-0 flex-1">
                        <p className="font-bold text-[#2A2A2A] truncate">{customer?.name || "Cliente Excluído"}</p>
                        <p className="text-xs text-[#6B6B6B] mt-0.5">{formatDateOnly(loan.loan_date)}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-black text-[#C84D8A] text-lg whitespace-nowrap">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(loan.total_amount)}
                        </p>
                        <span className="bg-[#F5EBEF] px-2 py-0.5 rounded-md text-[10px] font-black text-[#6B6B6B] border border-[#EAEAEA]">
                          {loan.installments_count}x
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <span className="inline-flex items-center gap-1 bg-[#F5EBEF] px-2 py-1 rounded-md text-[#2A2A2A] font-bold">
                        <ShoppingBag size={12} className="text-[#C84D8A]" /> {loan.store_name}
                      </span>
                      {loan.order_number && (
                        <span className="inline-flex items-center gap-1 text-[#6B6B6B]">
                          <Hash size={10} /> {loan.order_number}
                        </span>
                      )}
                      <span className={`inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-wider ml-auto ${
                        loan.status === 'active' ? 'text-blue-500' : 'text-emerald-500'
                      }`}>
                        <ShieldCheck size={12} /> {loan.status === 'active' ? 'Ativo' : 'Finalizado'}
                      </span>
                    </div>
                    <div className="flex gap-2 pt-1">
                      {loan.attachment_url && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 h-10 rounded-xl text-blue-500 border-blue-200"
                          onClick={() => window.open(loan.attachment_url, '_blank')}
                        >
                          <ImageIcon size={16} className="shrink-0" />
                          <span className="ml-1 truncate">Anexo</span>
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 h-10 rounded-xl text-[#C84D8A] border-[#F5EBEF]"
                        onClick={() => generateLoanPDF(loan, customer)}
                      >
                        <FileText size={16} className="shrink-0" />
                        <span className="ml-1 truncate">PDF</span>
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-10 w-10 rounded-xl text-blue-500 border-blue-200 shrink-0 p-0"
                        onClick={() => openEditLoan(loan)}
                        title="Editar"
                      >
                        <Pencil size={16} />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-10 w-10 rounded-xl text-destructive border-destructive/20 shrink-0 p-0"
                        onClick={() => {
                          if (!requireAdminPassword("excluir este empréstimo")) return;
                          if (confirm("Deseja realmente excluir este empréstimo?")) {
                            deleteLoanMutation.mutate(loan.id);
                          }
                        }}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Desktop table */}
          <Table className="hidden md:table">
            <TableHeader className="bg-[#F5EBEF]">
              <TableRow className="border-[#EAEAEA] hover:bg-transparent">
                <TableHead className="font-bold py-4 pl-6 text-[#6B6B6B]">Data</TableHead>
                <TableHead className="font-bold text-[#6B6B6B]">Cliente</TableHead>
                <TableHead className="font-bold text-[#6B6B6B]">Loja</TableHead>
                <TableHead className="font-bold text-right text-[#6B6B6B]">Valor Total</TableHead>
                <TableHead className="font-bold text-center text-[#6B6B6B]">Parcelas</TableHead>
                <TableHead className="font-bold text-[#6B6B6B]">Status</TableHead>
                <TableHead className="text-right pr-6 font-bold text-[#6B6B6B]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {!loans || loans.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground italic">
                    Nenhum empréstimo registrado.
                  </TableCell>
                </TableRow>
              ) : (
                loans.map((loan: any) => {
                  const customer = customers?.find((c: any) => c.id === loan.customer_id);
                  return (
                    <TableRow key={loan.id} className="hover:bg-[#F5EBEF]/80 transition-colors border-[#EAEAEA] group h-20">
                      <TableCell className="pl-6 py-4 font-medium text-[#6B6B6B]">
                        {formatDateOnly(loan.loan_date)}
                      </TableCell>
                      <TableCell className="font-bold text-[#2A2A2A]">
                        {customer?.name || "Cliente Excluído"}
                      </TableCell>
                      <TableCell className="py-4">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-2">
                            <ShoppingBag size={14} className="text-[#C84D8A]" />
                            <span className="text-sm font-bold text-[#2A2A2A]">{loan.store_name}</span>
                          </div>
                          {loan.order_number && (
                            <span className="text-[10px] uppercase tracking-tighter text-[#6B6B6B] mt-1 flex items-center gap-1">
                              <Hash size={10} /> {loan.order_number}
                            </span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-black text-[#C84D8A] text-lg">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(loan.total_amount)}
                      </TableCell>
                      <TableCell className="text-center font-bold">
                        <span className="bg-[#F5EBEF] px-3 py-1 rounded-lg text-[10px] font-black text-[#6B6B6B] border border-[#EAEAEA]">
                          {loan.installments_count}x
                        </span>
                      </TableCell>
                      <TableCell>
                         <span className={`inline-flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${
                           loan.status === 'active' ? 'text-blue-400' : 'text-emerald-400'
                         }`}>
                            <ShieldCheck size={12} /> {loan.status === 'active' ? 'Ativo' : 'Finalizado'}
                         </span>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          {loan.attachment_url && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-9 w-9 rounded-xl text-blue-400 hover:bg-blue-400/10"
                              onClick={() => window.open(loan.attachment_url, '_blank')}
                              title="Ver anexo"
                            >
                              <ImageIcon size={18} />
                            </Button>
                          )}
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-9 w-9 rounded-xl text-[#C84D8A] hover:bg-[#C84D8A]/10"
                            onClick={() => generateLoanPDF(loan, customer)}
                            title="Gerar PDF"
                          >
                            <FileText size={18} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-9 w-9 rounded-xl text-blue-500 hover:bg-blue-500/10"
                            onClick={() => openEditLoan(loan)}
                            title="Editar nota"
                          >
                            <Pencil size={18} />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10 h-9 w-9 rounded-xl" onClick={() => {
                            if (!requireAdminPassword("excluir este empréstimo")) return;
                            if (confirm("Deseja realmente excluir este empréstimo?")) {
                              deleteLoanMutation.mutate(loan.id);
                            }
                          }}>
                            <Trash2 size={18} />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!editingLoan} onOpenChange={(o) => !o && setEditingLoan(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#C84D8A] flex items-center gap-2">
              <Pencil size={18} /> Editar Nota Promissória
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Loja</Label>
              <Select value={editForm.store_name} onValueChange={(v) => setEditForm({ ...editForm, store_name: v })}>
                <SelectTrigger className="h-11 bg-white border-[#EAEAEA]">
                  <SelectValue placeholder="Selecione a loja" />
                </SelectTrigger>
                <SelectContent>
                  {uniqueStores.map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Nº do Pedido / Nota</Label>
              <Input
                value={editForm.order_number}
                onChange={(e) => setEditForm({ ...editForm, order_number: e.target.value })}
                className="h-11 bg-white border-[#EAEAEA]"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Valor Total</Label>
              <Input
                type="number"
                step="0.01"
                value={editForm.total_amount || ""}
                onChange={(e) => setEditForm({ ...editForm, total_amount: Number(e.target.value) })}
                className="h-11 bg-white border-[#EAEAEA]"
              />
              <p className="text-[10px] text-[#6B6B6B]">Atenção: alterar o valor total não recalcula automaticamente as parcelas já criadas.</p>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Data da Compra</Label>
              <Input
                type="date"
                value={editForm.loan_date}
                onChange={(e) => setEditForm({ ...editForm, loan_date: e.target.value })}
                className="h-11 bg-white border-[#EAEAEA]"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-[#6B6B6B]">Observações</Label>
              <textarea
                value={editForm.notes}
                onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                className="w-full min-h-[80px] p-3 bg-white border border-[#EAEAEA] rounded-md text-sm"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingLoan(null)}>Cancelar</Button>
            <Button
              className="btn-primary"
              onClick={() => updateLoanMutation.mutate()}
              disabled={updateLoanMutation.isPending}
            >
              {updateLoanMutation.isPending ? <Loader2 className="animate-spin mr-2" size={16} /> : null}
              Salvar Alterações
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
