import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { lookupSignupToken, registerCustomerByToken } from "../serverFunctions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2, UserPlus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { formatCpf, cleanCpf, isValidCpf } from "@/lib/cpf";

export const Route = createFileRoute("/cadastro-cliente/$token")({
  component: PublicSignup,
});

function PublicSignup() {
  const { token } = Route.useParams();
  const [done, setDone] = useState(false);
  const [isSearchingCep, setIsSearchingCep] = useState(false);
  const [form, setForm] = useState({
    name: "", phone: "", secondary_phone: "", cpf: "",
    cep: "", address_street: "", address_number: "", address_complement: "",
    address_neighborhood: "", address_city: "", address_state: "",
  });

  const { data, isLoading, error } = useQuery({
    queryKey: ["signup-token", token],
    queryFn: () => lookupSignupToken({ data: { token } }),
    retry: false,
  });

  const mutation = useMutation({
    mutationFn: (payload: any) => registerCustomerByToken({ data: payload }),
    onSuccess: () => { setDone(true); toast.success("Cadastro enviado!"); },
    onError: (e: any) => toast.error(e?.message || "Erro ao cadastrar"),
  });

  const searchCep = async (cep: string) => {
    const clean = cep.replace(/\D/g, "");
    if (clean.length !== 8) return;
    setIsSearchingCep(true);
    try {
      const r = await fetch(`https://viacep.com.br/ws/${clean}/json/`);
      const j = await r.json();
      if (!j.erro) {
        setForm((f) => ({
          ...f,
          address_street: j.logradouro || "",
          address_neighborhood: j.bairro || "",
          address_city: j.localidade || "",
          address_state: j.uf || "",
        }));
      }
    } finally { setIsSearchingCep(false); }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return toast.error("Preencha nome e telefone");
    if (!isValidCpf(form.cpf)) return toast.error("CPF inválido");
    mutation.mutate({ ...form, cpf: cleanCpf(form.cpf), token });
  };

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  }
  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full"><CardContent className="pt-6 text-center">
          <p className="text-destructive font-semibold">Link de cadastro inválido ou expirado.</p>
        </CardContent></Card>
      </div>
    );
  }
  if (done) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="max-w-md w-full"><CardContent className="pt-6 text-center space-y-3">
          <CheckCircle2 className="mx-auto text-green-500" size={48} />
          <h2 className="text-xl font-bold">Cadastro enviado!</h2>
          <p className="text-muted-foreground">Aguarde o contato de {data.adminName} para liberação.</p>
        </CardContent></Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 flex items-start justify-center py-8">
      <Card className="max-w-2xl w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><UserPlus /> Cadastro de Cliente</CardTitle>
          <p className="text-sm text-muted-foreground">Preencha seus dados para {data.adminName}</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Nome completo *</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div>
                <Label>CPF *</Label>
                <Input value={formatCpf(form.cpf)} onChange={(e) => setForm({ ...form, cpf: e.target.value })} maxLength={14} required />
              </div>
              <div>
                <Label>Telefone *</Label>
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} required />
              </div>
              <div>
                <Label>Telefone secundário</Label>
                <Input value={form.secondary_phone} onChange={(e) => setForm({ ...form, secondary_phone: e.target.value })} />
              </div>
              <div className="relative">
                <Label>CEP</Label>
                <Input value={form.cep} onChange={(e) => { setForm({ ...form, cep: e.target.value }); searchCep(e.target.value); }} />
                {isSearchingCep && <Loader2 className="absolute right-2 top-8 animate-spin" size={14} />}
              </div>
              <div>
                <Label>Estado</Label>
                <Input value={form.address_state} onChange={(e) => setForm({ ...form, address_state: e.target.value })} />
              </div>
              <div className="md:col-span-2">
                <Label>Rua</Label>
                <Input value={form.address_street} onChange={(e) => setForm({ ...form, address_street: e.target.value })} />
              </div>
              <div>
                <Label>Número</Label>
                <Input value={form.address_number} onChange={(e) => setForm({ ...form, address_number: e.target.value })} />
              </div>
              <div>
                <Label>Complemento</Label>
                <Input value={form.address_complement} onChange={(e) => setForm({ ...form, address_complement: e.target.value })} />
              </div>
              <div>
                <Label>Bairro</Label>
                <Input value={form.address_neighborhood} onChange={(e) => setForm({ ...form, address_neighborhood: e.target.value })} />
              </div>
              <div>
                <Label>Cidade</Label>
                <Input value={form.address_city} onChange={(e) => setForm({ ...form, address_city: e.target.value })} />
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={mutation.isPending}>
              {mutation.isPending ? <Loader2 className="animate-spin mr-2" size={16} /> : null}
              Enviar cadastro
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
