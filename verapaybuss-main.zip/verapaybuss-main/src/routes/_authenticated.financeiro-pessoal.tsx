import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Wallet,
  TrendingDown,
  TrendingUp,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Calendar,
  CreditCard,
  Target,
  PieChart,
  Repeat,
  Trash2,
  AlertTriangle,
  Sparkles,
  Shield,
  LineChart as LineChartIcon,
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, AreaChart, Area } from "recharts";
import { Button } from "@/components/ui/button";
import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";

export const Route = createFileRoute("/_authenticated/financeiro-pessoal")({
  component: FinanceiroPessoal,
});

const BRL = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);

const monthStart = () => {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().split("T")[0];
};
const monthEnd = () => {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().split("T")[0];
};

async function getUserId() {
  const { data } = await supabase.auth.getUser();
  if (!data.user) throw new Error("Não autenticado");
  return data.user.id;
}

function FinanceiroPessoal() {
  const qc = useQueryClient();

  // ============ QUERIES ============
  const { data: transactions = [] } = useQuery({
    queryKey: ["personal_transactions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("personal_transactions")
        .select("*")
        .gte("transaction_date", monthStart())
        .lte("transaction_date", monthEnd())
        .order("transaction_date", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["personal_categories"],
    queryFn: async () => {
      const { data, error } = await supabase.from("personal_categories").select("*").order("name");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: recurringBills = [] } = useQuery({
    queryKey: ["personal_recurring_bills"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("personal_recurring_bills")
        .select("*")
        .order("due_day");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: creditCards = [] } = useQuery({
    queryKey: ["personal_credit_cards"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("personal_credit_cards")
        .select("*")
        .order("name");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: ccExpenses = [] } = useQuery({
    queryKey: ["personal_cc_expenses"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("personal_credit_card_expenses")
        .select("*")
        .order("purchase_date", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["personal_goals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("personal_goals")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    },
  });

  // Last 12 months of transactions for patrimony chart & averages
  const { data: yearTx = [] } = useQuery({
    queryKey: ["personal_transactions_year"],
    queryFn: async () => {
      const d = new Date();
      const start = new Date(d.getFullYear(), d.getMonth() - 11, 1).toISOString().split("T")[0];
      const { data, error } = await supabase
        .from("personal_transactions")
        .select("transaction_date,amount,type")
        .gte("transaction_date", start);
      if (error) throw error;
      return data || [];
    },
  });

  // ============ DERIVED METRICS ============
  const totalIncome = useMemo(
    () => transactions.filter((t: any) => t.type === "income").reduce((a, t: any) => a + Number(t.amount), 0),
    [transactions]
  );
  const totalExpense = useMemo(
    () => transactions.filter((t: any) => t.type === "expense").reduce((a, t: any) => a + Number(t.amount), 0),
    [transactions]
  );
  const balance = totalIncome - totalExpense;

  // Spending per category this month
  const spendByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of transactions as any[]) {
      if (t.type !== "expense") continue;
      const key = t.category_name || "Sem categoria";
      map[key] = (map[key] || 0) + Number(t.amount);
    }
    return map;
  }, [transactions]);

  // Upcoming recurring bills in next 7 days
  const upcomingBills = useMemo(() => {
    const today = new Date();
    return (recurringBills as any[])
      .filter((b: any) => b.active)
      .map((b: any) => {
        const day = b.due_day;
        const next = new Date(today.getFullYear(), today.getMonth(), day);
        if (next < today) next.setMonth(next.getMonth() + 1);
        const diff = Math.round((next.getTime() - today.getTime()) / 86400000);
        return { ...b, nextDate: next, daysUntil: diff };
      })
      .filter((b) => b.daysUntil <= 7)
      .sort((a, b) => a.daysUntil - b.daysUntil);
  }, [recurringBills]);

  // CC bill total per card (current month)
  const ccBillsByCard = useMemo(() => {
    const m: Record<string, number> = {};
    for (const e of ccExpenses as any[]) {
      const installment = Number(e.total_amount) / e.installments;
      m[e.credit_card_id] = (m[e.credit_card_id] || 0) + installment;
    }
    return m;
  }, [ccExpenses]);

  // ============ PHASE 2: Patrimony chart (last 12 months cumulative balance) ============
  const patrimonyData = useMemo(() => {
    const months: { key: string; label: string; income: number; expense: number }[] = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", "");
      months.push({ key, label, income: 0, expense: 0 });
    }
    for (const t of yearTx as any[]) {
      const dt = new Date(t.transaction_date);
      const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}`;
      const m = months.find((x) => x.key === key);
      if (!m) continue;
      if (t.type === "income") m.income += Number(t.amount);
      else m.expense += Number(t.amount);
    }
    let cumulative = 0;
    return months.map((m) => {
      const net = m.income - m.expense;
      cumulative += net;
      return { mes: m.label, saldo: Number(cumulative.toFixed(2)), entradas: m.income, saidas: m.expense, liquido: net };
    });
  }, [yearTx]);

  // Average monthly expense (last 6 closed months, excludes current)
  const avgMonthlyExpense = useMemo(() => {
    const past = patrimonyData.slice(0, -1).slice(-6);
    if (past.length === 0) return totalExpense || 0;
    return past.reduce((a, m) => a + m.saidas, 0) / past.length;
  }, [patrimonyData, totalExpense]);

  // Future balance forecast (next 3 months using recurring bills)
  const forecast = useMemo(() => {
    const currentBalance = patrimonyData.length ? patrimonyData[patrimonyData.length - 1].saldo : 0;
    const monthlyRecurringIncome = (recurringBills as any[]).filter((b) => b.active && b.type === "income").reduce((a, b) => a + Number(b.amount), 0);
    const monthlyRecurringExpense = (recurringBills as any[]).filter((b) => b.active && b.type === "expense").reduce((a, b) => a + Number(b.amount), 0);
    const monthlyNet = monthlyRecurringIncome - monthlyRecurringExpense;
    const out: { mes: string; previsto: number }[] = [];
    const now = new Date();
    let running = currentBalance;
    for (let i = 1; i <= 3; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
      running += monthlyNet;
      out.push({ mes: d.toLocaleDateString("pt-BR", { month: "short" }).replace(".", ""), previsto: Number(running.toFixed(2)) });
    }
    return { rows: out, monthlyNet, monthlyRecurringIncome, monthlyRecurringExpense };
  }, [patrimonyData, recurringBills]);

  // Emergency reserve (goal identified by name)
  const emergencyGoal = useMemo(
    () => (goals as any[]).find((g) => g.name?.toLowerCase().includes("emerg")),
    [goals]
  );
  const emergencyTarget = avgMonthlyExpense * 6;
  const emergencyCurrent = Number(emergencyGoal?.current_amount || 0);
  const emergencyPct = emergencyTarget > 0 ? Math.min((emergencyCurrent / emergencyTarget) * 100, 100) : 0;

  // ============ MUTATIONS ============
  const invalidate = (key: string) => qc.invalidateQueries({ queryKey: [key] });

  const addTransaction = useMutation({
    mutationFn: async (t: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_transactions").insert({ ...t, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_transactions");
      toast.success("Lançamento registrado!");
    },
    onError: (e: any) => toast.error(e.message),
  });

  const deleteTransaction = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_transactions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_transactions");
      toast.success("Lançamento removido");
    },
  });

  const addCategory = useMutation({
    mutationFn: async (c: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_categories").insert({ ...c, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_categories");
      toast.success("Categoria criada!");
    },
  });

  const deleteCategory = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_categories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate("personal_categories"),
  });

  const addRecurring = useMutation({
    mutationFn: async (r: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_recurring_bills").insert({ ...r, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_recurring_bills");
      toast.success("Conta fixa adicionada!");
    },
  });

  const deleteRecurring = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_recurring_bills").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate("personal_recurring_bills"),
  });

  const payRecurring = useMutation({
    mutationFn: async (bill: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_transactions").insert({
        user_id,
        description: bill.description,
        amount: bill.amount,
        type: bill.type,
        category_name: bill.category_name,
        category_id: bill.category_id,
        transaction_date: new Date().toISOString().split("T")[0],
        recurring_bill_id: bill.id,
        source: "recurring",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_transactions");
      toast.success("Conta paga e registrada!");
    },
  });

  const addCard = useMutation({
    mutationFn: async (c: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_credit_cards").insert({ ...c, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_credit_cards");
      toast.success("Cartão cadastrado!");
    },
  });

  const deleteCard = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_credit_cards").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_credit_cards");
      invalidate("personal_cc_expenses");
    },
  });

  const addCcExpense = useMutation({
    mutationFn: async (e: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_credit_card_expenses").insert({ ...e, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_cc_expenses");
      toast.success("Compra registrada no cartão!");
    },
  });

  const deleteCcExpense = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_credit_card_expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate("personal_cc_expenses"),
  });

  const addGoal = useMutation({
    mutationFn: async (g: any) => {
      const user_id = await getUserId();
      const { error } = await supabase.from("personal_goals").insert({ ...g, user_id });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate("personal_goals");
      toast.success("Meta criada!");
    },
  });

  const updateGoal = useMutation({
    mutationFn: async ({ id, ...g }: any) => {
      const { error } = await supabase.from("personal_goals").update(g).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate("personal_goals"),
  });

  const deleteGoal = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("personal_goals").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => invalidate("personal_goals"),
  });

  // ============ Smart alerts ============
  const smartAlerts = useMemo(() => {
    const list: { severity: "high" | "medium" | "low"; msg: string }[] = [];
    for (const cat of categories as any[]) {
      if (!cat.monthly_budget || cat.monthly_budget <= 0) continue;
      const spent = spendByCategory[cat.name] || 0;
      const pct = (spent / Number(cat.monthly_budget)) * 100;
      if (pct >= 100)
        list.push({ severity: "high", msg: `Orçamento estourado em "${cat.name}": ${BRL(spent)} de ${BRL(Number(cat.monthly_budget))}.` });
      else if (pct >= 80)
        list.push({ severity: "medium", msg: `"${cat.name}" já consumiu ${pct.toFixed(0)}% do orçamento (${BRL(spent)}).` });
    }
    for (const b of upcomingBills) {
      if (b.daysUntil <= 2)
        list.push({ severity: "medium", msg: `${b.description} vence em ${b.daysUntil === 0 ? "hoje" : `${b.daysUntil} dia(s)`} — ${BRL(Number(b.amount))}.` });
    }
    if (forecast.monthlyNet < 0)
      list.push({ severity: "high", msg: `Previsão negativa: suas contas fixas superam as receitas fixas em ${BRL(Math.abs(forecast.monthlyNet))} por mês.` });
    if (emergencyTarget > 0 && emergencyPct < 50)
      list.push({ severity: "medium", msg: `Reserva de emergência em ${emergencyPct.toFixed(0)}% da meta (${BRL(emergencyTarget)}). Foque em construir esse colchão.` });
    return list;
  }, [categories, spendByCategory, upcomingBills, forecast, emergencyTarget, emergencyPct]);

  // ============ Form States ============
  const [txForm, setTxForm] = useState({ description: "", amount: "", category_name: "", type: "expense" as "income" | "expense", transaction_date: new Date().toISOString().split("T")[0] });
  const [openTx, setOpenTx] = useState(false);

  return (
    <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto pb-20">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between border-b border-[#EAEAEA] pb-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-[#2A2A2A]">
            Financeiro <span className="gold-text">Pessoal</span>
          </h1>
          <p className="text-[#6B6B6B] font-medium italic mt-1">Controle completo: lançamentos, contas fixas, cartões, orçamento e metas.</p>
        </div>

        <Dialog open={openTx} onOpenChange={setOpenTx}>
          <DialogTrigger asChild>
            <Button className="h-12 rounded-xl bg-[#C84D8A] hover:bg-[#C84D8A]/90 text-[#7D2958] gap-2 font-bold px-6">
              <Plus size={18} /> Novo Lançamento
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
            <DialogHeader>
              <DialogTitle>Novo Lançamento</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3">
                <Button
                  type="button"
                  variant={txForm.type === "income" ? "default" : "outline"}
                  className={txForm.type === "income" ? "bg-emerald-500 text-white" : "border-[#EAEAEA]"}
                  onClick={() => setTxForm({ ...txForm, type: "income" })}
                >
                  Entrada
                </Button>
                <Button
                  type="button"
                  variant={txForm.type === "expense" ? "default" : "outline"}
                  className={txForm.type === "expense" ? "bg-rose-500 text-white" : "border-[#EAEAEA]"}
                  onClick={() => setTxForm({ ...txForm, type: "expense" })}
                >
                  Saída
                </Button>
              </div>
              <div className="space-y-2">
                <Label>Descrição</Label>
                <Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={txForm.description} onChange={(e) => setTxForm({ ...txForm, description: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Valor</Label>
                  <Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={txForm.amount} onChange={(e) => setTxForm({ ...txForm, amount: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Data</Label>
                  <Input type="date" className="bg-[#F5EBEF] border-[#EAEAEA]" value={txForm.transaction_date} onChange={(e) => setTxForm({ ...txForm, transaction_date: e.target.value })} />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Categoria</Label>
                <Select value={txForm.category_name} onValueChange={(v) => setTxForm({ ...txForm, category_name: v })}>
                  <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                    {(categories as any[]).filter((c: any) => c.type === txForm.type).map((c: any) => (
                      <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                    ))}
                    <SelectItem value="Sem categoria">Sem categoria</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                onClick={() => {
                  if (!txForm.description || !txForm.amount) return toast.error("Preencha descrição e valor");
                  addTransaction.mutate({
                    description: txForm.description,
                    amount: parseFloat(txForm.amount),
                    type: txForm.type,
                    category_name: txForm.category_name || null,
                    transaction_date: txForm.transaction_date,
                  });
                  setTxForm({ description: "", amount: "", category_name: "", type: txForm.type, transaction_date: new Date().toISOString().split("T")[0] });
                  setOpenTx(false);
                }}
                className="bg-[#C84D8A] text-[#7D2958] font-bold hover:bg-[#C84D8A]/90"
              >
                Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </header>

      {/* SUMMARY CARDS */}
      <div className="grid gap-4 md:grid-cols-4">
        <StatCard label="Saldo do Mês" value={BRL(balance)} icon={Wallet} color="blue" />
        <StatCard label="Entradas" value={BRL(totalIncome)} icon={ArrowUpRight} color="emerald" />
        <StatCard label="Saídas" value={BRL(totalExpense)} icon={ArrowDownRight} color="rose" />
        <StatCard label="Contas Fixas Ativas" value={String((recurringBills as any[]).filter((b: any) => b.active).length)} icon={Repeat} color="amber" />
      </div>

      {/* SMART ALERTS */}
      {smartAlerts.length > 0 && (
        <Card className="border-none bg-[#FFFFFF] rounded-[24px] border border-amber-500/20 p-6 shadow-2xl">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={18} className="text-[#C84D8A]" />
            <h3 className="font-black uppercase text-sm tracking-wide text-[#2A2A2A]">Alertas Inteligentes — VERA Pessoal</h3>
          </div>
          <div className="space-y-2">
            {smartAlerts.map((a, i) => (
              <motion.div key={i} initial={{ x: -10, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: i * 0.05 }} className={`flex items-start gap-2 p-3 rounded-xl text-sm ${
                a.severity === "high" ? "bg-rose-500/10 text-rose-300 border border-rose-500/20" :
                a.severity === "medium" ? "bg-amber-500/10 text-amber-300 border border-amber-500/20" :
                "bg-blue-500/10 text-blue-300 border border-blue-500/20"
              }`}>
                <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
                <span>{a.msg}</span>
              </motion.div>
            ))}
          </div>
        </Card>
      )}

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-[#FFFFFF] border border-[#EAEAEA] p-1 rounded-2xl h-auto flex-wrap">
          <TabsTrigger value="overview" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><PieChart size={14} className="mr-1.5" /> Visão Geral</TabsTrigger>
          <TabsTrigger value="transactions" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><Wallet size={14} className="mr-1.5" /> Lançamentos</TabsTrigger>
          <TabsTrigger value="recurring" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><Repeat size={14} className="mr-1.5" /> Contas Fixas</TabsTrigger>
          <TabsTrigger value="cards" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><CreditCard size={14} className="mr-1.5" /> Cartões</TabsTrigger>
          <TabsTrigger value="budget" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><PieChart size={14} className="mr-1.5" /> Orçamento</TabsTrigger>
          <TabsTrigger value="goals" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><Target size={14} className="mr-1.5" /> Metas</TabsTrigger>
          <TabsTrigger value="patrimony" className="rounded-xl data-[state=active]:bg-[#C84D8A] data-[state=active]:text-[#7D2958]"><LineChartIcon size={14} className="mr-1.5" /> Patrimônio</TabsTrigger>
        </TabsList>

        {/* PATRIMONY (Phase 2) */}
        <TabsContent value="patrimony" className="space-y-6">
          <PatrimonyTab
            patrimonyData={patrimonyData}
            forecast={forecast}
            avgMonthlyExpense={avgMonthlyExpense}
            emergencyGoal={emergencyGoal}
            emergencyTarget={emergencyTarget}
            emergencyCurrent={emergencyCurrent}
            emergencyPct={emergencyPct}
            onCreateEmergency={() => addGoal.mutate({ name: "Reserva de Emergência", target_amount: emergencyTarget || 6000, current_amount: 0, icon: "Shield", color: "#10b981" })}
            onContribute={(amount: number) => {
              if (!emergencyGoal) return;
              updateGoal.mutate({ id: emergencyGoal.id, current_amount: Number(emergencyGoal.current_amount) + amount });
            }}
          />
        </TabsContent>

        {/* OVERVIEW */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
              <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B] mb-4">Próximas Contas (7 dias)</h3>
              {upcomingBills.length === 0 ? (
                <p className="text-[#6B6B6B] text-sm">Nenhuma conta nos próximos 7 dias.</p>
              ) : (
                <div className="space-y-2">
                  {upcomingBills.map((b: any) => (
                    <div key={b.id} className="flex items-center justify-between p-3 rounded-xl bg-[#F5EBEF]">
                      <div>
                        <p className="font-bold text-[#2A2A2A] text-sm">{b.description}</p>
                        <p className="text-xs text-[#6B6B6B]">{b.daysUntil === 0 ? "Vence hoje" : `Em ${b.daysUntil} dia(s)`}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-black text-[#C84D8A]">{BRL(Number(b.amount))}</p>
                        <Button size="sm" variant="ghost" className="text-xs h-6 text-emerald-400" onClick={() => payRecurring.mutate(b)}>Pagar</Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
              <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B] mb-4">Orçamento por Categoria</h3>
              {(categories as any[]).filter((c: any) => c.type === "expense" && c.monthly_budget > 0).length === 0 ? (
                <p className="text-[#6B6B6B] text-sm">Defina orçamentos na aba Orçamento.</p>
              ) : (
                <div className="space-y-3">
                  {(categories as any[]).filter((c: any) => c.type === "expense" && c.monthly_budget > 0).map((c: any) => {
                    const spent = spendByCategory[c.name] || 0;
                    const pct = Math.min((spent / Number(c.monthly_budget)) * 100, 100);
                    return (
                      <div key={c.id} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-bold text-[#2A2A2A]">{c.name}</span>
                          <span className={pct >= 100 ? "text-rose-400" : pct >= 80 ? "text-amber-400" : "text-[#6B6B6B]"}>
                            {BRL(spent)} / {BRL(Number(c.monthly_budget))}
                          </span>
                        </div>
                        <Progress value={pct} className="h-2 bg-[#F5EBEF]" />
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>
        </TabsContent>

        {/* TRANSACTIONS */}
        <TabsContent value="transactions">
          <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
            <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B] mb-4">Lançamentos do Mês</h3>
            {transactions.length === 0 ? (
              <p className="text-[#6B6B6B] text-sm">Nenhum lançamento ainda. Clique em "Novo Lançamento".</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-[#EAEAEA] hover:bg-transparent">
                    <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Data</TableHead>
                    <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Descrição</TableHead>
                    <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Categoria</TableHead>
                    <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Valor</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((t: any) => (
                    <TableRow key={t.id} className="border-[#EAEAEA]">
                      <TableCell className="text-[#6B6B6B] text-xs">{new Date(t.transaction_date).toLocaleDateString("pt-BR")}</TableCell>
                      <TableCell className="font-bold text-[#2A2A2A]">{t.description}</TableCell>
                      <TableCell><Badge variant="outline" className="text-xs border-[#EAEAEA] text-[#6B6B6B]">{t.category_name || "—"}</Badge></TableCell>
                      <TableCell className={`font-black ${t.type === "income" ? "text-emerald-400" : "text-rose-400"}`}>
                        {t.type === "income" ? "+" : "-"}{BRL(Number(t.amount))}
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="ghost" onClick={() => deleteTransaction.mutate(t.id)} className="text-[#6B6B6B] hover:text-rose-400 h-8 w-8 p-0">
                          <Trash2 size={14} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Card>
        </TabsContent>

        {/* RECURRING BILLS */}
        <TabsContent value="recurring">
          <RecurringTab bills={recurringBills} categories={categories} onAdd={(r: any) => addRecurring.mutate(r)} onDelete={(id: string) => deleteRecurring.mutate(id)} onPay={(b: any) => payRecurring.mutate(b)} />
        </TabsContent>

        {/* CARDS */}
        <TabsContent value="cards">
          <CardsTab
            cards={creditCards}
            expenses={ccExpenses}
            categories={categories}
            billsByCard={ccBillsByCard}
            onAddCard={(c: any) => addCard.mutate(c)}
            onDeleteCard={(id: string) => deleteCard.mutate(id)}
            onAddExpense={(e: any) => addCcExpense.mutate(e)}
            onDeleteExpense={(id: string) => deleteCcExpense.mutate(id)}
          />
        </TabsContent>

        {/* BUDGET */}
        <TabsContent value="budget">
          <BudgetTab categories={categories} spendByCategory={spendByCategory} onAdd={(c: any) => addCategory.mutate(c)} onDelete={(id: string) => deleteCategory.mutate(id)} />
        </TabsContent>

        {/* GOALS */}
        <TabsContent value="goals">
          <GoalsTab goals={goals} onAdd={(g: any) => addGoal.mutate(g)} onUpdate={(g: any) => updateGoal.mutate(g)} onDelete={(id: string) => deleteGoal.mutate(id)} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============ STAT CARD ============
function StatCard({ label, value, icon: Icon, color }: any) {
  const colors: any = { blue: "text-blue-400 bg-blue-400/10", emerald: "text-emerald-400 bg-emerald-400/10", rose: "text-rose-400 bg-rose-400/10", amber: "text-amber-400 bg-amber-400/10" };
  return (
    <Card className="bg-[#FFFFFF] border border-[#EAEAEA] rounded-[24px] p-5 shadow-2xl">
      <div className="flex justify-between items-start mb-3">
        <p className="text-[10px] font-black uppercase tracking-widest text-[#6B6B6B]">{label}</p>
        <div className={`p-2 rounded-xl ${colors[color]}`}><Icon size={16} /></div>
      </div>
      <p className="text-2xl font-black text-[#2A2A2A]">{value}</p>
    </Card>
  );
}

// ============ RECURRING TAB ============
function RecurringTab({ bills, categories, onAdd, onDelete, onPay }: any) {
  const [form, setForm] = useState({ description: "", amount: "", due_day: "5", type: "expense", category_name: "" });
  const [open, setOpen] = useState(false);
  return (
    <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Contas Fixas Recorrentes</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-[#C84D8A] text-[#7D2958] hover:bg-[#C84D8A]/90 font-bold"><Plus size={14} className="mr-1" /> Nova</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
            <DialogHeader><DialogTitle>Nova Conta Fixa</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div className="space-y-2"><Label>Descrição (ex: Aluguel, Netflix)</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Valor</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
                <div className="space-y-2"><Label>Dia do Vencimento</Label><Input type="number" min="1" max="31" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.due_day} onChange={(e) => setForm({ ...form, due_day: e.target.value })} /></div>
              </div>
              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                    <SelectItem value="expense">Despesa</SelectItem>
                    <SelectItem value="income">Receita</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Categoria</Label>
                <Select value={form.category_name} onValueChange={(v) => setForm({ ...form, category_name: v })}>
                  <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                    {(categories as any[]).filter((c: any) => c.type === form.type).map((c: any) => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button className="bg-[#C84D8A] text-[#7D2958] font-bold" onClick={() => {
                if (!form.description || !form.amount) return toast.error("Preencha descrição e valor");
                onAdd({ description: form.description, amount: parseFloat(form.amount), due_day: parseInt(form.due_day), type: form.type, category_name: form.category_name || null });
                setForm({ description: "", amount: "", due_day: "5", type: "expense", category_name: "" });
                setOpen(false);
              }}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      {bills.length === 0 ? <p className="text-[#6B6B6B] text-sm">Nenhuma conta fixa cadastrada.</p> : (
        <Table>
          <TableHeader>
            <TableRow className="border-[#EAEAEA] hover:bg-transparent">
              <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Descrição</TableHead>
              <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Categoria</TableHead>
              <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Dia</TableHead>
              <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Valor</TableHead>
              <TableHead className="text-[#6B6B6B] text-[10px] uppercase">Tipo</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bills.map((b: any) => (
              <TableRow key={b.id} className="border-[#EAEAEA]">
                <TableCell className="font-bold text-[#2A2A2A]">{b.description}</TableCell>
                <TableCell className="text-[#6B6B6B] text-xs">{b.category_name || "—"}</TableCell>
                <TableCell className="text-[#6B6B6B]">Todo dia {b.due_day}</TableCell>
                <TableCell className="font-black text-[#C84D8A]">{BRL(Number(b.amount))}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={`text-[10px] ${b.type === "income" ? "border-emerald-500/20 text-emerald-400" : "border-rose-500/20 text-rose-400"}`}>
                    {b.type === "income" ? "Receita" : "Despesa"}
                  </Badge>
                </TableCell>
                <TableCell className="flex gap-1">
                  <Button size="sm" variant="ghost" className="text-emerald-400 h-8" onClick={() => onPay(b)}><CheckCircle2 size={14} /></Button>
                  <Button size="sm" variant="ghost" className="text-rose-400 h-8" onClick={() => onDelete(b.id)}><Trash2 size={14} /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </Card>
  );
}

// ============ CARDS TAB ============
function CardsTab({ cards, expenses, categories, billsByCard, onAddCard, onDeleteCard, onAddExpense, onDeleteExpense }: any) {
  const [openCard, setOpenCard] = useState(false);
  const [openExpense, setOpenExpense] = useState(false);
  const [cardForm, setCardForm] = useState({ name: "", bank: "", brand: "", last_digits: "", credit_limit: "", closing_day: "1", due_day: "10" });
  const [expForm, setExpForm] = useState({ credit_card_id: "", description: "", total_amount: "", installments: "1", purchase_date: new Date().toISOString().split("T")[0], category_name: "" });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Meus Cartões</h3>
        <div className="flex gap-2">
          {cards.length > 0 && (
            <Dialog open={openExpense} onOpenChange={setOpenExpense}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="border-[#EAEAEA] text-[#2A2A2A]"><Plus size={14} className="mr-1" /> Nova Compra</Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
                <DialogHeader><DialogTitle>Nova Compra no Cartão</DialogTitle></DialogHeader>
                <div className="space-y-3 py-2">
                  <div className="space-y-2">
                    <Label>Cartão</Label>
                    <Select value={expForm.credit_card_id} onValueChange={(v) => setExpForm({ ...expForm, credit_card_id: v })}>
                      <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                      <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                        {cards.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2"><Label>Descrição</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={expForm.description} onChange={(e) => setExpForm({ ...expForm, description: e.target.value })} /></div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="space-y-2"><Label>Valor Total</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={expForm.total_amount} onChange={(e) => setExpForm({ ...expForm, total_amount: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Parcelas</Label><Input type="number" min="1" max="36" className="bg-[#F5EBEF] border-[#EAEAEA]" value={expForm.installments} onChange={(e) => setExpForm({ ...expForm, installments: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Data</Label><Input type="date" className="bg-[#F5EBEF] border-[#EAEAEA]" value={expForm.purchase_date} onChange={(e) => setExpForm({ ...expForm, purchase_date: e.target.value })} /></div>
                  </div>
                  <div className="space-y-2">
                    <Label>Categoria</Label>
                    <Select value={expForm.category_name} onValueChange={(v) => setExpForm({ ...expForm, category_name: v })}>
                      <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue placeholder="Selecione..." /></SelectTrigger>
                      <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                        {(categories as any[]).filter((c: any) => c.type === "expense").map((c: any) => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button className="bg-[#C84D8A] text-[#7D2958] font-bold" onClick={() => {
                    if (!expForm.credit_card_id || !expForm.description || !expForm.total_amount) return toast.error("Preencha cartão, descrição e valor");
                    onAddExpense({
                      credit_card_id: expForm.credit_card_id,
                      description: expForm.description,
                      total_amount: parseFloat(expForm.total_amount),
                      installments: parseInt(expForm.installments),
                      purchase_date: expForm.purchase_date,
                      category_name: expForm.category_name || null,
                    });
                    setExpForm({ credit_card_id: "", description: "", total_amount: "", installments: "1", purchase_date: new Date().toISOString().split("T")[0], category_name: "" });
                    setOpenExpense(false);
                  }}>Salvar</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
          <Dialog open={openCard} onOpenChange={setOpenCard}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-[#C84D8A] text-[#7D2958] font-bold"><Plus size={14} className="mr-1" /> Cartão</Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
              <DialogHeader><DialogTitle>Novo Cartão</DialogTitle></DialogHeader>
              <div className="space-y-3 py-2">
                <div className="space-y-2"><Label>Apelido (ex: Nubank Principal)</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.name} onChange={(e) => setCardForm({ ...cardForm, name: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2"><Label>Banco</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.bank} onChange={(e) => setCardForm({ ...cardForm, bank: e.target.value })} /></div>
                  <div className="space-y-2"><Label>Final (4 dígitos)</Label><Input maxLength={4} className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.last_digits} onChange={(e) => setCardForm({ ...cardForm, last_digits: e.target.value })} /></div>
                </div>
                <div className="space-y-2"><Label>Limite</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.credit_limit} onChange={(e) => setCardForm({ ...cardForm, credit_limit: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2"><Label>Dia Fechamento</Label><Input type="number" min="1" max="31" className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.closing_day} onChange={(e) => setCardForm({ ...cardForm, closing_day: e.target.value })} /></div>
                  <div className="space-y-2"><Label>Dia Vencimento</Label><Input type="number" min="1" max="31" className="bg-[#F5EBEF] border-[#EAEAEA]" value={cardForm.due_day} onChange={(e) => setCardForm({ ...cardForm, due_day: e.target.value })} /></div>
                </div>
              </div>
              <DialogFooter>
                <Button className="bg-[#C84D8A] text-[#7D2958] font-bold" onClick={() => {
                  if (!cardForm.name) return toast.error("Informe o apelido do cartão");
                  onAddCard({
                    name: cardForm.name,
                    bank: cardForm.bank || null,
                    last_digits: cardForm.last_digits || null,
                    credit_limit: parseFloat(cardForm.credit_limit || "0"),
                    closing_day: parseInt(cardForm.closing_day),
                    due_day: parseInt(cardForm.due_day),
                  });
                  setCardForm({ name: "", bank: "", brand: "", last_digits: "", credit_limit: "", closing_day: "1", due_day: "10" });
                  setOpenCard(false);
                }}>Salvar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {cards.length === 0 ? (
        <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-8 text-center"><p className="text-[#6B6B6B]">Cadastre seu primeiro cartão.</p></Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {cards.map((card: any) => {
            const bill = billsByCard[card.id] || 0;
            const usedPct = card.credit_limit > 0 ? (bill / Number(card.credit_limit)) * 100 : 0;
            return (
              <Card key={card.id} className="bg-gradient-to-br from-[#FFFFFF] to-[#7D2958] border border-[#EAEAEA] rounded-[24px] p-6 shadow-2xl">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-black text-[#2A2A2A] text-lg">{card.name}</h4>
                    <p className="text-xs text-[#6B6B6B]">{card.bank} {card.last_digits && `•••• ${card.last_digits}`}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => onDeleteCard(card.id)} className="text-[#6B6B6B] hover:text-rose-400 h-8 w-8 p-0"><Trash2 size={14} /></Button>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#6B6B6B]">Fatura atual</span>
                    <span className="font-black text-[#C84D8A]">{BRL(bill)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-[#6B6B6B]">Limite</span>
                    <span className="text-[#2A2A2A]">{BRL(Number(card.credit_limit))}</span>
                  </div>
                  <Progress value={usedPct} className="h-2 bg-[#F5EBEF]" />
                  <div className="flex justify-between text-[10px] text-[#6B6B6B]">
                    <span>Fecha dia {card.closing_day}</span>
                    <span>Vence dia {card.due_day}</span>
                  </div>
                </div>
                <div className="border-t border-[#EAEAEA] pt-3">
                  <p className="text-[10px] uppercase font-bold text-[#6B6B6B] mb-2">Compras recentes</p>
                  {(expenses as any[]).filter((e: any) => e.credit_card_id === card.id).slice(0, 4).map((e: any) => (
                    <div key={e.id} className="flex justify-between items-center py-1.5 text-xs">
                      <span className="text-[#2A2A2A]">{e.description} {e.installments > 1 && <span className="text-[#6B6B6B]">({e.installments}x)</span>}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[#2A2A2A]">{BRL(Number(e.total_amount))}</span>
                        <Button size="sm" variant="ghost" onClick={() => onDeleteExpense(e.id)} className="text-[#6B6B6B] hover:text-rose-400 h-6 w-6 p-0"><Trash2 size={12} /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ============ BUDGET TAB ============
function BudgetTab({ categories, spendByCategory, onAdd, onDelete }: any) {
  const [form, setForm] = useState({ name: "", type: "expense", monthly_budget: "" });
  const [open, setOpen] = useState(false);
  return (
    <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Categorias e Orçamento Mensal</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-[#C84D8A] text-[#7D2958] font-bold"><Plus size={14} className="mr-1" /> Categoria</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
            <DialogHeader><DialogTitle>Nova Categoria</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div className="space-y-2"><Label>Nome (ex: Mercado, Lazer)</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger className="bg-[#F5EBEF] border-[#EAEAEA]"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-white border-[#EAEAEA] text-[#2A2A2A]">
                    <SelectItem value="expense">Despesa</SelectItem>
                    <SelectItem value="income">Receita</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Orçamento mensal (R$) — opcional</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.monthly_budget} onChange={(e) => setForm({ ...form, monthly_budget: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button className="bg-[#C84D8A] text-[#7D2958] font-bold" onClick={() => {
                if (!form.name) return toast.error("Informe o nome");
                onAdd({ name: form.name, type: form.type, monthly_budget: parseFloat(form.monthly_budget || "0") });
                setForm({ name: "", type: "expense", monthly_budget: "" });
                setOpen(false);
              }}>Salvar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      {categories.length === 0 ? <p className="text-[#6B6B6B] text-sm">Crie categorias para organizar seus lançamentos.</p> : (
        <div className="space-y-3">
          {categories.map((c: any) => {
            const spent = spendByCategory[c.name] || 0;
            const budget = Number(c.monthly_budget);
            const pct = budget > 0 ? Math.min((spent / budget) * 100, 100) : 0;
            return (
              <div key={c.id} className="p-4 rounded-xl bg-[#F5EBEF] border border-[#EAEAEA]">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#2A2A2A]">{c.name}</span>
                      <Badge variant="outline" className={`text-[9px] ${c.type === "income" ? "border-emerald-500/20 text-emerald-400" : "border-rose-500/20 text-rose-400"}`}>
                        {c.type === "income" ? "Receita" : "Despesa"}
                      </Badge>
                    </div>
                    {budget > 0 && <p className="text-xs text-[#6B6B6B] mt-1">{BRL(spent)} de {BRL(budget)} ({pct.toFixed(0)}%)</p>}
                    {budget === 0 && <p className="text-xs text-[#6B6B6B] mt-1">Sem orçamento definido • Gasto: {BRL(spent)}</p>}
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => onDelete(c.id)} className="text-[#6B6B6B] hover:text-rose-400 h-8 w-8 p-0"><Trash2 size={14} /></Button>
                </div>
                {budget > 0 && <Progress value={pct} className="h-2 bg-[#F5EBEF]" />}
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}

// ============ GOALS TAB ============
function GoalsTab({ goals, onAdd, onUpdate, onDelete }: any) {
  const [form, setForm] = useState({ name: "", target_amount: "", current_amount: "0", deadline: "" });
  const [open, setOpen] = useState(false);
  return (
    <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Metas de Economia</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-[#C84D8A] text-[#7D2958] font-bold"><Plus size={14} className="mr-1" /> Meta</Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto bg-white border-[#EAEAEA] text-[#2A2A2A]">
            <DialogHeader><DialogTitle>Nova Meta</DialogTitle></DialogHeader>
            <div className="space-y-3 py-2">
              <div className="space-y-2"><Label>Nome (ex: Viagem, Reserva)</Label><Input className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Valor Alvo</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.target_amount} onChange={(e) => setForm({ ...form, target_amount: e.target.value })} /></div>
                <div className="space-y-2"><Label>Já Guardou</Label><Input type="number" step="0.01" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.current_amount} onChange={(e) => setForm({ ...form, current_amount: e.target.value })} /></div>
              </div>
              <div className="space-y-2"><Label>Prazo (opcional)</Label><Input type="date" className="bg-[#F5EBEF] border-[#EAEAEA]" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} /></div>
            </div>
            <DialogFooter>
              <Button className="bg-[#C84D8A] text-[#7D2958] font-bold" onClick={() => {
                if (!form.name || !form.target_amount) return toast.error("Preencha nome e valor alvo");
                onAdd({ name: form.name, target_amount: parseFloat(form.target_amount), current_amount: parseFloat(form.current_amount || "0"), deadline: form.deadline || null });
                setForm({ name: "", target_amount: "", current_amount: "0", deadline: "" });
                setOpen(false);
              }}>Criar Meta</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      {goals.length === 0 ? <p className="text-[#6B6B6B] text-sm">Crie sua primeira meta de economia.</p> : (
        <div className="grid md:grid-cols-2 gap-4">
          {goals.map((g: any) => {
            const pct = Math.min((Number(g.current_amount) / Number(g.target_amount)) * 100, 100);
            return (
              <div key={g.id} className="p-5 rounded-2xl bg-gradient-to-br from-white/5 to-transparent border border-[#EAEAEA]">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-2">
                    <Target size={18} className="text-[#C84D8A]" />
                    <h4 className="font-black text-[#2A2A2A]">{g.name}</h4>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => onDelete(g.id)} className="text-[#6B6B6B] hover:text-rose-400 h-8 w-8 p-0"><Trash2 size={14} /></Button>
                </div>
                <div className="space-y-2 mb-3">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#6B6B6B]">{BRL(Number(g.current_amount))}</span>
                    <span className="text-[#2A2A2A] font-bold">{BRL(Number(g.target_amount))}</span>
                  </div>
                  <Progress value={pct} className="h-3 bg-[#F5EBEF]" />
                  <p className="text-[10px] text-[#6B6B6B] text-right">{pct.toFixed(0)}% concluído {g.deadline && `• Prazo: ${new Date(g.deadline).toLocaleDateString("pt-BR")}`}</p>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="Adicionar R$"
                    className="bg-[#F5EBEF] border-[#EAEAEA] h-8 text-xs"
                    onKeyDown={(e: any) => {
                      if (e.key === "Enter" && e.currentTarget.value) {
                        const add = parseFloat(e.currentTarget.value);
                        onUpdate({ id: g.id, current_amount: Number(g.current_amount) + add });
                        e.currentTarget.value = "";
                      }
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}

// ============ PATRIMONY TAB (Phase 2) ============
function PatrimonyTab({ patrimonyData, forecast, avgMonthlyExpense, emergencyGoal, emergencyTarget, emergencyCurrent, emergencyPct, onCreateEmergency, onContribute }: any) {
  const [aporte, setAporte] = useState("");
  const currentBalance = patrimonyData.length ? patrimonyData[patrimonyData.length - 1].saldo : 0;
  const chartData = [...patrimonyData, ...forecast.rows.map((r: any) => ({ mes: r.mes, saldo: r.previsto, previsto: true }))];

  return (
    <div className="space-y-6">
      {/* Emergency Reserve */}
      <Card className="bg-gradient-to-br from-emerald-500/10 to-[#FFFFFF] border border-emerald-500/20 rounded-[24px] p-6 shadow-2xl">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-emerald-500/20"><Shield size={24} className="text-emerald-400" /></div>
            <div>
              <h3 className="font-black text-[#2A2A2A] text-lg">Reserva de Emergência</h3>
              <p className="text-xs text-[#6B6B6B]">Meta: 6× sua despesa média mensal ({BRL(avgMonthlyExpense)})</p>
            </div>
          </div>
          {!emergencyGoal && (
            <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold" onClick={onCreateEmergency}>
              <Plus size={14} className="mr-1" /> Criar Reserva
            </Button>
          )}
        </div>

        {emergencyGoal ? (
          <>
            <div className="grid md:grid-cols-3 gap-4 mb-4">
              <div>
                <p className="text-[10px] uppercase font-black text-[#6B6B6B] tracking-wider">Acumulado</p>
                <p className="text-2xl font-black text-emerald-400">{BRL(emergencyCurrent)}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase font-black text-[#6B6B6B] tracking-wider">Meta Total</p>
                <p className="text-2xl font-black text-[#2A2A2A]">{BRL(emergencyTarget)}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase font-black text-[#6B6B6B] tracking-wider">Progresso</p>
                <p className="text-2xl font-black text-[#C84D8A]">{emergencyPct.toFixed(0)}%</p>
              </div>
            </div>
            <Progress value={emergencyPct} className="h-3 bg-[#F5EBEF] mb-4" />
            <div className="flex gap-2">
              <Input
                type="number"
                step="0.01"
                placeholder="Valor do aporte"
                className="bg-[#F5EBEF] border-[#EAEAEA] flex-1"
                value={aporte}
                onChange={(e) => setAporte(e.target.value)}
              />
              <Button
                className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold"
                onClick={() => {
                  const v = parseFloat(aporte);
                  if (!v || v <= 0) return toast.error("Informe um valor válido");
                  onContribute(v);
                  setAporte("");
                  toast.success(`Aporte de ${BRL(v)} registrado!`);
                }}
              >
                Aportar
              </Button>
            </div>
          </>
        ) : (
          <p className="text-[#6B6B6B] text-sm">Crie sua reserva de emergência para começar a se proteger contra imprevistos.</p>
        )}
      </Card>

      {/* Forecast */}
      <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp size={18} className="text-[#C84D8A]" />
          <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Previsão de Saldo (próximos 3 meses)</h3>
        </div>
        <div className="grid md:grid-cols-4 gap-4 mb-4">
          <div className="p-3 rounded-xl bg-[#F5EBEF]">
            <p className="text-[10px] uppercase font-black text-[#6B6B6B]">Saldo Atual</p>
            <p className={`text-xl font-black ${currentBalance >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{BRL(currentBalance)}</p>
          </div>
          {forecast.rows.map((r: any, i: number) => (
            <div key={i} className="p-3 rounded-xl bg-[#F5EBEF]">
              <p className="text-[10px] uppercase font-black text-[#6B6B6B]">{r.mes}</p>
              <p className={`text-xl font-black ${r.previsto >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{BRL(r.previsto)}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-[#6B6B6B]">
          Fluxo mensal recorrente: <span className={forecast.monthlyNet >= 0 ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>{BRL(forecast.monthlyNet)}</span>
          {" "}({BRL(forecast.monthlyRecurringIncome)} entradas − {BRL(forecast.monthlyRecurringExpense)} saídas fixas)
        </p>
      </Card>

      {/* Patrimony chart */}
      <Card className="bg-[#FFFFFF] border-[#EAEAEA] rounded-[24px] p-6">
        <div className="flex items-center gap-2 mb-4">
          <LineChartIcon size={18} className="text-[#C84D8A]" />
          <h3 className="font-black uppercase text-xs tracking-wider text-[#6B6B6B]">Evolução Patrimonial (12 meses + previsão)</h3>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="patColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#C84D8A" stopOpacity={0.6} />
                  <stop offset="95%" stopColor="#C84D8A" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis dataKey="mes" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: "#FFFFFF", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12 }}
                labelStyle={{ color: "#2A2A2A" }}
                formatter={(v: any) => BRL(Number(v))}
              />
              <Area type="monotone" dataKey="saldo" stroke="#C84D8A" strokeWidth={2.5} fill="url(#patColor)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <p className="text-xs text-[#6B6B6B] mt-2">A linha mostra o saldo acumulado mês a mês. Os últimos 3 pontos são projeções baseadas em suas contas fixas recorrentes.</p>
      </Card>
    </div>
  );
}
