import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuthReady } from "@/hooks/use-auth-ready";
import { getDashboardSummary, getRecentPayments } from "../serverFunctions";
import { chatWithAssistant, getPendingAlerts } from "../lib/ai-assistant.functions";
import { 
  DollarSign, 
  AlertCircle, 
  Calendar, 
  PlusCircle, 
  CheckCircle2, 
  Loader2, 
  TrendingUp, 
  Users as UsersIcon,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  History as HistoryIcon,
  ShoppingBag,
  Clock,
  Sparkles,
  Send,
  MessageSquare,
  Bell
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";


export const Route = createFileRoute("/_authenticated/")({
  component: Dashboard,
});

function Dashboard() {
  const { isReady: authReady, user } = useAuthReady();
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([
    { role: 'assistant', content: 'Olá! Sou a VERA, sua assistente financeira. Já analisei sua operação — me pergunte sobre clientes em atraso, vencimentos do dia ou sugestões de cobrança. 💼' }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const chatFn = useServerFn(chatWithAssistant);
  const alertsFn = useServerFn(getPendingAlerts);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollArea = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollArea) scrollArea.scrollTop = scrollArea.scrollHeight;
    }
  }, [messages]);

  const chatMutation = useMutation({
    mutationFn: async (history: {role: 'user' | 'assistant', content: string}[]) => {
      return await chatFn({ data: { messages: history } });
    },
    onSuccess: (res) => {
      setMessages(prev => [...prev, { role: 'assistant', content: res.reply }]);
    },
    onError: (err: any) => {
      toast.error(err?.message || "Erro na assistente.");
    },
  });

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;
    const userMsg = input.trim();
    setInput("");
    const newHistory = [...messages, { role: 'user' as const, content: userMsg }];
    setMessages(newHistory);
    chatMutation.mutate(newHistory);
  };

  const { data: alertsData } = useQuery({
    queryKey: ["pendingAlerts", user?.id],
    queryFn: () => alertsFn(),
    enabled: authReady && !!user,
    staleTime: 1000 * 60 * 2,
    refetchInterval: 1000 * 60 * 5,
  });


  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ["dashboardSummary", user?.id],
    queryFn: () => getDashboardSummary(),
    enabled: authReady && !!user,
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: 1,
  });

  const { data: recentPayments, isLoading: paymentsLoading } = useQuery({
    queryKey: ["recentPayments", user?.id],
    queryFn: () => getRecentPayments(),
    enabled: authReady && !!user,
    staleTime: 1000 * 60, // 1 minute
    retry: 1,
  });

  if (summaryLoading || paymentsLoading || !authReady) {
    return (
      <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
          <div className="space-y-2">
            <div className="h-4 w-32 bg-[#F5EBEF] animate-pulse rounded-full" />
            <div className="h-10 w-64 bg-[#F5EBEF] animate-pulse rounded-xl" />
          </div>
          <div className="h-14 w-40 bg-[#F5EBEF] animate-pulse rounded-2xl" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4].map(i => <div key={i} className="h-40 bg-[#F5EBEF] animate-pulse rounded-[32px]" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-7 h-96 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
          <div className="lg:col-span-5 h-96 bg-[#F5EBEF] animate-pulse rounded-[32px]" />
        </div>
      </div>
    );
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 md:space-y-12">
      <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <motion.div 
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="min-w-0"
        >
          <div className="flex items-center gap-2 mb-2">
            <span className="h-2 w-2 rounded-full bg-[#C84D8A] animate-pulse" />
            <span className="text-[10px] font-bold text-[#C84D8A] uppercase tracking-[0.2em]">SISTEMA ONLINE</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-black tracking-tight text-[#2A2A2A]">Olá, <span className="gold-text">Administrador</span></h1>
          <p className="text-sm md:text-base text-[#6B6B6B] font-medium mt-1">Resumo financeiro detalhado por loja.</p>
        </motion.div>
        
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
        >
          <Button asChild size="lg" className="h-12 md:h-14 w-full md:w-auto px-6 md:px-8 btn-primary">
            <Link to={"/emprestimos" as any} className="flex items-center justify-center gap-2">
              <PlusCircle size={20} />
              Nova Operação
            </Link>
          </Button>
        </motion.div>
      </header>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="grid gap-3 md:gap-6 grid-cols-2 lg:grid-cols-5"
      >
        <StatCard 
          label="Nota Promissória" 
          value={summary?.totalPending || 0} 
          icon={TrendingUp} 
          type="currency"
          color="indigo"
          variants={item}
          description="Volume total sob gestão"
        />
        <StatCard 
          label="A Pagar (Terceiros)" 
          value={summary?.totalToPay || 0} 
          icon={ArrowDownRight} 
          type="currency"
          color="rose"
          variants={item}
          description="Compromissos financeiros"
        />
        <StatCard 
          label="Taxa de Atraso" 
          value={summary?.overdueCount || 0} 
          icon={AlertCircle} 
          color="amber"
          variants={item}
          isWarning={summary?.overdueCount > 0}
          description="Contratos com pendência"
        />
        <StatCard 
          label="Recebíveis do Dia" 
          value={summary?.todayPayments || 0} 
          icon={Calendar} 
          color="indigo"
          variants={item}
          description="Compromissos para hoje"
        />
        <StatCard 
          label="Base Fidelizada" 
          value={summary?.customersCount || 0} 
          icon={UsersIcon} 
          color="emerald"
          variants={item}
          description="Total de clientes ativos"
        />
      </motion.div>

      {alertsData && alertsData.alerts.length > 0 && (
        <Card className="border border-[#F0D9E2] bg-gradient-to-br from-white via-[#FFF7FA] to-[#F5EBEF] rounded-[32px] shadow-xl overflow-hidden">
          <CardHeader className="p-6 pb-4 border-b border-[#F0D9E2]/60">
            <CardTitle className="text-lg font-bold flex items-center gap-3 text-[#2A2A2A]">
              <div className="p-2.5 rounded-2xl bg-gradient-to-br from-[#C84D8A] to-[#7D2958] text-white shadow-lg shadow-[#C84D8A]/30 relative">
                <Bell size={20} />
                <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-rose-500 ring-2 ring-white animate-pulse" />
              </div>
              <span>Alertas Inteligentes da <span className="text-[#C84D8A]">VERA</span></span>
              <span className="ml-auto text-[10px] font-black text-[#C84D8A] uppercase tracking-widest bg-[#C84D8A]/10 px-3 py-1.5 rounded-full">
                {alertsData.alerts.length} {alertsData.alerts.length === 1 ? "aviso" : "avisos"}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            {alertsData.alerts.map((a, i) => {
              const palette = a.severity === "high"
                ? { bg: "bg-rose-50", border: "border-rose-200", icon: "text-rose-600", iconBg: "bg-rose-100", title: "text-rose-900", msg: "text-rose-700/80", tag: "bg-rose-600 text-white", tagLabel: "CRÍTICO" }
                : a.severity === "medium"
                ? { bg: "bg-amber-50", border: "border-amber-200", icon: "text-amber-600", iconBg: "bg-amber-100", title: "text-amber-900", msg: "text-amber-700/80", tag: "bg-amber-500 text-white", tagLabel: "ATENÇÃO" }
                : { bg: "bg-sky-50", border: "border-sky-200", icon: "text-sky-600", iconBg: "bg-sky-100", title: "text-sky-900", msg: "text-sky-700/80", tag: "bg-sky-500 text-white", tagLabel: "INFO" };
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className={`p-4 rounded-2xl border-2 ${palette.bg} ${palette.border} flex items-start gap-3 shadow-sm`}
                >
                  <div className={`p-2 rounded-xl ${palette.iconBg} shrink-0`}>
                    <AlertCircle size={18} className={palette.icon} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className={`font-black text-sm ${palette.title}`}>{a.title}</p>
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-full tracking-widest ${palette.tag}`}>{palette.tagLabel}</span>
                    </div>
                    <p className={`text-xs mt-1 leading-relaxed ${palette.msg}`}>{a.message}</p>
                  </div>
                </motion.div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:gap-8 lg:grid-cols-12">
        <div className="lg:col-span-7 space-y-8">

          <Card className="border-none bg-[#FFFFFF] rounded-[32px] overflow-hidden shadow-2xl group border border-[#EAEAEA]">
            <CardHeader className="p-8 pb-0">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl font-bold flex items-center gap-3 text-[#2A2A2A]">
                  <div className="p-2.5 rounded-2xl bg-[#F5EBEF] text-[#C84D8A]">
                    <TrendingUp size={22} />
                  </div>
                  Performance Operacional
                </CardTitle>
                <Badge variant="outline" className="rounded-lg font-bold border-slate-100 text-[#6B6B6B]">Últimos 30 dias</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-8 pt-6">
              <div className="h-[320px] w-full flex flex-col items-center justify-center bg-[#F5EBEF] rounded-[24px] border-2 border-dashed border-[#EAEAEA] group-hover:border-[#C84D8A]/20 transition-colors">
                <div className="flex items-end gap-2 h-32 mb-4">
                  <motion.div initial={{ height: 0 }} animate={{ height: "40%" }} className="w-8 bg-blue-500/20 rounded-t-lg" />
                  <motion.div initial={{ height: 0 }} animate={{ height: "70%" }} className="w-8 bg-[#C84D8A] rounded-t-lg" />
                  <motion.div initial={{ height: 0 }} animate={{ height: "50%" }} className="w-8 bg-blue-500/20 rounded-t-lg" />
                  <motion.div initial={{ height: 0 }} animate={{ height: "90%" }} className="w-8 bg-[#C84D8A] rounded-t-lg" />
                  <motion.div initial={{ height: 0 }} animate={{ height: "65%" }} className="w-8 bg-blue-500/20 rounded-t-lg" />
                </div>
                <p className="text-[#6B6B6B] font-bold text-sm tracking-wide uppercase">Performance de Fluxo de Caixa</p>
                <p className="text-[10px] text-[#6B6B6B] font-medium mt-1 italic">Dourado: Entradas | Azul: Projeção</p>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-6">
            <Card className="border-none bg-[#F5EBEF] text-[#2A2A2A] rounded-[32px] p-8 flex flex-col justify-between overflow-hidden relative border border-[#EAEAEA]">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#C84D8A]/5 blur-3xl rounded-full -mr-16 -mt-16" />
              <div className="z-10">
                <p className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-widest mb-1">Loja Principal</p>
                <h3 className="text-xl font-black uppercase tracking-tight">VeraPay <span className="text-[#C84D8A]">Admin</span></h3>
              </div>
              <div className="flex items-center gap-2 text-[#C84D8A] font-bold z-10">
                <ShoppingBag size={18} />
                <span className="text-sm">Gestão Inteligente</span>
              </div>
            </Card>
            <Card className="border-none gold-gradient text-[#7D2958] rounded-[32px] p-8 flex flex-col justify-between overflow-hidden relative shadow-xl shadow-primary/10">
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/20 blur-3xl rounded-full -ml-16 -mb-16" />
              <div className="z-10">
                <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest mb-1">Status do Banco</p>
                <h3 className="text-xl font-black italic">PRODUTIVIDADE</h3>
              </div>
              <div className="flex items-center gap-2 text-[#7D2958] font-bold z-10">
                <ShieldCheck size={18} />
                <span className="text-sm">Segurança Máxima</span>
              </div>
            </Card>
          </div>
        </div>

        <Card className="lg:col-span-5 border-none bg-[#FFFFFF] rounded-[24px] md:rounded-[32px] shadow-2xl flex flex-col border border-[#EAEAEA] h-[480px] md:h-[600px] overflow-hidden">
          <CardHeader className="p-6 border-b border-[#EAEAEA] bg-[#F5EBEF]">
            <CardTitle className="text-lg font-bold flex items-center gap-3 text-[#2A2A2A]">
              <div className="p-2 rounded-xl bg-[#C84D8A]/10 text-[#C84D8A]">
                <Sparkles size={20} />
              </div>
              Assistente VeraPay
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
            <ScrollArea ref={scrollRef} className="flex-1 p-6">
              <div className="space-y-4">
                <AnimatePresence initial={false}>
                  {messages.map((msg, i) => (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={i}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[85%] p-4 rounded-2xl text-sm font-medium ${
                        msg.role === 'user' 
                          ? 'bg-[#C84D8A] text-[#7D2958] rounded-tr-none' 
                          : 'bg-[#F5EBEF] text-[#2A2A2A] rounded-tl-none border border-[#EAEAEA]'
                      }`}>
                        {msg.content}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {chatMutation.isPending && (
                  <div className="flex justify-start">
                    <div className="bg-[#F5EBEF] text-[#6B6B6B] p-4 rounded-2xl rounded-tl-none border border-[#EAEAEA]">
                      <Loader2 size={16} className="animate-spin" />
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
            <div className="p-6 bg-[#F5EBEF]/60 border-t border-[#EAEAEA]">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="relative flex items-center"
              >
                <Input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Tire suas dúvidas..."
                  className="h-12 bg-[#F5EBEF] border-[#EAEAEA] pr-12 rounded-xl text-[#2A2A2A] placeholder:text-[#6B6B6B] focus:ring-[#C84D8A]/20"
                />
                <Button 
                  type="submit"
                  size="icon" 
                  className="absolute right-1 bg-transparent hover:bg-[#F5EBEF]/80 text-[#C84D8A]"
                >
                  <Send size={18} />
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, type = "number", color, variants, isWarning, description }: any) {
  const colors: any = {
    indigo: "bg-[#C84D8A]",
    rose: "bg-rose-500",
    amber: "bg-amber-500",
    emerald: "bg-emerald-500"
  };

  const formattedValue = type === "currency" 
    ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)
    : value;

  return (
    <motion.div variants={variants}>
      <Card className={`border-none bg-[#FFFFFF] rounded-2xl md:rounded-[32px] p-4 md:p-8 shadow-lg md:shadow-2xl group hover:scale-[1.02] transition-transform duration-300 relative overflow-hidden border border-[#EAEAEA] ${isWarning ? "ring-2 ring-rose-500/10" : ""}`}>
        <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full opacity-[0.05] transition-transform group-hover:scale-150 ${colors[color]}`} />
        
        <div className="flex items-center justify-between mb-4">
          <p className="text-[10px] font-bold text-[#6B6B6B] uppercase tracking-[0.2em]">{label}</p>
          <div className={`p-2.5 rounded-2xl text-[#7D2958] shadow-lg ${colors[color]} ${color === 'indigo' ? '' : 'text-white'}`}>
            <Icon size={20} />
          </div>
        </div>
        
        <div className="flex flex-col">
          <h3 className={`text-lg md:text-2xl font-black tracking-tight break-words ${isWarning ? "text-rose-400" : "text-[#2A2A2A]"}`}>
            {formattedValue}
          </h3>
          <p className="text-[9px] font-medium text-[#6B6B6B] mt-1">{description}</p>
          <div className="mt-3 flex items-center gap-1.5">
            {isWarning ? (
              <div className="inline-flex max-w-full items-center gap-1 px-2 py-0.5 rounded-lg bg-rose-500/10 text-rose-400 text-[9px] font-bold uppercase tracking-wider whitespace-nowrap overflow-hidden">
                <AlertCircle size={10} className="shrink-0" /> <span className="truncate">ALTO RISCO</span>
              </div>
            ) : (
              <div className="inline-flex max-w-full items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-400 text-[9px] font-bold uppercase tracking-wider whitespace-nowrap overflow-hidden">
                <CheckCircle2 size={10} className="shrink-0" /> <span className="truncate">SAUDÁVEL</span>
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

function Badge({ children, variant, className }: any) {
  return (
    <div className={`px-2 py-1 rounded-md text-[10px] font-bold ${className}`}>
      {children}
    </div>
  );
}

function ShieldCheck({ size, className }: any) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
