import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMyClientPortal, updateMyClientProfile } from "../serverFunctions";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { ArrowLeft, Camera, Loader2, Save, Trash2, User as UserIcon, QrCode } from "lucide-react";
import { formatCpf } from "@/lib/cpf";
import { QRCodeSVG } from "qrcode.react";

export const Route = createFileRoute("/cliente/perfil")({
  ssr: false,
  component: ClientePerfilPage,
});

function ClientePerfilPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [ready, setReady] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate({ to: "/cliente/login" as any });
        return;
      }
      setReady(true);
    })();
  }, [navigate]);

  const { data, isLoading } = useQuery({
    queryKey: ["my-client-portal"],
    queryFn: () => getMyClientPortal(),
    enabled: ready,
    retry: false,
  });

  useEffect(() => {
    if (data?.customer) {
      setName(data.customer.name ?? "");
      setPhone((data.customer as any).phone ?? "");
    }
  }, [data?.customer]);

  const saveMutation = useMutation({
    mutationFn: (patch: { name?: string; phone?: string; avatar_url?: string | null }) =>
      updateMyClientProfile({ data: patch }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-client-portal"] });
      toast.success("Perfil atualizado!");
    },
    onError: () => toast.error("Não foi possível salvar."),
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      toast.error("Informe um nome válido.");
      return;
    }
    saveMutation.mutate({ name, phone });
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      toast.error("A foto deve ter no máximo 3 MB.");
      return;
    }
    setUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("no user");

      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;

      // delete previous (best-effort) so we don't accumulate junk
      const prev = (data?.customer as any)?.avatar_url;
      if (prev) await supabase.storage.from("avatars").remove([prev]).catch(() => {});

      const { error: upErr } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: file.type });
      if (upErr) throw upErr;

      await updateMyClientProfile({ data: { avatar_url: path } });
      await qc.invalidateQueries({ queryKey: ["my-client-portal"] });
      toast.success("Foto atualizada!");
    } catch (err: any) {
      toast.error("Falha ao enviar a foto.", { description: err?.message });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const handleRemoveAvatar = async () => {
    const prev = (data?.customer as any)?.avatar_url;
    if (!prev) return;
    setUploading(true);
    try {
      await supabase.storage.from("avatars").remove([prev]).catch(() => {});
      await updateMyClientProfile({ data: { avatar_url: null } });
      await qc.invalidateQueries({ queryKey: ["my-client-portal"] });
      toast.success("Foto removida.");
    } finally {
      setUploading(false);
    }
  };

  if (!ready || isLoading || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7]">
        <Loader2 className="animate-spin text-[#C84D8A]" size={32} />
      </div>
    );
  }

  const customer = data.customer as any;
  const avatar = customer.avatar_signed_url;

  return (
    <div className="min-h-screen bg-[#FAF6F7] pb-12">
      <header className="bg-[#7D2958] text-white px-4 md:px-8 py-5 shadow-lg">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Link to={"/cliente" as any} className="flex items-center gap-2 text-white/90 hover:text-white text-sm font-bold">
            <ArrowLeft size={18} /> Voltar
          </Link>
          <span className="text-sm font-bold uppercase tracking-wider">Meu Perfil</span>
          <div className="w-16" />
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 md:px-8 mt-6">
        <motion.div initial={{ y: 12, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
          <Card className="bg-white border-[#EAEAEA] shadow-md">
            <CardContent className="p-6 md:p-8 space-y-8">
              {/* Avatar */}
              <div className="flex flex-col items-center text-center">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full overflow-hidden bg-gradient-to-br from-[#C84D8A] to-[#7D2958] flex items-center justify-center text-white text-5xl font-extrabold shadow-xl ring-4 ring-white">
                    {avatar ? (
                      <img src={avatar} alt={customer.name} className="w-full h-full object-cover" />
                    ) : (
                      (customer.name?.[0]?.toUpperCase() ?? "?")
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    className="absolute bottom-1 right-1 w-10 h-10 rounded-full bg-[#C84D8A] hover:bg-[#7D2958] text-white flex items-center justify-center shadow-lg transition disabled:opacity-50"
                    aria-label="Trocar foto"
                  >
                    {uploading ? <Loader2 className="animate-spin" size={16} /> : <Camera size={16} />}
                  </button>
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleAvatarChange}
                  />
                </div>
                <div className="mt-4 font-bold text-[#2A2A2A] text-lg">{customer.name}</div>
                <div className="text-xs text-[#6B6B6B]">CPF {customer.cpf ? formatCpf(customer.cpf) : "-"}</div>
                {avatar && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleRemoveAvatar}
                    disabled={uploading}
                    className="mt-3 text-[#6B6B6B] hover:text-red-600 gap-1.5"
                  >
                    <Trash2 size={14} /> Remover foto
                  </Button>
                )}
              </div>

              <div className="h-px bg-[#EAEAEA]" />

              {/* QR Code */}
              <div className="rounded-2xl bg-gradient-to-br from-[#7D2958] to-[#C84D8A] p-6 text-white text-center space-y-3">
                <div className="flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest opacity-90">
                  <QrCode size={14} /> Meu QR Code
                </div>
                <div className="bg-white rounded-2xl p-4 inline-block">
                  <QRCodeSVG value={`vp:cust:${customer.id}`} size={180} level="M" />
                </div>
                <p className="text-xs opacity-90 max-w-xs mx-auto">
                  Mostre este código na loja na hora de comprar — a vendedora escaneia e já registra sua compra em 3x.
                </p>
              </div>

              <div className="h-px bg-[#EAEAEA]" />
              <form onSubmit={handleSave} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-xs font-bold uppercase text-[#6B6B6B]">Nome</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="h-12 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-xs font-bold uppercase text-[#6B6B6B]">Telefone</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(00) 00000-0000"
                    className="h-12 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]"
                  />
                </div>

                <div className="rounded-xl bg-[#FAF6F7] border border-[#EAEAEA] p-4 text-xs text-[#6B6B6B]">
                  <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider mb-1">
                    <UserIcon size={12} /> CPF
                  </div>
                  {customer.cpf ? formatCpf(customer.cpf) : "-"}
                  <div className="mt-1 text-[10px]">Para corrigir o CPF, fale com a loja.</div>
                </div>

                <Button
                  type="submit"
                  disabled={saveMutation.isPending}
                  className="w-full h-12 btn-primary text-base font-bold flex items-center justify-center gap-2"
                >
                  {saveMutation.isPending ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                  Salvar alterações
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
