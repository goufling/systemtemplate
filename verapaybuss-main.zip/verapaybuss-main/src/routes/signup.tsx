import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Lock, ArrowRight, UserCircle } from "lucide-react";

export const Route = createFileRoute("/signup")({
  beforeLoad: async () => {
    // Cadastro público no sistema administrativo está desativado.
    // Quem precisa de acesso administrativo é cadastrado manualmente.
    // Clientes têm uma área própria.
    throw redirect({ to: "/login" as any });
  },
  component: SignupDisabledPage,
});

function SignupDisabledPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7] px-4">
      <Card className="w-full max-w-md border border-[#EAEAEA] shadow-xl">
        <CardContent className="p-8 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-[#7D2958] flex items-center justify-center mx-auto">
            <Lock className="text-white" size={28} />
          </div>
          <h1 className="text-2xl font-bold text-[#2A2A2A]">Cadastro restrito</h1>
          <p className="text-sm text-[#6B6B6B]">
            O sistema administrativo é privado. Novas contas só são criadas pela equipe VeraPay.
          </p>
          <div className="pt-4 space-y-2">
            <Link to={"/cliente/login" as any} className="flex items-center justify-center gap-2 h-12 rounded-xl bg-[#7D2958] text-white font-bold hover:bg-[#C84D8A] transition">
              <UserCircle size={18} /> Sou cliente — acessar minha conta
              <ArrowRight size={16} />
            </Link>
            <Link to={"/login" as any} className="block text-sm text-[#C84D8A] font-bold hover:underline">
              Sou da equipe — entrar
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
