import { createFileRoute, useNavigate, Link, redirect, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Mail, Lock, Loader2, ArrowRight, UserCircle, Store, ShieldCheck, Clock } from "lucide-react";

export const Route = createFileRoute("/login")({
  beforeLoad: async () => {
    if (typeof window === "undefined") return;
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", session.user.id);
    if ((roles || []).some((row) => row.role === "admin")) throw redirect({ to: "/" as any });
    if ((roles || []).some((row) => row.role === "client")) throw redirect({ to: "/cliente" as any });

    // No role yet → pending Google sign-in approval
    throw redirect({ to: "/login" as any, search: { pending: "1" } as any });
  },
  validateSearch: (s: Record<string, unknown>) => ({ pending: s.pending === "1" ? "1" : undefined }),
  component: LoginPage,
});

function LoginPage() {
  const search = Route.useSearch() as { pending?: string };
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(search.pending === "1");
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);
  const navigate = useNavigate();
  const router = useRouter();

  useEffect(() => {
    if (search.pending === "1") {
      supabase.auth.getUser().then(({ data }) => {
        setPendingEmail(data.user?.email ?? null);
      });
    }
  }, [search.pending]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", data.user!.id);
      const isAdmin = (roles || []).some((row) => row.role === "admin");
      if (!isAdmin) {
        await supabase.auth.signOut();
        toast.error("Acesso restrito à administração.");
        navigate({ to: "/cliente/login" as any });
        return;
      }
      toast.success("Bem-vindo(a)!");
      await router.invalidate();
      navigate({ to: "/" as any });
    } catch (err: any) {
      toast.error("Não foi possível entrar", { description: err.message || "Verifique suas credenciais" });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) toast.error("Erro no login com Google", { description: result.error.message });
  };

  const handleSignOutPending = async () => {
    await supabase.auth.signOut();
    setPending(false);
    setPendingEmail(null);
    navigate({ to: "/login" as any });
  };

  if (pending) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#FAF6F7] via-white to-[#F5EBF0] px-4">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-[#EAEAEA] p-8 text-center">
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-5">
            <Clock size={32} />
          </div>
          <h1 className="text-2xl font-bold text-[#2A2A2A]">Aguardando autorização</h1>
          <p className="text-sm text-[#6B6B6B] mt-3 leading-relaxed">
            Sua tentativa de acesso foi registrada{pendingEmail && <> com o email <strong className="text-[#2A2A2A]">{pendingEmail}</strong></>}.
            Um administrador precisa aprovar antes de você poder entrar.
          </p>
          <div className="mt-6 space-y-2">
            <Button onClick={handleSignOutPending} className="w-full h-12 btn-primary font-bold">
              Entendi, voltar ao login
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#FAF6F7] via-white to-[#F5EBF0] px-4 py-10">
      <div className="w-full max-w-[400px]">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#7D2958] shadow-lg shadow-[#7D2958]/25 mb-4">
            <ShieldCheck className="text-white" size={26} />
          </div>
          <h1 className="text-3xl font-black tracking-tight text-[#2A2A2A]">
            Vera<span className="text-[#C84D8A]">Pay</span>
          </h1>
          <p className="text-sm text-[#6B6B6B] mt-1">Acesso da equipe administrativa</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl border border-[#EAEAEA] shadow-xl p-7">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs font-semibold text-[#2A2A2A]">Email</Label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" />
                <Input
                  id="email" type="email" placeholder="voce@exemplo.com"
                  value={email} onChange={(e) => setEmail(e.target.value)} required
                  className="h-11 pl-10 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A] focus:bg-white focus:border-[#C84D8A]"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-xs font-semibold text-[#2A2A2A]">Senha</Label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" />
                <Input
                  id="password" type="password" placeholder="••••••••"
                  value={password} onChange={(e) => setPassword(e.target.value)} required
                  className="h-11 pl-10 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A] focus:bg-white focus:border-[#C84D8A]"
                />
              </div>
            </div>

            <Button type="submit" disabled={loading} className="w-full h-11 btn-primary font-bold">
              {loading ? <Loader2 className="animate-spin" size={18} /> : "Entrar"}
            </Button>
          </form>

          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-[#EAEAEA]" /></div>
            <div className="relative flex justify-center text-[10px] uppercase tracking-widest">
              <span className="bg-white px-3 text-[#6B6B6B] font-semibold">ou</span>
            </div>
          </div>

          <Button
            variant="outline" onClick={handleGoogle}
            className="w-full h-11 rounded-xl font-semibold border-[#EAEAEA] bg-white text-[#2A2A2A] hover:bg-[#FAF6F7]"
          >
            <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continuar com Google
          </Button>

          <p className="text-[11px] text-center text-[#6B6B6B] mt-4 leading-relaxed">
            Novos acessos via Google precisam de aprovação do administrador.
          </p>
        </div>

        {/* Portals */}
        <div className="mt-5 grid grid-cols-2 gap-3">
          <Link
            to={"/cliente/login" as any}
            className="flex items-center justify-center gap-1.5 h-11 rounded-xl bg-white border border-[#EAEAEA] text-[#7D2958] font-semibold text-sm hover:bg-[#FAF6F7] transition"
          >
            <UserCircle size={16} /> Sou Cliente
          </Link>
          <Link
            to={"/loja/login" as any}
            className="flex items-center justify-center gap-1.5 h-11 rounded-xl bg-white border border-[#EAEAEA] text-[#7D2958] font-semibold text-sm hover:bg-[#FAF6F7] transition"
          >
            <Store size={16} /> Sou Loja
          </Link>
        </div>

        <p className="text-xs text-center text-[#6B6B6B] mt-5">
          © {new Date().getFullYear()} VeraPay
          <Link to="/signup" className="ml-2 text-[#C84D8A] hover:underline inline-flex items-center gap-0.5">
            Solicitar acesso <ArrowRight size={11} />
          </Link>
        </p>
      </div>
    </div>
  );
}
