import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Lock, User as UserIcon, LogIn } from "lucide-react";
import { motion } from "framer-motion";
import { cleanCpf, formatCpf, isValidCpf, cpfToSyntheticEmail } from "@/lib/cpf";

export const Route = createFileRoute("/cliente/login")({
  beforeLoad: async () => {
    if (typeof window !== "undefined") {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        // Already signed in — let /cliente decide where to send them.
        throw redirect({ to: "/cliente" as any });
      }
    }
  },
  component: ClienteLoginPage,
});

function ClienteLoginPage() {
  const [cpf, setCpf] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const c = cleanCpf(cpf);
    if (!isValidCpf(c)) {
      toast.error("CPF inválido. Confira os números.");
      return;
    }
    if (password.length < 6) {
      toast.error("Senha precisa ter no mínimo 6 caracteres.");
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: cpfToSyntheticEmail(c),
        password,
      });
      if (error) throw error;
      toast.success("Bem-vindo(a)!");
      navigate({ to: "/cliente" as any });
    } catch (err: any) {
      toast.error("CPF ou senha incorretos.", {
        description: "Confirme com a loja se já foi liberado seu acesso.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#FAF6F7] px-4 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#C84D8A]/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[#7D2958]/10 rounded-full blur-[120px]" />

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-[420px] z-10"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-[#7D2958] flex items-center justify-center mx-auto mb-4 shadow-lg shadow-[#7D2958]/30">
            <UserIcon className="text-white" size={28} />
          </div>
          <h1 className="text-3xl font-bold text-[#2A2A2A]">Área do Cliente</h1>
          <p className="text-sm text-[#6B6B6B] mt-2">
            Acompanhe suas compras e parcelas
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-[#EAEAEA] shadow-xl p-8 space-y-5">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="cpf" className="text-xs font-bold uppercase text-[#6B6B6B]">CPF</Label>
              <div className="relative">
                <UserIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" />
                <Input
                  id="cpf"
                  placeholder="000.000.000-00"
                  value={cpf}
                  onChange={(e) => setCpf(formatCpf(e.target.value))}
                  maxLength={14}
                  required
                  className="h-12 pl-10 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-xs font-bold uppercase text-[#6B6B6B]">Senha</Label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#6B6B6B]" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Sua senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-12 pl-10 bg-[#FAF6F7] border-[#EAEAEA] text-[#2A2A2A]"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 btn-primary text-base font-bold flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : <LogIn size={18} />}
              Entrar
            </Button>
          </form>

          <p className="text-[11px] text-center text-[#6B6B6B] leading-relaxed">
            Não tem acesso? Solicite à loja onde fez sua compra.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
