import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { listLimitRequests, respondLimitRequest } from "../serverFunctions";
import { assessCustomerCredit } from "@/lib/credit-assessment.functions";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ShieldCheck, Check, X, Loader2, Clock, Sparkles, TrendingUp, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/limites")({
  component: LimitesPage,
});

const brl = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(n) || 0);

function LimitesPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["limit-requests"],
    queryFn: () => listLimitRequests(),
    refetchInterval: 15_000,
  });
  const [overrides, setOverrides] = useState<Record<string, string>>({});

  // Realtime sync — instant updates on new/changed requests
  useEffect(() => {
    const channel = supabase
      .channel("admin-limit-requests")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "limit_requests" },
        (payload) => {
          qc.invalidateQueries({ queryKey: ["limit-requests"] });
          qc.invalidateQueries({ queryKey: ["pending-alerts-bell"] });
          if (payload.eventType === "INSERT") {
            const row: any = payload.new;
            toast.info("Nova solicitação de liberação de limite!", {
              description: `Loja: ${row.store_name || "—"} · ${brl(Number(row.requested_amount || 0))}`,
            });
          } else if (payload.eventType === "UPDATE") {
            qc.invalidateQueries({ queryKey: ["customers"] });
            qc.invalidateQueries({ queryKey: ["dashboardSummary"] });
          }
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const respond = useMutation({
    mutationFn: (vars: { id: string; approve: boolean; approvedAmount?: number; note?: string }) =>
      respondLimitRequest({ data: vars }),
    onSuccess: (_res, vars) => {
      toast.success(vars.approve ? "Limite aprovado e atualizado!" : "Solicitação rejeitada.");
      qc.invalidateQueries({ queryKey: ["limit-requests"] });
      qc.invalidateQueries({ queryKey: ["pending-alerts-bell"] });
      qc.invalidateQueries({ queryKey: ["customers"] });
      qc.invalidateQueries({ queryKey: ["dashboardSummary"] });
    },
    onError: (e: any) => toast.error(e?.message || "Erro."),
  });


  const list = (data || []) as any[];
  const pending = list.filter((r) => r.status === "pending");
  const history = list.filter((r) => r.status !== "pending");

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-6">
      <div className="flex items-center gap-3">
        <ShieldCheck className="text-[#C84D8A]" size={28} />
        <h1 className="text-3xl font-black text-[#2A2A2A]">Liberação de Limites</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock size={18} className="text-amber-600" /> Pendentes
            <Badge className="ml-2 bg-amber-100 text-amber-800 border border-amber-200">{pending.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-24 bg-gray-100 animate-pulse rounded-xl" />
          ) : !pending.length ? (
            <p className="text-sm text-[#6B6B6B] text-center py-6">Nenhuma solicitação pendente.</p>
          ) : (
            <ul className="space-y-3">
              {pending.map((r) => (
                <PendingRequestItem
                  key={r.id}
                  request={r}
                  override={overrides[r.id] || ""}
                  setOverride={(v) => setOverrides((o) => ({ ...o, [r.id]: v }))}
                  onApprove={(amt) => respond.mutate({ id: r.id, approve: true, approvedAmount: amt })}
                  onReject={() => respond.mutate({ id: r.id, approve: false })}
                  isPending={respond.isPending}
                />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          {!history.length ? (
            <p className="text-sm text-[#6B6B6B] text-center py-6">Sem histórico ainda.</p>
          ) : (
            <ul className="divide-y divide-[#EAEAEA]">
              {history.map((r) => (
                <li key={r.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-bold text-[#2A2A2A] truncate">{r.customer?.name}</div>
                    <div className="text-xs text-[#6B6B6B]">
                      {r.store_name} · {new Date(r.created_at).toLocaleDateString("pt-BR")}
                    </div>
                  </div>
                  <Badge
                    className={
                      r.status === "approved"
                        ? "bg-green-100 text-green-800 border border-green-200"
                        : "bg-red-100 text-red-800 border border-red-200"
                    }
                  >
                    {r.status === "approved" ? "Aprovado" : "Rejeitado"} · extra de {brl(r.approved_amount || r.requested_amount)}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PendingRequestItem({
  request: r,
  override,
  setOverride,
  onApprove,
  onReject,
  isPending,
}: {
  request: any;
  override: string;
  setOverride: (v: string) => void;
  onApprove: (amt?: number) => void;
  onReject: () => void;
  isPending: boolean;
}) {
  const assess = useQuery({
    queryKey: ["assess", r.customer?.id],
    queryFn: () => assessCustomerCredit({ data: { customerId: r.customer.id } }),
    enabled: !!r.customer?.id,
    staleTime: 60_000,
  });

  const noAmountRequested = !(Number(r.requested_amount) > 0);
  const suggested = assess.data?.suggestedExtra || 0;
  const rating = assess.data?.stats.rating;
  const ratingStyles: Record<string, string> = {
    excelente: "bg-green-100 text-green-800 border-green-300",
    bom: "bg-emerald-50 text-emerald-700 border-emerald-200",
    regular: "bg-amber-100 text-amber-800 border-amber-300",
    risco: "bg-red-100 text-red-800 border-red-300",
  };

  return (
    <li className="rounded-2xl border border-[#EAEAEA] p-4 bg-white space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-black text-[#2A2A2A]">{r.customer?.name || "Cliente"}</div>
          <div className="text-xs text-[#6B6B6B]">
            Loja: {r.store_name || "—"} · Limite atual: {brl(r.customer?.credit_limit || 0)}
          </div>
          {r.reason && <div className="text-xs italic text-[#6B6B6B] mt-1">"{r.reason}"</div>}
          {r.purchase_amount > 0 && (
            <div className="text-xs text-[#6B6B6B] mt-1">Compra em andamento: {brl(r.purchase_amount)}</div>
          )}
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-[#6B6B6B]">Extra solicitado</div>
          <div className="text-xl font-black text-[#7D2958]">
            {noAmountRequested ? "a definir" : brl(r.requested_amount)}
          </div>
        </div>
      </div>

      {/* IA — parecer */}
      <div className="rounded-xl border border-[#F0D7E3] bg-gradient-to-br from-[#FFF7FB] to-white p-3">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles size={14} className="text-[#C84D8A]" />
          <span className="text-[11px] font-black uppercase tracking-wider text-[#7D2958]">VERA · análise de crédito</span>
          {rating && (
            <Badge className={`ml-auto border ${ratingStyles[rating]} text-[10px] uppercase font-bold`}>
              {rating} · {assess.data?.stats.score}/100
            </Badge>
          )}
        </div>
        {assess.isLoading ? (
          <div className="flex items-center gap-2 text-xs text-[#6B6B6B]"><Loader2 className="animate-spin" size={12} /> analisando histórico…</div>
        ) : assess.data ? (
          <>
            <p className="text-sm text-[#2A2A2A] leading-snug">{assess.data.advice}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3 text-[11px]">
              <Stat label="Em dia" value={assess.data.stats.onTimeRate !== null ? `${assess.data.stats.onTimeRate}%` : "—"} />
              <Stat label="Pagas" value={`${assess.data.stats.paidOnTime}/${assess.data.stats.paidCount}`} />
              <Stat label="Atraso médio" value={`${assess.data.stats.avgDelayDays}d`} />
              <Stat
                label="Vencidas abertas"
                value={assess.data.stats.overdueOpen > 0 ? `${assess.data.stats.overdueOpen} · ${brl(assess.data.stats.overdueOpenAmount)}` : "0"}
                danger={assess.data.stats.overdueOpen > 0}
              />
            </div>
            {suggested > 0 && (
              <button
                type="button"
                onClick={() => setOverride(String(suggested))}
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-[#7D2958] hover:underline"
              >
                <TrendingUp size={12} /> Usar sugestão da IA: {brl(suggested)}
              </button>
            )}
          </>
        ) : (
          <p className="text-xs text-[#6B6B6B]">Sem parecer disponível.</p>
        )}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex-1 min-w-[160px]">
          <Input
            type="number"
            placeholder={noAmountRequested ? "Valor extra (R$)" : String(r.requested_amount)}
            value={override}
            onChange={(e) => setOverride(e.target.value)}
            className="h-10 bg-[#FAF6F7] border-[#EAEAEA]"
          />
        </div>
        <Button
          onClick={() => {
            const amt = override ? Number(override) : (noAmountRequested ? suggested : undefined);
            if (noAmountRequested && !(Number(amt) > 0)) {
              toast.error("Informe o valor a liberar.");
              return;
            }
            onApprove(amt);
          }}
          disabled={isPending}
          className="btn-primary gap-1 h-10"
        >
          <Check size={14} /> Aprovar
        </Button>
        <Button
          onClick={onReject}
          disabled={isPending}
          variant="outline"
          className="gap-1 h-10 border-red-300 text-red-700 hover:bg-red-50"
        >
          <X size={14} /> Rejeitar
        </Button>
      </div>
    </li>
  );
}

function Stat({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className={`rounded-lg px-2 py-1.5 border ${danger ? "border-red-200 bg-red-50" : "border-[#EAEAEA] bg-white"}`}>
      <div className="text-[9px] uppercase font-bold text-[#6B6B6B] tracking-wider">{label}</div>
      <div className={`text-xs font-black ${danger ? "text-red-700" : "text-[#2A2A2A]"}`}>{value}</div>
    </div>
  );
}

