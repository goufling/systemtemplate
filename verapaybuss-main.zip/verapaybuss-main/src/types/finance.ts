export type PaymentStatus = "pending" | "paid" | "overdue" | "rescheduled";

export type PaymentMethod = "pix" | "cheque" | "card" | "cash" | "nota_promissoria";

export interface Customer {
  id: string;
  name: string;
  phone: string;
  totalBorrowed: number;
  activeLoans: number;
}

export interface Loan {
  id: string;
  customerId: string;
  storeName: string;
  totalAmount: number;
  date: string;
  installmentsCount: number;
  status: "active" | "completed";
}

export interface Installment {
  id: string;
  loanId: string;
  customerId: string;
  number: number; // 1, 2, or 3
  amount: number;
  dueDate: string;
  status: PaymentStatus;
  paymentMethod?: PaymentMethod;
  paidAt?: string;
  notes?: string;
}
