import { Customer, Loan, Installment } from "./types/finance";

export const MOCK_CUSTOMERS: Customer[] = [
  { id: "1", name: "João Silva", phone: "(11) 98888-7777", totalBorrowed: 1500, activeLoans: 1 },
  { id: "2", name: "Maria Oliveira", phone: "(11) 97777-6666", totalBorrowed: 3000, activeLoans: 2 },
  { id: "3", name: "Carlos Santos", phone: "(11) 96666-5555", totalBorrowed: 500, activeLoans: 0 },
];

export const MOCK_LOANS: Loan[] = [
  {
    id: "l1",
    customerId: "1",
    storeName: "Loja ABC",
    totalAmount: 1500,
    date: "2023-10-01",
    installmentsCount: 3,
    status: "active",
  },
  {
    id: "l2",
    customerId: "2",
    storeName: "Magazine XYZ",
    totalAmount: 3000,
    date: "2023-10-15",
    installmentsCount: 3,
    status: "active",
  },
];

export const MOCK_INSTALLMENTS: Installment[] = [
  {
    id: "i1",
    loanId: "l1",
    customerId: "1",
    number: 1,
    amount: 500,
    dueDate: "2023-11-01",
    status: "paid",
    paymentMethod: "pix",
    paidAt: "2023-11-01",
  },
  {
    id: "i2",
    loanId: "l1",
    customerId: "1",
    number: 2,
    amount: 500,
    dueDate: "2023-12-01",
    status: "pending",
  },
  {
    id: "i3",
    loanId: "l1",
    customerId: "1",
    number: 3,
    amount: 500,
    dueDate: "2024-01-01",
    status: "pending",
  },
  {
    id: "i4",
    loanId: "l2",
    customerId: "2",
    number: 1,
    amount: 1000,
    dueDate: "2023-11-15",
    status: "overdue",
  },
];
