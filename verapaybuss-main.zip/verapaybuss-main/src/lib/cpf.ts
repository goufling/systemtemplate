// CPF helpers shared by client and server.
// Synthetic email format used to register a client in Supabase Auth
// using only their CPF + a password chosen by the admin.

export const cleanCpf = (raw: string) => (raw || "").replace(/\D/g, "");

export const formatCpf = (raw: string) => {
  const c = cleanCpf(raw);
  if (c.length !== 11) return raw;
  return `${c.slice(0, 3)}.${c.slice(3, 6)}.${c.slice(6, 9)}-${c.slice(9)}`;
};

// Algorithmic CPF validation (does NOT check the federal database).
export const isValidCpf = (raw: string): boolean => {
  const cpf = cleanCpf(raw);
  if (cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  const calc = (size: number) => {
    let sum = 0;
    for (let i = 0; i < size; i++) sum += parseInt(cpf[i], 10) * (size + 1 - i);
    const r = (sum * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return calc(9) === parseInt(cpf[9], 10) && calc(10) === parseInt(cpf[10], 10);
};

// Synthetic email used to register clients in Supabase Auth.
// They never see or type this — they log in with CPF + password.
export const cpfToSyntheticEmail = (cpf: string) =>
  `cpf${cleanCpf(cpf)}@clientes.verapay.app`;
