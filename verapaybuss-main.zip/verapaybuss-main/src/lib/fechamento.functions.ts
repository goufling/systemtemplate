import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type CtxData<T> = { context: any; data: T };

// Get monthly closing report grouped by store
export const getMonthlyClosing = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<{ year: number; month: number }>) => {
    const { supabase, userId } = context;
    const { year, month } = data;

    const start = new Date(Date.UTC(year, month - 1, 1)).toISOString();
    const end = new Date(Date.UTC(year, month, 1)).toISOString();

    const { data: records, error } = await supabase
      .from("payment_records")
      .select(`
        id, amount, paid_at, payment_method, card_fee,
        installment:installments!inner (
          id, number,
          loan:loans!inner ( id, store_name, profit_margin_percent, total_amount ),
          customer:customers!inner ( id, name )
        )
      `)
      .eq("user_id", userId)
      .gte("paid_at", start)
      .lt("paid_at", end)
      .order("paid_at", { ascending: true });

    if (error) throw new Error("Erro ao buscar fechamento: " + error.message);

    // Group by store
    const byStore = new Map<string, any>();
    let grandTotal = 0;
    let grandCommission = 0;
    let totalCardFee = 0;
    const methodTotals: Record<string, number> = {};

    for (const r of records || []) {
      const inst: any = r.installment;
      const loan: any = inst?.loan;
      const storeName = loan?.store_name || "(Sem loja)";
      const margin = Number(loan?.profit_margin_percent || 0);
      const amount = Number(r.amount || 0);
      const fee = Number(r.card_fee || 0);
      const commission = amount * (margin / 100);

      if (!byStore.has(storeName)) {
        byStore.set(storeName, {
          storeName,
          totalReceived: 0,
          totalCommission: 0,
          totalCardFee: 0,
          marginPercent: margin,
          methods: {} as Record<string, number>,
          payments: [] as any[],
        });
      }
      const s = byStore.get(storeName);
      s.totalReceived += amount;
      s.totalCommission += commission;
      s.totalCardFee += fee;
      s.methods[r.payment_method] = (s.methods[r.payment_method] || 0) + amount;
      s.payments.push({
        id: r.id,
        amount,
        paidAt: r.paid_at,
        method: r.payment_method,
        cardFee: fee,
        commission,
        customerName: inst?.customer?.name,
        installmentNumber: inst?.number,
      });

      grandTotal += amount;
      grandCommission += commission;
      totalCardFee += fee;
      methodTotals[r.payment_method] = (methodTotals[r.payment_method] || 0) + amount;
    }

    const stores = Array.from(byStore.values()).sort((a, b) => b.totalReceived - a.totalReceived);

    // Check if month is already closed
    const { data: closing } = await supabase
      .from("month_closings")
      .select("*")
      .eq("user_id", userId)
      .eq("year", year)
      .eq("month", month)
      .maybeSingle();

    return {
      year,
      month,
      stores,
      totals: {
        received: grandTotal,
        commission: grandCommission,
        cardFee: totalCardFee,
        net: grandTotal - totalCardFee,
        methodTotals,
        paymentsCount: (records || []).length,
        storesCount: stores.length,
      },
      closing: closing || null,
    };
  });

export const closeMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { year: number; month: number; notes?: string; totals?: any; stores?: any[] }) => d)
  .handler(async ({ context, data }: CtxData<{ year: number; month: number; notes?: string; totals?: any; stores?: any[] }>) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("month_closings")
      .upsert({
        user_id: userId,
        year: data.year,
        month: data.month,
        notes: data.notes,
        totals: data.totals,
        stores: data.stores, // Assuming a 'stores' jsonb column exists or we add it to 'totals'
        closed_at: new Date().toISOString(),
      }, { onConflict: "user_id,year,month" })
      .select()
      .single();
    if (error) throw new Error("Erro ao fechar mês: " + error.message);
    return row;
  });

export const reopenMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<{ year: number; month: number }>) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("month_closings")
      .delete()
      .eq("user_id", userId)
      .eq("year", data.year)
      .eq("month", data.month);
    if (error) throw new Error("Erro ao reabrir mês: " + error.message);
    return { ok: true };
  });

export const listMonthClosings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("month_closings")
      .select("*")
      .eq("user_id", userId)
      .order("year", { ascending: false })
      .order("month", { ascending: false });
    if (error) throw new Error("Erro ao listar fechamentos");
    return data || [];
  });

// ===== Per-customer monthly note closing =====

export const getCustomerClosing = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string; year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<{ customerId: string; year: number; month: number }>) => {
    const { supabase } = context;
    const { data: row } = await supabase
      .from("customer_month_closings")
      .select("*")
      .eq("customer_id", data.customerId)
      .eq("year", data.year)
      .eq("month", data.month)
      .maybeSingle();
    return row || null;
  });

export const listCustomerClosings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string }) => d)
  .handler(async ({ context, data }: CtxData<{ customerId: string }>) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("customer_month_closings")
      .select("*")
      .eq("customer_id", data.customerId)
      .order("year", { ascending: false })
      .order("month", { ascending: false });
    if (error) throw new Error(error.message);
    return rows || [];
  });

export const closeCustomerMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string; year: number; month: number; closedByRole?: "admin" | "store" | "client"; totalAmount?: number; notes?: string }) => d)
  .handler(async ({ context, data }: CtxData<any>) => {
    const { supabase, userId } = context;
    // Resolve owner user_id from customer record
    const { data: cust, error: cErr } = await supabase
      .from("customers")
      .select("user_id, client_user_id")
      .eq("id", data.customerId)
      .single();
    if (cErr || !cust) throw new Error("Cliente não encontrado");

    const { data: row, error } = await supabase
      .from("customer_month_closings")
      .upsert({
        customer_id: data.customerId,
        user_id: cust.user_id,
        year: data.year,
        month: data.month,
        closed_at: new Date().toISOString(),
        closed_by_role: data.closedByRole || "admin",
        closed_by_user_id: userId,
        total_amount: data.totalAmount ?? 0,
        notes: data.notes,
      }, { onConflict: "customer_id,year,month" })
      .select()
      .single();
    if (error) throw new Error("Erro ao fechar nota: " + error.message);
    return row;
  });

export const reopenCustomerMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string; year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<any>) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("customer_month_closings")
      .delete()
      .eq("customer_id", data.customerId)
      .eq("year", data.year)
      .eq("month", data.month);
    if (error) throw new Error("Erro ao reabrir nota: " + error.message);
    return { ok: true };
  });

// List all customers and their closing status for a given period (admin view)
export const listCustomersClosingStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<{ year: number; month: number }>) => {
    const { supabase, userId } = context;
    const { data: customers, error } = await supabase
      .from("customers")
      .select("id, name, phone")
      .eq("user_id", userId)
      .order("name");
    if (error) throw new Error(error.message);

    const ids = (customers || []).map((c: any) => c.id);
    if (ids.length === 0) return [];

    const { data: closings } = await supabase
      .from("customer_month_closings")
      .select("*")
      .eq("year", data.year)
      .eq("month", data.month)
      .in("customer_id", ids);

    const map = new Map((closings || []).map((c: any) => [c.customer_id, c]));
    return (customers || []).map((c: any) => ({
      ...c,
      closing: map.get(c.id) || null,
    }));
  });

// ===== Per-store monthly purchase closing =====

export const listStorePurchasesByMonth = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<{ year: number; month: number }>) => {
    const { supabase, userId } = context;
    const { year, month } = data;
    const start = `${year}-${String(month).padStart(2, "0")}-01`;
    const endDate = new Date(Date.UTC(year, month, 1));
    const end = `${endDate.getUTCFullYear()}-${String(endDate.getUTCMonth() + 1).padStart(2, "0")}-01`;

    const { data: loans, error } = await supabase
      .from("loans")
      .select("id, store_name, total_amount, loan_date, order_number, delivery_note, notes, customer:customers(name)")
      .eq("user_id", userId)
      .gte("loan_date", start)
      .lt("loan_date", end)
      .order("loan_date", { ascending: true });
    if (error) throw new Error(error.message);

    const { data: closings } = await supabase
      .from("store_month_closings")
      .select("*")
      .eq("user_id", userId)
      .eq("year", year)
      .eq("month", month);

    const byStore = new Map<string, any>();
    for (const l of loans || []) {
      const name = l.store_name || "(Sem loja)";
      if (!byStore.has(name)) {
        byStore.set(name, { storeName: name, totalAmount: 0, purchases: [] as any[] });
      }
      const s = byStore.get(name);
      s.totalAmount += Number(l.total_amount || 0);
      s.purchases.push({
        id: l.id,
        loanDate: l.loan_date,
        totalAmount: Number(l.total_amount || 0),
        orderNumber: l.order_number,
        deliveryNote: l.delivery_note,
        notes: l.notes,
        customerName: (l.customer as any)?.name || "—",
      });
    }
    const closingMap = new Map((closings || []).map((c: any) => [c.store_name, c]));
    // Include closed stores even if no purchases this month
    for (const c of closings || []) {
      if (!byStore.has(c.store_name)) {
        byStore.set(c.store_name, { storeName: c.store_name, totalAmount: 0, purchases: [] });
      }
    }
    return Array.from(byStore.values())
      .map((s: any) => ({ ...s, closing: closingMap.get(s.storeName) || null }))
      .sort((a, b) => b.totalAmount - a.totalAmount);
  });

export const closeStoreMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeName: string; year: number; month: number; totalAmount: number; purchasesCount: number; notes?: string; paymentMethod?: string; commissionAmount?: number; paymentDetails?: any }) => d)
  .handler(async ({ context, data }: CtxData<any>) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("store_month_closings")
      .upsert({
        user_id: userId,
        store_name: data.storeName,
        year: data.year,
        month: data.month,
        total_amount: data.totalAmount,
        purchases_count: data.purchasesCount,
        notes: data.notes,
        payment_method: data.paymentMethod,
        commission_amount: data.commissionAmount ?? 0,
        payment_details: data.paymentDetails ?? null,
        closed_at: new Date().toISOString(),
        closed_by_user_id: userId,
      }, { onConflict: "user_id,store_name,year,month" })
      .select()
      .single();
    if (error) throw new Error("Erro ao fechar loja: " + error.message);
    return row;
  });


export const reopenStoreMonth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeName: string; year: number; month: number }) => d)
  .handler(async ({ context, data }: CtxData<any>) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("store_month_closings")
      .delete()
      .eq("user_id", userId)
      .eq("store_name", data.storeName)
      .eq("year", data.year)
      .eq("month", data.month);
    if (error) throw new Error("Erro ao reabrir loja: " + error.message);
    return { ok: true };
  });

// List all store closings across periods for Financeiro Profissional
export const listAllStoreClosings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("store_month_closings")
      .select("*")
      .eq("user_id", userId)
      .order("year", { ascending: false })
      .order("month", { ascending: false })
      .order("closed_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data || [];
  });
