import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Msg = { role: "user" | "assistant" | "system"; content: string };

const BRL = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);

const fmtDate = (d: string) => {
  try {
    return new Date(d).toLocaleDateString("pt-BR");
  } catch {
    return d;
  }
};

const daysBetween = (a: Date, b: Date) =>
  Math.round((a.getTime() - b.getTime()) / (1000 * 60 * 60 * 24));

async function buildBusinessContext(supabase: any, userId: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split("T")[0];
  const in7 = new Date(today);
  in7.setDate(in7.getDate() + 7);
  const monthStart = `${todayStr.slice(0, 7)}-01`;
  const year = today.getFullYear();
  const month = today.getMonth() + 1;

  const [
    { data: installments },
    { data: customers },
    { data: loans },
    { data: recentPayments },
    { data: personalTx },
    { data: customerClosings },
  ] = await Promise.all([
    supabase
      .from("installments")
      .select("id, amount, due_date, status, number, customer_id, loan_id, customers(name, phone), loans(store_name)")
      .eq("user_id", userId)
      .in("status", ["pending", "overdue"])
      .order("due_date", { ascending: true }),
    supabase.from("customers").select("id, name, phone").eq("user_id", userId),
    supabase
      .from("loans")
      .select("id, total_amount, status, capital_source, customers(name)")
      .eq("user_id", userId)
      .eq("status", "active"),
    supabase
      .from("payment_records")
      .select("amount, paid_at, payment_method, installments(customers(name))")
      .eq("user_id", userId)
      .order("paid_at", { ascending: false })
      .limit(10),
    supabase
      .from("personal_transactions")
      .select("amount, type, category_name, transaction_date, description")
      .eq("user_id", userId)
      .gte("transaction_date", monthStart)
      .order("transaction_date", { ascending: false }),
    supabase
      .from("customer_month_closings")
      .select("customer_id, total_amount, closed_at")
      .eq("user_id", userId)
      .eq("year", year)
      .eq("month", month),
  ]);

  const overdue: any[] = [];
  const dueToday: any[] = [];
  const dueSoon: any[] = [];
  let totalReceivable = 0;
  const debtByCustomer = new Map<string, { name: string; phone: string; total: number; count: number }>();

  for (const i of installments || []) {
    totalReceivable += Number(i.amount);
    const due = new Date(i.due_date);
    due.setHours(0, 0, 0, 0);
    const diff = daysBetween(due, today);
    const name = i.customers?.name || "—";
    const phone = i.customers?.phone || "";
    const enriched = {
      id: i.id,
      customer: name,
      customer_id: i.customer_id,
      phone,
      store: i.loans?.store_name || "—",
      number: i.number,
      amount: Number(i.amount),
      dueDate: i.due_date,
      daysOverdue: -diff,
    };
    if (diff < 0) overdue.push(enriched);
    else if (diff === 0) dueToday.push(enriched);
    else if (diff <= 7) dueSoon.push(enriched);

    const cur = debtByCustomer.get(i.customer_id) || { name, phone, total: 0, count: 0 };
    cur.total += Number(i.amount);
    cur.count += 1;
    debtByCustomer.set(i.customer_id, cur);
  }

  const topDebtors = Array.from(debtByCustomer.entries())
    .map(([id, v]) => ({ customer_id: id, ...v }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  const personalIncome = (personalTx || []).filter((t: any) => t.type === "income").reduce((a: number, b: any) => a + Number(b.amount), 0);
  const personalExpense = (personalTx || []).filter((t: any) => t.type === "expense").reduce((a: number, b: any) => a + Number(b.amount), 0);

  const closedIds = new Set((customerClosings || []).map((c: any) => c.customer_id));
  const customersNotClosed = (customers || []).filter((c: any) => !closedIds.has(c.id)).length;

  return {
    today: todayStr,
    year,
    month,
    customersCount: customers?.length || 0,
    activeLoansCount: loans?.length || 0,
    totalReceivable,
    overdue,
    dueToday,
    dueSoon,
    topDebtors,
    personal: {
      income: personalIncome,
      expense: personalExpense,
      balance: personalIncome - personalExpense,
      txCount: personalTx?.length || 0,
    },
    closings: {
      closedThisMonth: customerClosings?.length || 0,
      pendingThisMonth: customersNotClosed,
    },
    recentPayments: (recentPayments || []).map((p: any) => ({
      amount: Number(p.amount),
      paidAt: p.paid_at,
      method: p.payment_method,
      customer: p.installments?.customers?.name,
    })),
  };
}

export const getPendingAlerts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const ctx = await buildBusinessContext(supabase, userId);

    const alerts: { severity: "high" | "medium" | "low"; title: string; message: string; count?: number; amount?: number }[] = [];

    // Pending limit requests (highest priority — action required by admin)
    const { data: limitReqs } = await supabase
      .from("limit_requests")
      .select("id, requested_amount, store_name, customer:customers(name)")
      .eq("owner_user_id", userId)
      .eq("status", "pending")
      .order("created_at", { ascending: false })
      .limit(20);
    const pendingLimits = limitReqs || [];
    if (pendingLimits.length > 0) {
      const sumLim = pendingLimits.reduce((a: number, b: any) => a + Number(b.requested_amount || 0), 0);
      const first: any = pendingLimits[0];
      alerts.push({
        severity: "high",
        title: `${pendingLimits.length} liberação(ões) de limite pendente(s)`,
        message: `Aguardando aprovação. Ex.: ${first.customer?.name || "Cliente"} via ${first.store_name || "loja"} — ${BRL(Number(first.requested_amount))}.`,
        count: pendingLimits.length,
        amount: sumLim,
      });
    }

    if (ctx.overdue.length > 0) {
      const sum = ctx.overdue.reduce((a, b) => a + b.amount, 0);
      alerts.push({
        severity: "high",
        title: `${ctx.overdue.length} parcela(s) em atraso`,
        message: `Total atrasado: ${BRL(sum)}. Cliente mais antigo: ${ctx.overdue[0].customer} (${ctx.overdue[0].daysOverdue} dias).`,
        count: ctx.overdue.length,
        amount: sum,
      });
    }
    if (ctx.dueToday.length > 0) {
      const sum = ctx.dueToday.reduce((a, b) => a + b.amount, 0);
      alerts.push({
        severity: "medium",
        title: `${ctx.dueToday.length} parcela(s) vencem hoje`,
        message: `Total a receber hoje: ${BRL(sum)}. Entre em contato com os clientes para confirmar o pagamento.`,
        count: ctx.dueToday.length,
        amount: sum,
      });
    }
    if (ctx.dueSoon.length > 0) {
      const sum = ctx.dueSoon.reduce((a, b) => a + b.amount, 0);
      alerts.push({
        severity: "low",
        title: `${ctx.dueSoon.length} parcela(s) vencem em até 7 dias`,
        message: `Antecipe-se: ${BRL(sum)} previstos. Considere enviar lembretes via WhatsApp.`,
        count: ctx.dueSoon.length,
        amount: sum,
      });
    }

    return {
      alerts,
      summary: {
        overdueCount: ctx.overdue.length,
        dueTodayCount: ctx.dueToday.length,
        dueSoonCount: ctx.dueSoon.length,
        totalReceivable: ctx.totalReceivable,
        pendingLimitsCount: pendingLimits.length,
      },
      overdueList: ctx.overdue.slice(0, 5),
      dueTodayList: ctx.dueToday.slice(0, 5),
    };
  });


export const chatWithAssistant = createServerFn({ method: "POST" })
  .inputValidator((d: { messages: Msg[] }) => d)
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any; data: { messages: Msg[] } }) => {
    const { supabase, userId } = context;
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY não configurada");

    const ctx = await buildBusinessContext(supabase, userId);

    const contextSummary = `
DATA DE HOJE: ${fmtDate(ctx.today)} (mês de referência ${String(ctx.month).padStart(2, "0")}/${ctx.year})

📊 OPERAÇÃO:
- Clientes: ${ctx.customersCount} | Notas ativas: ${ctx.activeLoansCount}
- Total a receber em aberto: ${BRL(ctx.totalReceivable)}
- Fechamentos do mês: ${ctx.closings.closedThisMonth} fechados / ${ctx.closings.pendingThisMonth} pendentes

🏆 TOP DEVEDORES (em aberto agora):
${ctx.topDebtors.map((d, i) => `${i + 1}. ${d.name} — ${BRL(d.total)} (${d.count} parcelas)${d.phone ? ` · 📱 ${d.phone}` : ""}`).join("\n") || "Nenhum."}

⚠️ EM ATRASO (${ctx.overdue.length}):
${ctx.overdue.slice(0, 15).map(o => `- ${o.customer} (${o.store}) — P${o.number} — ${BRL(o.amount)} — venceu ${fmtDate(o.dueDate)} (${o.daysOverdue}d)`).join("\n") || "Nenhuma."}

📅 VENCEM HOJE (${ctx.dueToday.length}):
${ctx.dueToday.map(o => `- ${o.customer} — ${BRL(o.amount)} — P${o.number}`).join("\n") || "Nenhuma."}

🔔 PRÓXIMOS 7 DIAS (${ctx.dueSoon.length}):
${ctx.dueSoon.slice(0, 10).map(o => `- ${o.customer} — ${BRL(o.amount)} — ${fmtDate(o.dueDate)}`).join("\n") || "Nenhuma."}

💰 ÚLTIMOS RECEBIMENTOS:
${ctx.recentPayments.slice(0, 5).map((p: any) => `- ${p.customer || "—"} — ${BRL(p.amount)} via ${p.method} em ${fmtDate(p.paidAt)}`).join("\n") || "Nenhum."}

🏠 FINANÇAS PESSOAIS (mês atual):
- Receitas: ${BRL(ctx.personal.income)} | Despesas: ${BRL(ctx.personal.expense)} | Saldo: ${BRL(ctx.personal.balance)}
`.trim();

    const systemPrompt = `Você é a VERA — assistente financeira da VeraPay. Estilo: executiva sênior brasileira, calorosa, decidida, antecipa problemas. Atua como sócia da gestora, não como FAQ.

REGRAS DE OURO:
- Use SEMPRE dados reais do contexto abaixo. Cite NOMES e VALORES exatos.
- Seja proativa: se há atrasos críticos ou top devedores, mencione antes de responder o resto.
- Tom: direto, em português brasileiro. Frases curtas. Sem floreio. Use emojis com critério (⚠️ 📅 💰 ✅ 🏆 📱).
- Sugira ação concreta: "Mando o WhatsApp pra X?", "Quer que eu feche o mês de Y?", "Registro essa despesa em alimentação?".
- Quando o usuário pedir algo executável, USE A FERRAMENTA — não descreva, faça. Confirme em 1-2 frases após executar.
- Se faltar dado, assuma padrões inteligentes (data=hoje, método=pix, 1ª parcela em 30d) e execute.
- Toda criação automática vai com nota "[CRIADO POR IA - revisar]".
- Fora do escopo financeiro: redirecione em 1 linha.
- Respostas: máximo 4 parágrafos curtos. Use bullets/markdown quando ajudar.

${contextSummary}`;

    const tools = [
      {
        type: "function",
        function: {
          name: "create_customer",
          description: "Cria um novo cliente. Use quando o usuário disser 'crie cliente X', 'adicione cliente'. Sempre pergunte/inclua o CPF se o usuário mencionar.",
          parameters: {
            type: "object",
            properties: {
              name: { type: "string", description: "Nome completo do cliente" },
              phone: { type: "string", description: "Telefone (opcional)" },
              cpf: { type: "string", description: "CPF do cliente (opcional, apenas números ou formatado)" },
            },
            required: ["name"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "create_loan",
          description: "Cria uma nota/empréstimo com parcelas para um cliente. Se o cliente não existir, cria automaticamente.",
          parameters: {
            type: "object",
            properties: {
              customer_name: { type: "string" },
              customer_cpf: { type: "string", description: "CPF do cliente (opcional). Usado se o cliente for criado automaticamente." },
              total_amount: { type: "number", description: "Valor total em reais" },
              installments_count: { type: "integer" },
              store_name: { type: "string", description: "Default: 'Compra'" },
              loan_date: { type: "string", description: "YYYY-MM-DD. Default: hoje" },
              first_due_date: { type: "string", description: "YYYY-MM-DD. Default: dia 10 do próximo mês (padrão do sistema)." },
            },
            required: ["customer_name", "total_amount", "installments_count"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "mark_installment_paid",
          description: "Marca uma parcela como paga.",
          parameters: {
            type: "object",
            properties: {
              customer_name: { type: "string" },
              installment_number: { type: "integer", description: "Se omitido, usa a próxima em aberto." },
              method: { type: "string", enum: ["pix", "cheque", "card", "cash", "nota_promissoria"] },
            },
            required: ["customer_name"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "search_customer",
          description: "Busca clientes pelo nome e retorna empréstimos/parcelas.",
          parameters: {
            type: "object",
            properties: { query: { type: "string" } },
            required: ["query"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "generate_month_report",
          description: "Relatório de um mês: total a receber, recebido, em atraso.",
          parameters: {
            type: "object",
            properties: { month: { type: "string", description: "YYYY-MM. Default: mês atual" } },
          },
        },
      },
      {
        type: "function",
        function: {
          name: "register_personal_transaction",
          description: "Registra uma despesa ou receita pessoal da gestora. Use quando ela falar 'gastei X', 'paguei conta de Y', 'recebi Z'.",
          parameters: {
            type: "object",
            properties: {
              description: { type: "string" },
              amount: { type: "number", description: "Valor em reais (positivo)" },
              type: { type: "string", enum: ["income", "expense"] },
              category: { type: "string", description: "Ex: Alimentação, Transporte, Salário" },
              payment_method: { type: "string", description: "pix, cartão, dinheiro..." },
              date: { type: "string", description: "YYYY-MM-DD. Default: hoje" },
            },
            required: ["description", "amount", "type"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "close_customer_month",
          description: "Fecha a nota do cliente no mês atual (impede novas compras até o cliente abrir novamente). Use quando disser 'fecha a nota do X', 'fechar mês do Y'.",
          parameters: {
            type: "object",
            properties: {
              customer_name: { type: "string" },
              notes: { type: "string" },
            },
            required: ["customer_name"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "whatsapp_reminder",
          description: "Gera um link wa.me com mensagem de cobrança pronta para o cliente. Use quando ela pedir para cobrar/lembrar alguém.",
          parameters: {
            type: "object",
            properties: {
              customer_name: { type: "string" },
              tone: { type: "string", enum: ["amigavel", "firme", "urgente"], description: "Default: amigavel" },
            },
            required: ["customer_name"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "customer_balance",
          description: "Retorna saldo devedor total e parcelas em aberto de um cliente específico.",
          parameters: {
            type: "object",
            properties: { customer_name: { type: "string" } },
            required: ["customer_name"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "top_debtors",
          description: "Lista os maiores devedores no momento.",
          parameters: {
            type: "object",
            properties: { limit: { type: "integer", description: "Default 5" } },
          },
        },
      },
    ];

    async function runTool(name: string, args: any): Promise<string> {
      try {
        if (name === "create_customer") {
          const { data: existing } = await supabase
            .from("customers").select("id, name").eq("user_id", userId)
            .ilike("name", args.name).maybeSingle();
          if (existing) return JSON.stringify({ ok: true, already_exists: true, id: existing.id, name: existing.name });
          const { data, error } = await supabase.from("customers").insert({
            user_id: userId, name: args.name, phone: args.phone || null,
            cpf: args.cpf ? String(args.cpf).replace(/\D/g, "") : null,
            notes: "[CRIADO POR IA - revisar dados]",
          }).select("id, name").single();
          if (error) return JSON.stringify({ ok: false, error: error.message });
          return JSON.stringify({ ok: true, id: data.id, name: data.name, ai_created: true });
        }

        if (name === "create_loan") {
          let { data: customer } = await supabase
            .from("customers").select("id, name").eq("user_id", userId)
            .ilike("name", `%${args.customer_name}%`).limit(1).maybeSingle();
          if (!customer) {
            const ins = await supabase.from("customers").insert({
              user_id: userId, name: args.customer_name,
              cpf: args.customer_cpf ? String(args.customer_cpf).replace(/\D/g, "") : null,
              notes: "[CRIADO POR IA - revisar dados]",
            }).select("id, name").single();
            if (ins.error) return JSON.stringify({ ok: false, error: ins.error.message });
            customer = ins.data;
          }
          const loanDate = args.loan_date || new Date().toISOString().split("T")[0];
          const count = Math.max(1, Math.floor(args.installments_count));
          const total = Number(args.total_amount);
          const each = Math.round((total / count) * 100) / 100;
          const { data: loan, error: loanErr } = await supabase.from("loans").insert({
            user_id: userId, customer_id: customer.id,
            store_name: args.store_name || "Compra",
            total_amount: total, loan_date: loanDate,
            installments_count: count, status: "active",
            notes: "[CRIADO POR IA - revisar dados]",
          }).select("id").single();
          if (loanErr) return JSON.stringify({ ok: false, error: loanErr.message });

          // Default: dia 10 do próximo mês (padrão do sistema, igual cadastro manual)
          const firstDue = args.first_due_date ? new Date(args.first_due_date + "T00:00:00") : (() => {
            const base = new Date(loanDate + "T00:00:00");
            const d = new Date(base.getFullYear(), base.getMonth() + 1, 10);
            return d;
          })();
          const installmentsToInsert: any[] = [];
          let remaining = total;
          for (let i = 1; i <= count; i++) {
            const due = new Date(firstDue);
            due.setMonth(due.getMonth() + (i - 1));
            const amt = i === count ? Math.round(remaining * 100) / 100 : each;
            remaining -= each;
            installmentsToInsert.push({
              user_id: userId, loan_id: loan.id, customer_id: customer.id,
              number: i, amount: amt, due_date: due.toISOString().split("T")[0],
              status: "pending",
            });
          }
          const { error: instErr } = await supabase.from("installments").insert(installmentsToInsert);
          if (instErr) return JSON.stringify({ ok: false, error: instErr.message });
          return JSON.stringify({ ok: true, loan_id: loan.id, customer: customer.name, total, count, each, first_due: firstDue.toISOString().split("T")[0], ai_created: true });
        }

        if (name === "mark_installment_paid") {
          const { data: cust } = await supabase
            .from("customers").select("id, name").eq("user_id", userId)
            .ilike("name", `%${args.customer_name}%`).limit(1).maybeSingle();
          if (!cust) return JSON.stringify({ ok: false, error: "Cliente não encontrado" });
          let q = supabase.from("installments").select("id, number, amount")
            .eq("user_id", userId).eq("customer_id", cust.id).neq("status", "paid")
            .order("number", { ascending: true });
          if (args.installment_number) q = q.eq("number", args.installment_number);
          const { data: inst } = await q.limit(1).maybeSingle();
          if (!inst) return JSON.stringify({ ok: false, error: "Parcela em aberto não encontrada" });
          const method = args.method || "pix";
          const { error: payErr } = await supabase.from("payment_records").insert({
            user_id: userId, installment_id: inst.id, amount: inst.amount,
            payment_method: method, paid_at: new Date().toISOString(),
          });
          if (payErr) return JSON.stringify({ ok: false, error: payErr.message });
          return JSON.stringify({ ok: true, customer: cust.name, installment: inst.number, amount: inst.amount, method });
        }

        if (name === "search_customer") {
          const { data } = await supabase
            .from("customers").select("id, name, phone, loans(id, total_amount, installments_count, status, installments(number, amount, status, due_date))")
            .eq("user_id", userId).ilike("name", `%${args.query}%`).limit(5);
          return JSON.stringify({ ok: true, results: data || [] });
        }

        if (name === "generate_month_report") {
          const month = args.month || new Date().toISOString().slice(0, 7);
          const start = `${month}-01`;
          const end = new Date(start); end.setMonth(end.getMonth() + 1);
          const endStr = end.toISOString().split("T")[0];
          const { data: insts } = await supabase
            .from("installments").select("amount, status, customers(name)")
            .eq("user_id", userId).gte("due_date", start).lt("due_date", endStr);
          const total = (insts || []).reduce((a: number, b: any) => a + Number(b.amount), 0);
          const paid = (insts || []).filter((i: any) => i.status === "paid").reduce((a: number, b: any) => a + Number(b.amount), 0);
          const overdue = (insts || []).filter((i: any) => i.status === "overdue").reduce((a: number, b: any) => a + Number(b.amount), 0);
          const pending = total - paid - overdue;
          return JSON.stringify({ ok: true, month, total, paid, pending, overdue, parcelas: insts?.length || 0 });
        }

        if (name === "register_personal_transaction") {
          const date = args.date || new Date().toISOString().split("T")[0];
          const { data, error } = await supabase.from("personal_transactions").insert({
            user_id: userId,
            description: args.description,
            amount: Math.abs(Number(args.amount)),
            type: args.type,
            category_name: args.category || null,
            payment_method: args.payment_method || null,
            transaction_date: date,
            source: "ai",
            notes: "[CRIADO POR IA - revisar]",
          }).select("id").single();
          if (error) return JSON.stringify({ ok: false, error: error.message });
          return JSON.stringify({ ok: true, id: data.id, type: args.type, amount: args.amount, category: args.category, date });
        }

        if (name === "close_customer_month") {
          const { data: cust } = await supabase
            .from("customers").select("id, name").eq("user_id", userId)
            .ilike("name", `%${args.customer_name}%`).limit(1).maybeSingle();
          if (!cust) return JSON.stringify({ ok: false, error: "Cliente não encontrado" });
          const now = new Date();
          const y = now.getFullYear();
          const m = now.getMonth() + 1;
          const { data: pendingInsts } = await supabase
            .from("installments").select("amount")
            .eq("user_id", userId).eq("customer_id", cust.id)
            .in("status", ["pending", "overdue"]);
          const total = (pendingInsts || []).reduce((a: number, b: any) => a + Number(b.amount), 0);
          const { error } = await supabase.from("customer_month_closings").upsert({
            user_id: userId, customer_id: cust.id, year: y, month: m,
            total_amount: total, closed_by_role: "admin", closed_by_user_id: userId,
            notes: args.notes || "[FECHADO PELA VERA]",
          }, { onConflict: "customer_id,year,month" });
          if (error) return JSON.stringify({ ok: false, error: error.message });
          return JSON.stringify({ ok: true, customer: cust.name, year: y, month: m, total });
        }

        if (name === "whatsapp_reminder") {
          const { data: cust } = await supabase
            .from("customers").select("id, name, phone").eq("user_id", userId)
            .ilike("name", `%${args.customer_name}%`).limit(1).maybeSingle();
          if (!cust) return JSON.stringify({ ok: false, error: "Cliente não encontrado" });
          const { data: insts } = await supabase
            .from("installments").select("number, amount, due_date, status")
            .eq("user_id", userId).eq("customer_id", cust.id).in("status", ["pending", "overdue"])
            .order("due_date", { ascending: true });
          const total = (insts || []).reduce((a: number, b: any) => a + Number(b.amount), 0);
          const tone = args.tone || "amigavel";
          const greet = tone === "urgente" ? "Olá" : tone === "firme" ? "Boa, " : "Oi, tudo bem? ";
          const body = `${greet}${cust.name.split(" ")[0]}! Passando pra lembrar das suas parcelas em aberto:\n\n` +
            (insts || []).slice(0, 5).map((i: any) => `• Parcela ${i.number} — ${BRL(Number(i.amount))} — vence ${fmtDate(i.due_date)}${i.status === "overdue" ? " (em atraso)" : ""}`).join("\n") +
            `\n\nTotal em aberto: *${BRL(total)}*\n\nQualquer dúvida me chama por aqui. 🙏`;
          const phone = (cust.phone || "").replace(/\D/g, "");
          const link = phone ? `https://wa.me/55${phone}?text=${encodeURIComponent(body)}` : null;
          return JSON.stringify({ ok: true, customer: cust.name, phone: cust.phone, link, message: body, total, count: insts?.length || 0 });
        }

        if (name === "customer_balance") {
          const { data: cust } = await supabase
            .from("customers").select("id, name, phone").eq("user_id", userId)
            .ilike("name", `%${args.customer_name}%`).limit(1).maybeSingle();
          if (!cust) return JSON.stringify({ ok: false, error: "Cliente não encontrado" });
          const { data: insts } = await supabase
            .from("installments").select("number, amount, due_date, status")
            .eq("user_id", userId).eq("customer_id", cust.id).in("status", ["pending", "overdue"])
            .order("due_date", { ascending: true });
          const total = (insts || []).reduce((a: number, b: any) => a + Number(b.amount), 0);
          return JSON.stringify({ ok: true, customer: cust.name, phone: cust.phone, total_open: total, installments: insts });
        }

        if (name === "top_debtors") {
          return JSON.stringify({ ok: true, debtors: ctx.topDebtors.slice(0, args.limit || 5) });
        }

        return JSON.stringify({ ok: false, error: "Ferramenta desconhecida" });
      } catch (e: any) {
        return JSON.stringify({ ok: false, error: e?.message || "Erro" });
      }
    }

    const messages: any[] = [
      { role: "system", content: systemPrompt },
      ...data.messages.slice(-12),
    ];

    const callModel = async (model: string) => {
      return fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model, messages, tools, temperature: 0.4 }),
      });
    };

    let finalReply = "";
    for (let step = 0; step < 8; step++) {
      let response = await callModel("google/gemini-2.5-pro");
      if (response.status === 429 || response.status >= 500) {
        // Fallback para flash em caso de rate limit ou indisponibilidade do pro
        response = await callModel("google/gemini-2.5-flash");
      }
      if (!response.ok) {
        if (response.status === 429) throw new Error("Muitas requisições. Aguarde um momento.");
        if (response.status === 402) throw new Error("Créditos de IA esgotados. Adicione créditos em Configurações.");
        const t = await response.text();
        console.error("AI Gateway error:", response.status, t);
        throw new Error("Erro ao consultar a IA");
      }
      const json = await response.json();
      const msg = json.choices?.[0]?.message;
      if (!msg) { finalReply = "Não consegui processar agora."; break; }
      messages.push(msg);
      const calls = msg.tool_calls || [];
      if (calls.length === 0) {
        finalReply = msg.content || "Feito.";
        break;
      }
      for (const call of calls) {
        let args = {};
        try { args = JSON.parse(call.function.arguments || "{}"); } catch {}
        const result = await runTool(call.function.name, args);
        messages.push({ role: "tool", tool_call_id: call.id, content: result });
      }
    }
    return { reply: finalReply || "Feito." };
  });
