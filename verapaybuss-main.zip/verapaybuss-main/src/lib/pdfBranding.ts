import type { jsPDF } from "jspdf";
import { format } from "date-fns";

// VeraPay palette (matches src/styles.css tokens)
export const brand = {
  primary: [200, 77, 138] as [number, number, number],   // #C84D8A rosa
  deep: [125, 41, 88] as [number, number, number],       // #7D2958 vinho
  soft: [245, 235, 239] as [number, number, number],     // #F5EBEF rosa claro
  cream: [250, 246, 247] as [number, number, number],    // #FAF6F7 creme
  white: [255, 255, 255] as [number, number, number],
};

const c = (t: [number, number, number]) => [t[0], t[1], t[2]] as const;

export const tableTheme = {
  styles: {
    font: "helvetica" as const,
    fontSize: 11,
    textColor: brand.deep,
    lineColor: brand.primary,
    lineWidth: 0.15,
    cellPadding: 3,
  },
  headStyles: {
    fillColor: brand.deep,
    textColor: brand.white,
    fontStyle: "bold" as const,
    halign: "center" as const,
    lineColor: brand.deep,
  },
  alternateRowStyles: { fillColor: brand.cream },
};

export function drawVeraPayHeader(doc: jsPDF, title: string, subtitle?: string) {
  const pageWidth = doc.internal.pageSize.width;
  doc.setFillColor(brand.deep[0], brand.deep[1], brand.deep[2]);
  doc.rect(14, 14, pageWidth - 28, 16, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.setTextColor(brand.white[0], brand.white[1], brand.white[2]);
  doc.text(title.toUpperCase(), pageWidth / 2, 24, { align: "center" });

  if (subtitle) {
    doc.setFillColor(brand.soft[0], brand.soft[1], brand.soft[2]);
    doc.rect(14, 30, pageWidth - 28, 9, "F");
    doc.setFont("helvetica", "italic");
    doc.setFontSize(10);
    doc.setTextColor(brand.deep[0], brand.deep[1], brand.deep[2]);
    doc.text(subtitle, pageWidth / 2, 36, { align: "center" });
    return 41;
  }
  return 32;
}

export function drawVeraPayFooter(doc: jsPDF) {
  const pageHeight = doc.internal.pageSize.height;
  const pageWidth = doc.internal.pageSize.width;
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFillColor(brand.soft[0], brand.soft[1], brand.soft[2]);
    doc.rect(14, pageHeight - 18, pageWidth - 28, 10, "F");
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(brand.deep[0], brand.deep[1], brand.deep[2]);
    doc.text(
      `VeraPay  •  Gerado em ${format(new Date(), "dd/MM/yyyy 'às' HH:mm")}  •  Página ${i} de ${pageCount}`,
      pageWidth / 2,
      pageHeight - 12,
      { align: "center" }
    );
  }
}

export const fmtMoneyBR = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(v) || 0);
