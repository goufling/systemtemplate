import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const assessCustomerCredit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase } = context;

    const { data: customer } = await supabase
      .from("customers")
      .select("id, name, credit_limit, cpf, created_at")
      .eq("id", data.customerId)
      .maybeSingle();
    if (!customer) throw new Error("Cliente não encontrado.");

    const { data: loans } = await supabase
      .from("loans")
      .select("id, total_amount, loan_date, store:stores(name)")
      .eq("customer_id", data.customerId);

    const { data: installments } = await supabase
      .from("installments")
      .select("id, amount, due_date, paid_at, status, installment_number")
      .in("loan_id", (loans || []).map((l: any) => l.id).length ? (loans || []).map((l: any) => l.id) : ["00000000-0000-0000-0000-000000000000"]);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let paidCount = 0;
    let paidOnTime = 0;
    let paidLate = 0;
    let totalDelayDays = 0;
    let overdueOpen = 0;
    let overdueOpenAmount = 0;
    let openCount = 0;
    let openAmount = 0;
    let totalPurchased = 0;
    let totalPaid = 0;

    for (const i of installments || []) {
      const amt = Number(i.amount || 0);
      const due = new Date(i.due_date);
      if (i.status === "paid" && i.paid_at) {
        paidCount++;
        totalPaid += amt;
        const paid = new Date(i.paid_at);
        const diff = Math.floor((paid.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
        if (diff <= 0) paidOnTime++;
        else { paidLate++; totalDelayDays += diff; }
      } else {
        openCount++;
        openAmount += amt;
        if (due < today) {
          overdueOpen++;
          overdueOpenAmount += amt;
        }
      }
    }
    for (const l of loans || []) totalPurchased += Number(l.total_amount || 0);

    const onTimeRate = paidCount ? Math.round((paidOnTime / paidCount) * 100) : null;
    const avgDelay = paidLate ? Math.round(totalDelayDays / paidLate) : 0;

    // Score heurístico 0-100
    let score = 70;
    if (onTimeRate !== null) score = Math.round(onTimeRate * 0.8 + 20);
    score -= overdueOpen * 8;
    score -= Math.min(avgDelay, 30);
    if (paidCount >= 6 && (onTimeRate ?? 0) >= 90) score += 10;
    score = Math.max(0, Math.min(100, score));

    let rating: "excelente" | "bom" | "regular" | "risco" = "regular";
    if (score >= 85) rating = "excelente";
    else if (score >= 65) rating = "bom";
    else if (score >= 40) rating = "regular";
    else rating = "risco";

    const stats = {
      customerName: customer.name,
      memberSinceDays: Math.floor((today.getTime() - new Date(customer.created_at).getTime()) / (1000 * 60 * 60 * 24)),
      currentLimit: Number(customer.credit_limit || 0),
      totalLoans: (loans || []).length,
      totalPurchased,
      totalPaid,
      paidCount,
      paidOnTime,
      paidLate,
      onTimeRate,
      avgDelayDays: avgDelay,
      openCount,
      openAmount,
      overdueOpen,
      overdueOpenAmount,
      score,
      rating,
    };

    // IA: parecer narrativo curto
    let advice = "";
    let suggestedExtra = 0;
    try {
      const apiKey = process.env.LOVABLE_API_KEY;
      if (apiKey) {
        const prompt = `Você é VERA, analista de crédito. Analise este cliente em até 3 frases curtas (max 60 palavras) e sugira um VALOR EXTRA de liberação seguro (R$). Responda em JSON {"advice":"...","suggested_extra":NUMERO}.

DADOS:
${JSON.stringify(stats, null, 2)}

Regras:
- Se rating=risco ou overdueOpen>0: sugira 0 e recomende negar/aguardar quitação.
- Se rating=excelente: pode sugerir até 50% do limite atual como extra.
- Se rating=bom: até 30%.
- Se rating=regular: até 15%.
- Seja direto, use nomes/valores reais em R$.`;

        const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: "google/gemini-2.5-flash",
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" },
            temperature: 0.3,
          }),
        });
        if (resp.ok) {
          const j = await resp.json();
          const content = j.choices?.[0]?.message?.content || "{}";
          const parsed = JSON.parse(content);
          advice = String(parsed.advice || "");
          suggestedExtra = Number(parsed.suggested_extra || 0);
        }
      }
    } catch (e) {
      console.error("AI assessment failed", e);
    }

    if (!advice) {
      // Fallback determinístico
      if (rating === "risco") advice = `Cliente com ${overdueOpen} parcela(s) vencida(s) totalizando R$ ${overdueOpenAmount.toFixed(2)}. Recomendo negar até quitação.`;
      else if (rating === "excelente") advice = `Excelente pagador: ${paidOnTime}/${paidCount} parcelas em dia. Liberação segura.`;
      else if (rating === "bom") advice = `Bom histórico (${onTimeRate}% em dia). Liberação moderada recomendada.`;
      else advice = `Histórico regular. Avalie com cautela — atraso médio de ${avgDelay} dias.`;
    }

    return { stats, advice, suggestedExtra };
  });
