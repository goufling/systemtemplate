// Senha simples para liberar ações destrutivas (editar/excluir).
// NÃO É SEGURANÇA REAL — apenas uma trava de proteção no front-end.
const ADMIN_PASSWORD = "123456";

export function requireAdminPassword(action = "esta ação"): boolean {
  const input = window.prompt(`Digite a senha para ${action}:`);
  if (input === null) return false;
  if (input === ADMIN_PASSWORD) return true;
  window.alert("Senha incorreta.");
  return false;
}
