import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link } from "@tanstack/react-router";
import { Bell, AlertCircle, Calendar, Clock, CheckCheck, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { useAuthReady } from "@/hooks/use-auth-ready";
import { getPendingAlerts } from "@/lib/ai-assistant.functions";


const READ_KEY = "verapay:notifications:read";

const BRL = (n: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(n || 0);

function hashAlert(a: { title: string; message: string }) {
  return `${a.title}::${a.message}`;
}

function readSet(): Set<string> {
  try {
    const raw = localStorage.getItem(READ_KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function writeSet(s: Set<string>) {
  try {
    localStorage.setItem(READ_KEY, JSON.stringify(Array.from(s)));
  } catch {
    // ignore
  }
}

type Props = {
  variant?: "light" | "dark";
};

export function NotificationBell({ variant = "dark" }: Props) {
  const alertsFn = useServerFn(getPendingAlerts);
  const qc = useQueryClient();
  const { isReady: authReady, user } = useAuthReady();
  const [mounted, setMounted] = useState(false);
  const [read, setRead] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState(false);

  // Hydrate from localStorage only on the client, after mount
  useEffect(() => {
    setRead(readSet());
    setMounted(true);
  }, []);

  const { data } = useQuery({
    queryKey: ["pending-alerts-bell", user?.id],
    queryFn: () => alertsFn(),
    enabled: mounted && authReady && !!user,
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  // Realtime: instantly refresh on limit_request inserts/updates
  useEffect(() => {
    if (!mounted || !authReady || !user) return;
    const channelName = `notif-bell-limit-requests-${Math.random().toString(36).slice(2)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "limit_requests" },
        () => {
          qc.invalidateQueries({ queryKey: ["pending-alerts-bell"] });
          qc.invalidateQueries({ queryKey: ["limit-requests"] });
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [authReady, qc, mounted, user]);



  const alerts = data?.alerts || [];
  const unread = useMemo(
    () => alerts.filter((a) => !read.has(hashAlert(a))),
    [alerts, read]
  );
  const unreadCount = unread.length;

  useEffect(() => {
    // keep state in sync if multiple tabs
    const onStorage = (e: StorageEvent) => {
      if (e.key === READ_KEY) setRead(readSet());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const markAllRead = () => {
    const next = new Set(read);
    alerts.forEach((a) => next.add(hashAlert(a)));
    setRead(next);
    writeSet(next);
  };

  const markRead = (a: { title: string; message: string }) => {
    const next = new Set(read);
    next.add(hashAlert(a));
    setRead(next);
    writeSet(next);
  };

  const isLight = variant === "light";
  const bellBtn = isLight
    ? "text-[#7D2958] hover:bg-[#F5EBEF]"
    : "text-white hover:bg-white/10";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Notificações"
          className={`relative rounded-xl h-10 w-10 transition-colors ${bellBtn}`}
        >
          <Bell size={20} />
          <AnimatePresence>
            {unreadCount > 0 && (
              <motion.span
                key="badge"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center ring-2 ring-white shadow-lg"
              >
                {unreadCount > 9 ? "9+" : unreadCount}
              </motion.span>
            )}
          </AnimatePresence>
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-rose-500/60 animate-ping" />
          )}
        </Button>
      </PopoverTrigger>

      <PopoverContent
        align="end"
        sideOffset={12}
        className="w-[360px] p-0 rounded-3xl border border-[#F0D9E2] shadow-2xl overflow-hidden bg-white"
      >
        {/* Header */}
        <div className="relative p-5 bg-gradient-to-br from-[#7D2958] via-[#C84D8A] to-[#E879A8] text-white overflow-hidden">
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-white/15 backdrop-blur-sm">
                <Sparkles size={18} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-black tracking-tight">Central de Avisos</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/80">
                  {unreadCount > 0 ? `${unreadCount} não lido${unreadCount > 1 ? "s" : ""}` : "Tudo em dia"}
                </p>
              </div>
            </div>
            {alerts.length > 0 && unreadCount > 0 && (
              <button
                onClick={markAllRead}
                className="text-[10px] font-bold uppercase tracking-wider bg-white/15 hover:bg-white/25 transition-colors px-2.5 py-1.5 rounded-full flex items-center gap-1"
              >
                <CheckCheck size={12} /> Marcar lidos
              </button>
            )}
          </div>
        </div>

        {/* Summary chips */}
        {data?.summary && (
          <div className="grid grid-cols-3 gap-2 p-3 bg-[#FFF7FA] border-b border-[#F0D9E2]">
            <SummaryChip
              icon={<AlertCircle size={12} />}
              label="Atraso"
              value={data.summary.overdueCount}
              color="rose"
            />
            <SummaryChip
              icon={<Calendar size={12} />}
              label="Hoje"
              value={data.summary.dueTodayCount}
              color="amber"
            />
            <SummaryChip
              icon={<Clock size={12} />}
              label="7 dias"
              value={data.summary.dueSoonCount}
              color="sky"
            />
          </div>
        )}

        {/* List */}
        <ScrollArea className="max-h-[360px]">
          {alerts.length === 0 ? (
            <div className="p-8 text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mb-3">
                <CheckCheck className="text-emerald-500" size={22} />
              </div>
              <p className="text-sm font-bold text-[#2A2A2A]">Sem pendências críticas</p>
              <p className="text-xs text-[#6B6B6B] mt-1">A VERA te avisa quando algo precisar de atenção.</p>
            </div>
          ) : (
            <div className="divide-y divide-[#F5EBEF]">
              {alerts.map((a, i) => {
                const id = hashAlert(a);
                const isUnread = !read.has(id);
                const palette =
                  a.severity === "high"
                    ? { dot: "bg-rose-500", text: "text-rose-700", bg: "bg-rose-50/70" }
                    : a.severity === "medium"
                    ? { dot: "bg-amber-500", text: "text-amber-700", bg: "bg-amber-50/70" }
                    : { dot: "bg-sky-500", text: "text-sky-700", bg: "bg-sky-50/70" };
                return (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    onClick={() => markRead(a)}
                    className={`w-full text-left p-4 hover:bg-[#FFF7FA] transition-colors relative ${isUnread ? palette.bg : ""}`}
                  >
                    <div className="flex items-start gap-3">
                      <span className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${isUnread ? palette.dot : "bg-[#E5D5DC]"}`} />
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-bold ${isUnread ? "text-[#2A2A2A]" : "text-[#6B6B6B]"}`}>
                          {a.title}
                        </p>
                        <p className="text-xs text-[#6B6B6B] mt-1 leading-relaxed">{a.message}</p>
                        {a.amount ? (
                          <p className={`text-[11px] font-black mt-1.5 ${palette.text}`}>{BRL(a.amount)}</p>
                        ) : null}
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        <div className="p-3 border-t border-[#F0D9E2] bg-[#FFF7FA]">
          <Link
            to="/parcelas"
            onClick={() => setOpen(false)}
            className="block text-center text-xs font-black uppercase tracking-widest text-[#C84D8A] hover:text-[#7D2958] py-2 rounded-xl hover:bg-[#F5EBEF] transition-colors"
          >
            Ver todas as parcelas →
          </Link>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function SummaryChip({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: "rose" | "amber" | "sky";
}) {
  const map = {
    rose: "bg-rose-100 text-rose-700",
    amber: "bg-amber-100 text-amber-700",
    sky: "bg-sky-100 text-sky-700",
  };
  return (
    <div className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-white border border-[#F0D9E2]">
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest ${map[color]}`}>
        {icon} {label}
      </span>
      <span className="text-lg font-black text-[#2A2A2A] leading-none">{value}</span>
    </div>
  );
}
