import { useEffect, useState } from 'react';
import { registerSW } from 'virtual:pwa-register';
import { toast } from 'sonner';
import { Download } from 'lucide-react';

export function PWAManager() {
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    // Only run in the browser
    if (typeof window === 'undefined') return;

    console.log('PWA: Initializing PWAManager');

    const updateSW = registerSW({
      onNeedRefresh() {
        console.log('PWA: New content available');
        toast.info('Nova versão disponível!', {
          description: 'Deseja atualizar para a versão mais recente?',
          action: {
            label: 'Atualizar',
            onClick: () => {
              updateSW(true);
            },
          },
        });
      },
      onOfflineReady() {
        console.log('PWA: App ready for offline use');
        toast.success('App pronto para uso offline!');
      },
      onRegisterError(error) {
        console.error('PWA: Service Worker registration error:', error);
      },
      onRegistered(registration) {
        console.log('PWA: Service Worker registered:', registration);
      }
    });

    const handler = (e: any) => {
      console.log('PWA: received beforeinstallprompt event');
      e.preventDefault();
      setInstallPrompt(e);
      
      toast.info('Instale o VeraPay!', {
        description: 'Clique para instalar o app no seu dispositivo.',
        duration: 10000,
        action: {
          label: 'Instalar',
          onClick: () => {
            e.prompt();
            e.userChoice.then((choiceResult: any) => {
              if (choiceResult.outcome === 'accepted') {
                console.log('PWA: User accepted the install prompt');
              }
              setInstallPrompt(null);
            });
          },
        },
      });
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  if (!installPrompt) return null;

  return (
    <button
      onClick={() => {
        installPrompt.prompt();
        installPrompt.userChoice.then(() => setInstallPrompt(null));
      }}
      className="fixed bottom-20 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-2xl transition-all hover:scale-110 active:scale-95 md:bottom-8"
      title="Instalar Aplicativo"
    >
      <Download className="h-7 w-7" />
    </button>
  );
}
