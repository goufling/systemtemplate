import { Link, useNavigate, useLocation } from "@tanstack/react-router";
import { 
  LayoutDashboard, 
  Users, 
  Receipt, 
  CreditCard, 
  Landmark, 
  LogOut, 
  History,
  Menu,
  X,
  ChevronRight,
  ShieldCheck,
  Wallet,
  Briefcase,
  Store

} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "./ui/button";
import { NotificationBell } from "./NotificationBell";
import { toast } from "sonner";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuthReady } from "@/hooks/use-auth-ready";

export function Navigation() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthReady();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const items = [
    { to: "/", icon: LayoutDashboard, label: "Painel" },
    { to: "/clientes", icon: Users, label: "Clientes" },
    { to: "/emprestimos", icon: CreditCard, label: "Nota Promissória" },
    { to: "/parcelas", icon: Receipt, label: "Histórico" },
    { to: "/lojas", icon: Store, label: "Lojas" },
    { to: "/limites", icon: ShieldCheck, label: "Limites" },
    { to: "/fechamento", icon: Store, label: "Fechamento" },
    { to: "/financeiro-pessoal", icon: Wallet, label: "Pessoal" },
    { to: "/financeiro-profissional", icon: Briefcase, label: "Profissional" },
    { to: "/historico", icon: History, label: "Histórico" },
    { to: "/relatorios", icon: Landmark, label: "Relatórios" },
    { to: "/autorizacoes", icon: ShieldCheck, label: "Autorizações" },
  ];

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success("Sessão encerrada");
    navigate({ to: "/login" as any });
  };

  const isActive = (path: string) => {
    if (path === "/" && location.pathname === "/") return true;
    if (path !== "/" && location.pathname.startsWith(path)) return true;
    return false;
  };

  // Hide nav on public/auth + client-portal routes — clients have a separate UI.
  // IMPORTANT: match "/cliente" exact or "/cliente/..." so that "/clientes"
  // (the admin Clientes page) is NOT hidden.
  const p = location.pathname;
  const isClientArea = p === "/cliente" || p.startsWith("/cliente/");
  const isAuthArea = p === "/login" || p === "/signup" || p.startsWith("/auth");
  if (isClientArea || isAuthArea) {
    return null;
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="fixed left-0 top-0 hidden h-screen w-[280px] flex-col bg-[#7D2958] lg:flex z-50">
        <div className="flex h-24 items-center gap-4 px-8">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white shadow-lg">
            <Landmark className="text-[#7D2958]" size={24} />
          </div>
          <div className="flex flex-col flex-1 min-w-0">
            <span className="text-xl font-black tracking-tight text-white leading-none uppercase">VeraPay</span>
            <span className="text-[10px] font-bold text-[#F5EBEF] uppercase tracking-widest mt-1 flex items-center gap-1">
              <ShieldCheck size={10} /> PREMIUM
            </span>
          </div>
          <NotificationBell variant="dark" />
        </div>

        <nav className="flex-1 min-h-0 overflow-y-auto space-y-1.5 px-4 py-6 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
          {items.map((item) => (
            <Link
              key={item.to}
              to={item.to as any}
              className={`sidebar-item ${
                isActive(item.to) 
                  ? "sidebar-item-active" 
                  : "sidebar-item-inactive"
              }`}
            >
              <item.icon size={20} />
              {item.label}
              {isActive(item.to) && (
                <motion.div 
                  layoutId="active-indicator"
                  className="ml-auto h-1.5 w-1.5 rounded-full bg-white"
                />
              )}
            </Link>
          ))}
        </nav>

        <div className="p-3 border-t border-white/10">
          <div className="mb-2 px-2">
            <div className="text-[9px] font-bold text-white/60 uppercase tracking-[0.2em]">Administrador</div>
            <div className="text-xs font-semibold text-white truncate">{user?.email ?? "Carregando..."}</div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-2 rounded-lg text-white/80 hover:bg-white/10 hover:text-white transition-colors h-9 px-2"
            onClick={handleLogout}
          >
            <LogOut size={16} />
            <span className="text-sm font-semibold">Encerrar Sessão</span>
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-[#7D2958] lg:hidden z-50 flex items-center justify-between px-4 py-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white shadow-lg">
            <Landmark className="text-[#7D2958]" size={20} />
          </div>
          <span className="text-lg font-black tracking-tight text-white uppercase">VeraPay</span>
        </div>
        <div className="flex items-center gap-1">
          <NotificationBell variant="dark" />
          <Button variant="ghost" size="icon" className="rounded-xl text-white hover:bg-white/10" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="fixed inset-0 top-16 bg-[#7D2958] z-40 lg:hidden p-6 overflow-y-auto"
          >
            <div className="flex flex-col gap-3">
              {items.map((item) => (
                <Link
                  key={item.to}
                  to={item.to as any}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`flex items-center justify-between rounded-2xl px-5 py-5 text-lg font-bold ${
                    isActive(item.to) ? "bg-primary text-white shadow-xl shadow-primary/20" : "bg-slate-50 text-[#6B6B6B]"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <item.icon size={22} />
                    {item.label}
                  </div>
                  <ChevronRight size={20} className={isActive(item.to) ? "text-white/50" : "text-[#2A2A2A]"} />
                </Link>
              ))}
              <Button 
                variant="destructive" 
                className="mt-6 h-16 rounded-2xl text-lg font-bold shadow-xl shadow-red-200"
                onClick={handleLogout}
              >
                Sair do Sistema
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Spacing for mobile layout */}
      <div className="h-16 lg:hidden" />
      {/* Spacing for sidebar desktop */}
      <div className="hidden lg:block lg:w-[280px] shrink-0" />
    </>
  );
}
