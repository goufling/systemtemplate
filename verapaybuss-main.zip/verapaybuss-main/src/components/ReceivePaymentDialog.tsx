import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createPaymentRecord } from "@/serverFunctions";
import { supabase } from "@/integrations/supabase/client";
import { PaymentMethod } from "@/types/finance";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  CheckCircle2,
  Loader2,
  CreditCard,
  Landmark,
  Zap,
  Banknote,
  FileText,
  PlusCircle,
} from "lucide-react";
import { toast } from "sonner";

interface ReceivePaymentDialogProps {
  installment: any;
  remaining: number;
  customerName?: string;
  triggerClassName?: string;
  triggerLabel?: string;
}

export function ReceivePaymentDialog({
  installment,
  remaining,
  customerName,
  triggerClassName,
  triggerLabel = "Receber",
}: ReceivePaymentDialogProps) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
  const [amount, setAmount] = useState<number>(remaining);
  const [cardFee, setCardFee] = useState<number>(0);
  const [chequeNumber, setChequeNumber] = useState("");
  const [chequeBank, setChequeBank] = useState("");
  const [chequeDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [paidAt, setPaidAt] = useState<string>(new Date().toISOString().split("T")[0]);
  const [proofUrl, setProofUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetForm = () => {
    setPaymentMethod(null);
    setAmount(remaining);
    setCardFee(0);
    setChequeNumber("");
    setChequeBank("");
    setProofUrl("");
    setPaidAt(new Date().toISOString().split("T")[0]);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setUploading(true);
      const fileExt = file.name.split(".").pop();
      const fileName = `${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `payments/${fileName}`;
      const { error: uploadError } = await supabase.storage
        .from("loan-attachments")
        .upload(filePath, file);
      if (uploadError) throw uploadError;
      const { data: { publicUrl } } = supabase.storage
        .from("loan-attachments")
        .getPublicUrl(filePath);
      setProofUrl(publicUrl);
      toast.success("Comprovante anexado!");
    } catch (error: any) {
      toast.error("Erro ao fazer upload: " + error.message);
    } finally {
      setUploading(false);
    }
  };

  const payMutation = useMutation({
    mutationFn: (vars: any) => createPaymentRecord({ data: vars }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pagamentos-data"] });
      queryClient.invalidateQueries({ queryKey: ["dashboardSummary"] });
      queryClient.invalidateQueries({ queryKey: ["customer-detail"] });
      toast.success("Pagamento registrado!");
      resetForm();
      setOpen(false);
    },
    onError: (e: any) => toast.error(e.message),
  });

  const handlePay = () => {
    if (!installment || !paymentMethod || amount <= 0) return;
    payMutation.mutate({
      installmentId: installment.id,
      amount,
      paymentMethod,
      cardFee: paymentMethod === "card" ? cardFee : undefined,
      chequeNumber: paymentMethod === "cheque" ? chequeNumber : undefined,
      chequeBank: paymentMethod === "cheque" ? chequeBank : undefined,
      chequeDate: paymentMethod === "cheque" ? chequeDate : undefined,
      proofUrl,
      paidAt: paidAt ? new Date(paidAt).toISOString() : undefined,
      createNextInstallment: true,
      nextDueDate: new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
    });
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) resetForm();
      }}
    >
      <Button
        size="sm"
        className={
          triggerClassName ||
          "bg-[#C84D8A] text-[#7D2958] hover:bg-[#C84D8A]/90 font-black uppercase text-[9px] tracking-widest h-8 px-4 rounded-lg"
        }
        onClick={(e) => {
          e.stopPropagation();
          setAmount(remaining);
          setOpen(true);
        }}
      >
        {triggerLabel}
      </Button>

      <DialogContent className="sm:max-w-[480px] max-h-[90vh] overflow-y-auto bg-[#FFFFFF] border-[#EAEAEA] text-[#2A2A2A] rounded-[40px] p-6 sm:p-8 shadow-4xl">
        <DialogHeader>
          <DialogTitle className="text-3xl font-black text-[#C84D8A] uppercase tracking-tighter">
            Registrar Pagamento
          </DialogTitle>
          <p className="text-[#6B6B6B] font-medium italic">
            Confirmando recebimento de {customerName || installment?.customer?.name}
          </p>
        </DialogHeader>

        <div className="grid gap-8 py-6">
          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">
              Valor do Recebimento
            </Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 font-black text-2xl text-[#C84D8A]">
                R$
              </span>
              <Input
                type="number"
                className="pl-14 h-16 text-3xl font-black text-[#2A2A2A] border-[#EAEAEA] bg-[#F5EBEF] rounded-2xl shadow-inner"
                value={amount || ""}
                onChange={(e) => setAmount(Number(e.target.value))}
              />
            </div>
          </div>

          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">
              Data do Pagamento
            </Label>
            <Input
              type="date"
              className="h-12 text-base font-bold text-[#2A2A2A] border-[#EAEAEA] bg-[#F5EBEF] rounded-2xl"
              value={paidAt}
              onChange={(e) => setPaidAt(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">
              Método de Pagamento
            </Label>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { id: "pix", label: "PIX", icon: Zap, color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20" },
                { id: "cash", label: "Dinheiro", icon: Banknote, color: "text-emerald-400 bg-emerald-400/10 border-emerald-400/20" },
                { id: "card", label: "Cartão", icon: CreditCard, color: "text-purple-400 bg-purple-400/10 border-purple-400/20" },
                { id: "cheque", label: "Cheque", icon: Landmark, color: "text-orange-400 bg-orange-400/10 border-orange-400/20" },
                { id: "nota_promissoria", label: "Promissória", icon: FileText, color: "text-rose-400 bg-rose-400/10 border-rose-400/20" },
              ].map((method) => (
                <Button
                  key={method.id}
                  variant="outline"
                  className={`h-24 flex flex-col items-center justify-center gap-3 border-2 transition-all rounded-2xl ${
                    paymentMethod === method.id
                      ? `${method.color} border-current ring-4 ring-current/10`
                      : "border-[#EAEAEA] bg-[#F5EBEF] hover:bg-[#F5EBEF]/80"
                  }`}
                  onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                >
                  <method.icon size={28} />
                  <span className="text-[11px] font-black uppercase tracking-widest">
                    {method.label}
                  </span>
                </Button>
              ))}
            </div>
          </div>

          {paymentMethod === "card" && (
            <div className="space-y-2 p-5 bg-purple-500/5 rounded-2xl border border-purple-500/20">
              <Label className="text-[10px] font-black text-purple-400 uppercase">
                Taxa / Acréscimo
              </Label>
              <Input
                type="number"
                className="h-12 border-purple-500/20 bg-[#F5EBEF] font-bold text-[#2A2A2A] rounded-xl"
                placeholder="R$ 0,00"
                value={cardFee || ""}
                onChange={(e) => setCardFee(Number(e.target.value))}
              />
            </div>
          )}

          {paymentMethod === "cheque" && (
            <div className="space-y-4 p-5 bg-orange-500/5 rounded-2xl border border-orange-500/20">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black text-orange-400 uppercase">
                    Nº Cheque
                  </Label>
                  <Input
                    className="h-10 border-orange-500/30 bg-white text-[#2A2A2A] rounded-xl"
                    value={chequeNumber}
                    onChange={(e) => setChequeNumber(e.target.value)}
                    placeholder="000000"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black text-orange-400 uppercase">
                    Banco
                  </Label>
                  <Input
                    className="h-10 border-orange-500/30 bg-white text-[#2A2A2A] rounded-xl"
                    value={chequeBank}
                    onChange={(e) => setChequeBank(e.target.value)}
                    placeholder="Ex: Itaú"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="space-y-3">
            <Label className="text-[10px] font-black uppercase tracking-[0.2em] text-[#C84D8A]">
              Comprovante (Opcional)
            </Label>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleFileUpload}
            />
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`flex items-center justify-center w-full h-20 border-2 border-dashed rounded-2xl transition-colors cursor-pointer group ${
                proofUrl
                  ? "border-green-500/50 bg-green-500/5"
                  : "border-[#EAEAEA] bg-[#F5EBEF] hover:border-[#C84D8A]/30"
              }`}
            >
              <div className="text-center">
                {uploading ? (
                  <Loader2 size={24} className="mx-auto text-[#C84D8A] animate-spin" />
                ) : proofUrl ? (
                  <div className="flex items-center gap-2 text-green-500">
                    <CheckCircle2 size={20} />
                    <span className="text-xs font-bold uppercase">Foto Anexada!</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-[#6B6B6B] group-hover:text-[#C84D8A]">
                    <PlusCircle size={20} />
                    <span className="text-xs font-bold uppercase">Anexar Foto</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button
            className="w-full h-16 text-lg font-black shadow-2xl btn-primary uppercase tracking-[0.2em] text-[#7D2958] rounded-2xl transition-all hover:scale-[1.02] active:scale-[0.98]"
            onClick={handlePay}
            disabled={!paymentMethod || amount <= 0 || payMutation.isPending}
          >
            {payMutation.isPending ? (
              <Loader2 className="animate-spin mr-2" />
            ) : (
              <CheckCircle2 className="mr-2" />
            )}
            Confirmar Recebimento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
