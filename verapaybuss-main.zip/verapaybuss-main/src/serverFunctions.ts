import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const requireAdminRole = async (userId: string) => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();

  if (error || !data) throw new Error("Apenas administradores podem executar esta ação.");
  return supabaseAdmin;
};

// Fetch Full Payment History with Filters
export const getFullPaymentHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data, error } = await supabase
      .from("payment_records")
      .select(`
        *,
        installments (
          number,
          loans (
            store_name,
            customers (name)
          )
        )
      `)
      .eq("user_id", userId)
      .order("paid_at", { ascending: false });

    if (error) throw new Error("Erro ao buscar histórico");

    return (data || []).map((r: any) => ({
      id: r.id,
      amount: Number(r.amount),
      paidAt: r.paid_at,
      paymentMethod: r.payment_method,
      customerName: r.installments?.loans?.customers?.name,
      storeName: r.installments?.loans?.store_name,
      installmentNumber: r.installments?.number,
      proofUrl: r.proof_url,
      chequeDetails: r.payment_method === 'cheque' ? {
        bank: r.cheque_bank,
        number: r.cheque_number,
        date: r.cheque_date
      } : null
    }));
  });

// Create Customer
export const createCustomer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const {
      name, phone, secondary_phone, credit_limit, status, cpf,
      cep, address_street, address_number, address_complement,
      address_neighborhood, address_city, address_state
    } = data;

    const cleanedCpf = cpf ? String(cpf).replace(/\D/g, "") : null;

    const { data: customer, error } = await supabase
      .from("customers")
      .insert({
        user_id: userId,
        name,
        phone,
        secondary_phone,
        credit_limit,
        status,
        cpf: cleanedCpf,
        cep,
        address_street,
        address_number,
        address_complement,
        address_neighborhood,
        address_city,
        address_state,
      })
      .select()
      .single();

    if (error) {
      if ((error as any).code === "23505") throw new Error("Já existe um cliente com este CPF.");
      throw new Error("Erro ao criar cliente");
    }

    return customer;
  });

// Update Customer
export const updateCustomer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const {
      id, name, phone, secondary_phone, credit_limit, status, is_favorite, cpf,
      cep, address_street, address_number, address_complement,
      address_neighborhood, address_city, address_state
    } = data;

    const cleanedCpf = cpf === undefined ? undefined : (cpf ? String(cpf).replace(/\D/g, "") : null);

    const updatePayload: any = {
      name, phone, secondary_phone, credit_limit, status, is_favorite,
      cep, address_street, address_number, address_complement,
      address_neighborhood, address_city, address_state,
    };
    if (cleanedCpf !== undefined) updatePayload.cpf = cleanedCpf;

    const { data: customer, error } = await supabase
      .from("customers")
      .update(updatePayload)
      .eq("id", id)
      .eq("user_id", userId)
      .select()
      .single();

    if (error) {
      if ((error as any).code === "23505") throw new Error("Já existe um cliente com este CPF.");
      throw new Error("Erro ao atualizar cliente");
    }

    return customer;
  });

// Delete Customer
export const deleteCustomer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("customers")
      .delete()
      .eq("id", data.id)
      .eq("user_id", userId);

    if (error) throw new Error("Erro ao excluir cliente");

    return { success: true };
  });

// Fetch Dashboard Summary
export const getDashboardSummary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data: installments, error: instError } = await supabase
      .from("installments")
      .select("amount, status, due_date")
      .eq("user_id", userId);

    const { data: loans, error: loansError } = await supabase
      .from("loans")
      .select("total_amount, capital_source, status")
      .eq("user_id", userId);

    const { count: customersCount, error: custError } = await supabase
      .from("customers")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId);

    if (instError || custError || loansError) {
      console.error("Dashboard error:", instError || custError || loansError);
      throw new Error("Erro ao buscar dados do dashboard");
    }


    const todayStr = new Date().toISOString().split('T')[0];
    
    const totalPending = installments
      ?.filter((i: any) => i.status === "pending" || i.status === "overdue")
      .reduce((acc: number, curr: any) => acc + Number(curr.amount), 0) || 0;

    const totalToPay = loans
      ?.filter((l: any) => l.capital_source === "terceiro" && l.status === "active")
      .reduce((acc: number, curr: any) => acc + Number(curr.total_amount), 0) || 0;

    const overdueCount = installments?.filter((i: any) => i.status === "overdue").length || 0;
    const todayPayments = installments?.filter((i: any) => i.due_date === todayStr).length || 0;

    return {
      totalPending,
      totalToPay,
      overdueCount,
      todayPayments,
      customersCount: customersCount || 0,
    };
  });

// Fetch Recent Payments
export const getRecentPayments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data, error } = await supabase
      .from("installments")
      .select(`
        id, amount, number, payment_method, paid_at,
        customers (name)
      `)
      .eq("user_id", userId)
      .eq("status", "paid")
      .order("paid_at", { ascending: false })
      .limit(5);

    if (error) throw new Error("Erro ao buscar pagamentos recentes");

    return (data || []).map((i: any) => ({
      id: i.id,
      amount: Number(i.amount),
      number: i.number,
      paymentMethod: i.payment_method,
      customerName: (i.customers as any)?.name,
    }));
  });

// Fetch Customers
export const getCustomers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data, error } = await supabase
      .from("customers")
      .select(`
        *,
        loans (id, total_amount, status)
      `)
      .eq("user_id", userId)
      .order("name");

    if (error) throw new Error("Erro ao buscar clientes");

    return (data || []).map((c: any) => ({
      ...c,
      activeLoans: (c.loans as any[] || []).filter((l: any) => l.status === "active").length,
      totalBorrowed: (c.loans as any[] || []).reduce((acc: number, curr: any) => acc + Number(curr.total_amount), 0),
    }));
  });

// Create Loan with Installments
export const createLoan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { 
      customerId, 
      storeName, 
      totalAmount, 
      loanDate, 
      installmentsCount,
      orderNumber,
      capitalSource,
      profitMarginPercent,
      notes,
      attachmentUrl,
      firstDueDate
    } = data;

    // Auto-shift loan_date to day 01 of next month if this store is already closed for that month
    let effectiveLoanDate = loanDate as string;
    for (let guard = 0; guard < 24; guard++) {
      const [yy, mm] = effectiveLoanDate.split("-").map(Number);
      const { data: closedRow } = await supabase
        .from("store_month_closings")
        .select("id")
        .eq("user_id", userId)
        .eq("store_name", storeName)
        .eq("year", yy)
        .eq("month", mm)
        .maybeSingle();
      if (!closedRow) break;
      const next = new Date(Date.UTC(yy, mm, 1)); // first day of next month
      effectiveLoanDate = `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-01`;
    }

    const { data: loan, error: loanError } = await supabase
      .from("loans")
      .insert({
        user_id: userId,
        customer_id: customerId,
        store_name: storeName,
        total_amount: totalAmount,
        loan_date: effectiveLoanDate,
        installments_count: installmentsCount,
        order_number: orderNumber,
        capital_source: capitalSource,
        profit_margin_percent: profitMarginPercent,
        notes: notes,
        attachment_url: attachmentUrl,
        legal_terms_accepted: true
      })

      .select()
      .single();

    if (loanError) throw new Error("Erro ao criar empréstimo");

    // Round to cents and distribute remainder so installments sum exactly to totalAmount
    const totalCents = Math.round(totalAmount * 100);
    const baseCents = Math.floor(totalCents / installmentsCount);
    const remainderCents = totalCents - baseCents * installmentsCount;
    // Parse anchor as local date components (avoid UTC timezone shift)
    const parseLocal = (s: string) => {
      const [y, m, d] = s.split("-").map(Number);
      return { y, m: m - 1, d };
    };
    const anchor = parseLocal(effectiveLoanDate);
    const anchorY = anchor.y;
    const anchorM = anchor.m + 2;
    const anchorD = 10;
    const installments = Array.from({ length: installmentsCount }).map((_, i) => {
      const dt = new Date(anchorY, anchorM + i, anchorD);
      const dueDate = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
      // Add 1 extra cent to the first `remainderCents` installments so total matches exactly
      const cents = baseCents + (i < remainderCents ? 1 : 0);
      return {
        user_id: userId,
        loan_id: loan.id,
        customer_id: customerId,
        number: i + 1,
        amount: cents / 100,
        due_date: dueDate,
        status: "pending",
      };
    });

    const { error: instError } = await supabase
      .from("installments")
      .insert(installments as any);

    if (instError) throw new Error("Erro ao criar parcelas");

    return loan;
  });

// Update Installment Status
export const updateInstallmentStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { installmentId, status, paymentMethod, cardFee, chequeDate } = data;

    const updateData: any = { status };
    if (status === "paid") {
      updateData.payment_method = paymentMethod;
      updateData.paid_at = new Date().toISOString();
      if (paymentMethod === 'card') updateData.card_fee = cardFee;
      if (paymentMethod === 'cheque') updateData.cheque_date = chequeDate;
    }

    const { data: inst, error } = await supabase
      .from("installments")
      .update(updateData)
      .eq("id", installmentId)
      .eq("user_id", userId)
      .select()
      .single();

    if (error) throw new Error("Erro ao atualizar parcela");

    return inst;
  });

export const createPaymentRecord = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { 
      installmentId, 
      amount, 
      paymentMethod, 
      cardFee, 
      chequeNumber, 
      chequeBank, 
      chequeDate,
      proofUrl,
      paidAt,
      createNextInstallment = true,
      nextDueDate
    } = data;

    // 1. Get current installment state
    const { data: inst, error: fetchError } = await supabase
      .from("installments")
      .select("*, payment_records(amount)")
      .eq("id", installmentId)
      .single();

    if (fetchError) throw new Error("Erro ao buscar parcela");

    const totalPaidBefore = inst.payment_records?.reduce((acc: number, r: any) => acc + Number(r.amount), 0) || 0;
    const remainingBefore = Number(inst.amount) - totalPaidBefore;

    // 2. Register the payment
    const insertPayload: any = {
      installment_id: installmentId,
      amount,
      payment_method: paymentMethod,
      card_fee: cardFee || 0,
      cheque_number: chequeNumber,
      cheque_bank: chequeBank,
      cheque_date: chequeDate,
      proof_url: proofUrl,
      user_id: userId,
    };
    if (paidAt) insertPayload.paid_at = paidAt;

    const { data: record, error: recordError } = await supabase
      .from("payment_records")
      .insert(insertPayload)
      .select()
      .single();

    if (recordError) { console.error("payment_records insert error:", recordError); throw new Error("Erro ao registrar pagamento: " + recordError.message); }

    // 3. Handle Partial Payment & Auto-Renegotiation
    const totalPaidAfter = totalPaidBefore + Number(amount);
    
    if (totalPaidAfter >= Number(inst.amount)) {
      // Fully paid
      await supabase
        .from("installments")
        .update({ 
          status: "paid", 
          paid_at: new Date().toISOString(),
          payment_method: paymentMethod
        })
        .eq("id", installmentId);
    } else if (createNextInstallment) {
      // Partial payment - Create renegotiation and new installment
      const balance = Number(inst.amount) - totalPaidAfter;
      
      // Calculate suggested interest for the delay if applicable (example 1% simple interest)
      const isOverdue = new Date(inst.due_date) < new Date();
      const suggestedBalance = isOverdue ? balance * 1.01 : balance;

      // Register renegotiation
      const { data: reneg, error: renegError } = await supabase
        .from("renegotiations")
        .insert({
          user_id: userId,
          installment_id: installmentId,
          original_amount: inst.amount,
          paid_amount: totalPaidAfter,
          remaining_amount: balance,
          reason: "Pagamento parcial com renegociação automática"
        })
        .select()
        .single();

      if (!renegError) {
        // Create new installment for the balance
        const { data: newInst, error: newInstError } = await supabase
          .from("installments")
          .insert({
            user_id: userId,
            loan_id: inst.loan_id,
            customer_id: inst.customer_id,
            number: inst.number, // Keep same number but maybe add a suffix or just keep it
            amount: balance,
            due_date: nextDueDate || new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            status: "pending",
            notes: `Saldo remanescente da parcela ${inst.number}`,
            renegotiation_id: reneg.id
          })
          .select()
          .single();

        if (!newInstError) {
          // Mark original installment as paid (because it was renegotiated)
          await supabase
            .from("installments")
            .update({ 
              status: "paid", 
              notes: (inst.notes || "") + " [Renegociada - Saldo transferido]"
            })
            .eq("id", installmentId);
          
          // Link back
          await supabase
            .from("renegotiations")
            .update({ new_installment_id: newInst.id })
            .eq("id", reneg.id);
        }
      }
    }

    return record;
  });

export const getInstallmentPayments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { installmentId } = data;

    const { data: records, error } = await supabase
      .from("payment_records")
      .select("*")
      .eq("installment_id", installmentId)
      .eq("user_id", userId)
      .order("paid_at", { ascending: false });

    if (error) throw new Error("Erro ao buscar histórico de pagamentos");

    return records || [];
  });

export const getCustomerDetails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const customerId = data?.customerId;
    if (!customerId) throw new Error("ID do cliente não informado");

    const { data: customer, error: custError } = await supabase
      .from("customers")
      .select("*")
      .eq("id", customerId)
      .eq("user_id", userId)
      .maybeSingle();

    if (custError) throw new Error("Erro ao buscar dados do cliente: " + custError.message);
    if (!customer) throw new Error("Cliente não encontrado");

    const { data: loans, error: loansError } = await supabase
      .from("loans")
      .select(`
        *,
        notes,
        installments (*)
      `)
      .eq("customer_id", customerId)
      .eq("user_id", userId)
      .order("loan_date", { ascending: false });

    if (loansError) throw new Error("Erro ao buscar histórico do cliente: " + loansError.message);

    return {
      ...customer,
      loans: loans || []
    };
  });

export const getActivityLogs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data, error } = await supabase
      .from("activity_logs")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) throw new Error("Erro ao buscar logs de atividade");

    return data || [];
  });

export const getPagamentosData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    // Fetch installments with customer and loan data in a single join
    const { data, error } = await supabase
      .from("installments")
      .select(`
        *,
        customer:customers (id, name, phone),
        loan:loans (id, store_name, installments_count, order_number, notes),
        payment_records (*)
      `)
      .eq("user_id", userId)
      .order("due_date", { ascending: true });

    if (error) {
      console.error("Error fetching pagamentos:", error);
      throw new Error("Erro ao buscar dados de pagamentos");
    }

    return data || [];
  });

export const updatePaymentRecord = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { id, amount, paidAt, paymentMethod, cardFee, chequeNumber, chequeBank, chequeDate } = data;

    const update: any = {};
    if (amount !== undefined) update.amount = amount;
    if (paidAt !== undefined) update.paid_at = paidAt;
    if (paymentMethod !== undefined) update.payment_method = paymentMethod;
    if (cardFee !== undefined) update.card_fee = cardFee;
    if (chequeNumber !== undefined) update.cheque_number = chequeNumber;
    if (chequeBank !== undefined) update.cheque_bank = chequeBank;
    if (chequeDate !== undefined) update.cheque_date = chequeDate;

    const { data: rec, error } = await supabase
      .from("payment_records")
      .update(update)
      .eq("id", id)
      .eq("user_id", userId)
      .select()
      .single();
    if (error) throw new Error("Erro ao atualizar pagamento: " + error.message);

    // Recompute installment status
    if (rec?.installment_id) {
      const { data: inst } = await supabase.from("installments").select("amount").eq("id", rec.installment_id).single();
      const { data: allRecs } = await supabase.from("payment_records").select("amount").eq("installment_id", rec.installment_id);
      const totalPaid = (allRecs || []).reduce((s: number, r: any) => s + Number(r.amount), 0);
      const newStatus = inst && totalPaid >= Number(inst.amount) ? "paid" : "pending";
      await supabase.from("installments").update({ status: newStatus, paid_at: newStatus === "paid" ? (paidAt || new Date().toISOString()) : null }).eq("id", rec.installment_id);
    }
    return rec;
  });

export const deletePaymentRecord = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any, data: any }) => {
    const { supabase, userId } = context;
    const { id } = data;

    const { data: rec } = await supabase.from("payment_records").select("installment_id").eq("id", id).single();
    const { error } = await supabase.from("payment_records").delete().eq("id", id).eq("user_id", userId);
    if (error) throw new Error("Erro ao excluir pagamento: " + error.message);

    if (rec?.installment_id) {
      const { data: inst } = await supabase.from("installments").select("amount").eq("id", rec.installment_id).single();
      const { data: allRecs } = await supabase.from("payment_records").select("amount").eq("installment_id", rec.installment_id);
      const totalPaid = (allRecs || []).reduce((s: number, r: any) => s + Number(r.amount), 0);
      const newStatus = inst && totalPaid >= Number(inst.amount) ? "paid" : "pending";
      await supabase.from("installments").update({ status: newStatus, paid_at: newStatus === "paid" ? new Date().toISOString() : null }).eq("id", rec.installment_id);
    }
    return { success: true };
  });

// ============================================================
// CLIENT ACCESS (admin-only): create / reset / remove client login
// ============================================================

// Admin grants a client a login account (CPF + password).
// Creates the auth user via service role, links it to the customer row.
export const setClientAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const { customerId, password } = data as { customerId: string; password: string };

    if (!password || password.length < 6) {
      throw new Error("A senha precisa ter no mínimo 6 caracteres.");
    }

    const { data: customer, error: cErr } = await supabase
      .from("customers")
      .select("id, name, cpf, client_user_id")
      .eq("id", customerId)
      .eq("user_id", userId)
      .single();
    if (cErr || !customer) throw new Error("Cliente não encontrado.");
    if (!customer.cpf) throw new Error("Cadastre o CPF do cliente antes de criar o acesso.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = `cpf${String(customer.cpf).replace(/\D/g, "")}@clientes.verapay.app`;

    // If already linked, just reset the password.
    if (customer.client_user_id) {
      const { error: updErr } = await supabaseAdmin.auth.admin.updateUserById(
        customer.client_user_id,
        { password }
      );
      if (updErr) throw new Error("Erro ao atualizar a senha: " + updErr.message);
      return { success: true, reset: true };
    }

    // Try to create a brand-new auth user.
    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { account_type: "client", customer_id: customer.id, full_name: customer.name },
    });

    let clientUserId = created?.user?.id;
    if (createErr) {
      // If the email is taken (e.g. CPF reused after delete), look it up and reuse.
      const { data: list } = await supabaseAdmin.auth.admin.listUsers();
      const existing = list?.users?.find((u: any) => u.email === email);
      if (!existing) throw new Error("Erro ao criar acesso: " + createErr.message);
      clientUserId = existing.id;
      await supabaseAdmin.auth.admin.updateUserById(existing.id, { password });
    }

    if (!clientUserId) throw new Error("Não foi possível obter o ID do acesso do cliente.");

    // Ensure 'client' role
    await supabaseAdmin.from("user_roles").upsert(
      { user_id: clientUserId, role: "client" },
      { onConflict: "user_id,role" }
    );

    // Link the customer row to the new auth user
    const { error: linkErr } = await supabaseAdmin
      .from("customers")
      .update({ client_user_id: clientUserId })
      .eq("id", customer.id);
    if (linkErr) throw new Error("Erro ao vincular cliente ao acesso.");

    return { success: true, reset: false };
  });

// Admin revokes a client's login (deletes the auth user).
export const removeClientAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const { customerId } = data as { customerId: string };

    const { data: customer } = await supabase
      .from("customers")
      .select("client_user_id")
      .eq("id", customerId)
      .eq("user_id", userId)
      .single();
    if (!customer?.client_user_id) return { success: true };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.auth.admin.deleteUser(customer.client_user_id);
    // ON DELETE SET NULL on the FK already clears client_user_id.
    return { success: true };
  });

// ============================================================
// CLIENT PORTAL: data the logged-in client sees about themselves
// ============================================================
export const getMyClientPortal = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;

    const { data: customer, error: cErr } = await supabase
      .from("customers")
      .select("id, name, phone, cpf, credit_limit, status, avatar_url")
      .eq("client_user_id", userId)
      .maybeSingle();
    if (cErr) throw new Error("Erro ao carregar seus dados.");
    if (!customer) throw new Error("Nenhum cadastro de cliente vinculado a esta conta.");

    // Generate a short-lived signed URL for the private avatar, if any.
    let avatarSignedUrl: string | null = null;
    if (customer.avatar_url) {
      const { data: signed } = await supabase.storage
        .from("avatars")
        .createSignedUrl(customer.avatar_url, 60 * 60); // 1h
      avatarSignedUrl = signed?.signedUrl ?? null;
    }

    const { data: installments, error: instErr } = await supabase
      .from("installments")
      .select(`
        id, number, amount, due_date, status, paid_at, payment_method,
        loans ( id, store_name, total_amount, installments_count, loan_date, order_number )
      `)
      .eq("customer_id", customer.id)
      .order("due_date", { ascending: true });
    if (instErr) throw new Error("Erro ao carregar suas parcelas.");

    const list = installments || [];
    const pending = list.filter((i: any) => i.status !== "paid");
    const paid = list.filter((i: any) => i.status === "paid");

    const totalOwed = pending.reduce((s: number, i: any) => s + Number(i.amount), 0);
    const totalPaid = paid.reduce((s: number, i: any) => s + Number(i.amount), 0);
    const nextInstallment = pending[0] || null;

    return {
      customer: { ...customer, avatar_signed_url: avatarSignedUrl },
      summary: {
        totalOwed,
        totalPaid,
        pendingCount: pending.length,
        paidCount: paid.length,
        nextInstallment,
      },
      installments: list,
    };
  });

// Client updates own profile fields (name, phone).
// Avatar upload is done client-side directly to Storage (RLS scopes it to
// the user's own folder); this fn just persists the resulting path.
export const updateMyClientProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { name?: string; phone?: string; avatar_url?: string | null }) => input)
  .handler(async ({ data, context }: { data: any; context: any }) => {
    const { supabase, userId } = context;
    const patch: Record<string, any> = {};
    if (typeof data.name === "string" && data.name.trim().length >= 2) patch.name = data.name.trim();
    if (typeof data.phone === "string") patch.phone = data.phone.trim();
    if ("avatar_url" in data) patch.avatar_url = data.avatar_url;
    if (Object.keys(patch).length === 0) return { success: true };

    const { error } = await supabase
      .from("customers")
      .update(patch)
      .eq("client_user_id", userId);
    if (error) throw new Error("Não foi possível atualizar seu perfil.");
    return { success: true };
  });

// ============== STORES MANAGEMENT ==============

export const listStores = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("stores")
      .select("*")
      .eq("user_id", userId)
      .order("name", { ascending: true });
    if (error) throw new Error("Erro ao listar lojas: " + error.message);
    return data || [];
  });

export const createStore = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { name: string; commissionPercent?: number }) => d)
  .handler(async ({ context, data }: { context: any; data: { name: string; commissionPercent?: number } }) => {
    const { supabase, userId } = context;
    if (!data.name?.trim()) throw new Error("Nome da loja é obrigatório");
    const { data: row, error } = await supabase
      .from("stores")
      .insert({
        user_id: userId,
        name: data.name.trim(),
        commission_percent: Number(data.commissionPercent || 0),
      })
      .select()
      .single();
    if (error) throw new Error("Erro ao criar loja: " + error.message);
    return row;
  });

export const updateStore = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; name?: string; commissionPercent?: number }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const patch: any = {};
    if (data.name !== undefined) patch.name = String(data.name).trim();
    if (data.commissionPercent !== undefined) patch.commission_percent = Number(data.commissionPercent);
    const { data: row, error } = await supabase
      .from("stores")
      .update(patch)
      .eq("id", data.id)
      .eq("user_id", userId)
      .select()
      .single();
    if (error) throw new Error("Erro ao atualizar loja: " + error.message);
    return row;
  });

export const deleteStore = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ context, data }: { context: any; data: { id: string } }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("stores")
      .delete()
      .eq("id", data.id)
      .eq("user_id", userId);
    if (error) throw new Error("Erro ao remover loja: " + error.message);
    return { ok: true };
  });

export const getStoreReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeName: string }) => d)
  .handler(async ({ context, data }: { context: any; data: { storeName: string } }) => {
    const { supabase, userId } = context;

    // Pull store record (for commission_percent)
    const { data: storeRow } = await supabase
      .from("stores")
      .select("*")
      .eq("user_id", userId)
      .eq("name", data.storeName)
      .maybeSingle();

    // Loans of that store
    const { data: loans, error: loansErr } = await supabase
      .from("loans")
      .select("id, total_amount, loan_date, installments_count, status, customer:customers(id, name)")
      .eq("user_id", userId)
      .eq("store_name", data.storeName)
      .order("loan_date", { ascending: false });
    if (loansErr) throw new Error("Erro ao buscar empréstimos: " + loansErr.message);

    // Installments + payments
    const { data: insts } = await supabase
      .from("installments")
      .select("id, amount, due_date, status, loan:loans!inner(store_name), payment_records(amount, paid_at, payment_method, card_fee)")
      .eq("user_id", userId)
      .eq("loan.store_name", data.storeName);

    let totalSold = 0;
    let totalReceived = 0;
    let totalPending = 0;
    let totalOverdue = 0;
    let totalCardFee = 0;
    const today = new Date().toISOString().slice(0, 10);

    for (const l of loans || []) totalSold += Number(l.total_amount || 0);
    for (const i of insts || []) {
      const paid = (i.payment_records || []).reduce((s: number, r: any) => s + Number(r.amount || 0), 0);
      const fees = (i.payment_records || []).reduce((s: number, r: any) => s + Number(r.card_fee || 0), 0);
      totalReceived += paid;
      totalCardFee += fees;
      const remaining = Number(i.amount) - paid;
      if (remaining > 0) {
        totalPending += remaining;
        if (i.status === "overdue" || (i.due_date && i.due_date < today)) totalOverdue += remaining;
      }
    }

    const commissionPercent = Number(storeRow?.commission_percent || 0);
    const commissionValue = totalReceived * (commissionPercent / 100);

    return {
      store: storeRow,
      storeName: data.storeName,
      loansCount: (loans || []).length,
      totalSold,
      totalReceived,
      totalPending,
      totalOverdue,
      totalCardFee,
      commissionPercent,
      commissionValue,
      netReceived: totalReceived - totalCardFee,
      loans: loans || [],
    };
  });

// ============== STORE LOGIN ==============

const slugifyUsername = (raw: string) =>
  String(raw || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, 40);

export const storeUsernameToEmail = (username: string) =>
  `loja-${slugifyUsername(username)}@lojas.verapay.app`;

// Admin: create login credentials for an existing store
export const createStoreLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeId: string; username: string; password: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const supabaseAdmin = await requireAdminRole(userId);

    const username = slugifyUsername(data.username);
    if (username.length < 3) throw new Error("Usuário precisa ter ao menos 3 caracteres (letras/números).");
    if (!data.password || data.password.length < 6) throw new Error("Senha precisa ter no mínimo 6 caracteres.");

    // Confirm store belongs to admin
    const { data: store, error: sErr } = await supabase
      .from("stores")
      .select("id, name, auth_user_id")
      .eq("id", data.storeId)
      .eq("user_id", userId)
      .maybeSingle();
    if (sErr || !store) throw new Error("Loja não encontrada.");
    if (store.auth_user_id) throw new Error("Esta loja já possui acesso. Remova o atual para criar outro.");

    const email = `loja-${username}@lojas.verapay.app`;

    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: data.password,
      email_confirm: true,
      user_metadata: { kind: "store", store_id: store.id, store_name: store.name },
    });
    if (createErr || !created.user) throw new Error("Não foi possível criar o acesso: " + (createErr?.message || ""));

    const { error: updErr } = await supabase
      .from("stores")
      .update({ username, auth_user_id: created.user.id })
      .eq("id", store.id)
      .eq("user_id", userId);
    if (updErr) {
      await supabaseAdmin.auth.admin.deleteUser(created.user.id);
      throw new Error("Falha ao vincular acesso à loja: " + updErr.message);
    }

    return { username, email };
  });

// Admin: reset store login password
export const updateStoreLoginPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeId: string; password: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const supabaseAdmin = await requireAdminRole(userId);
    if (!data.password || data.password.length < 6) throw new Error("Senha precisa ter no mínimo 6 caracteres.");

    const { data: store, error: sErr } = await supabase
      .from("stores")
      .select("id, auth_user_id")
      .eq("id", data.storeId)
      .eq("user_id", userId)
      .maybeSingle();
    if (sErr || !store) throw new Error("Loja não encontrada.");
    if (!store.auth_user_id) throw new Error("Esta loja não possui acesso cadastrado.");

    const { error: updErr } = await supabaseAdmin.auth.admin.updateUserById(store.auth_user_id, {
      password: data.password,
    });
    if (updErr) throw new Error("Falha ao atualizar senha: " + updErr.message);
    return { ok: true };
  });

export const removeStoreLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { storeId: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const { data: store } = await supabase
      .from("stores")
      .select("id, auth_user_id")
      .eq("id", data.storeId)
      .eq("user_id", userId)
      .maybeSingle();
    if (!store?.auth_user_id) return { ok: true };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.auth.admin.deleteUser(store.auth_user_id).catch(() => {});
    await supabase
      .from("stores")
      .update({ username: null, auth_user_id: null })
      .eq("id", store.id)
      .eq("user_id", userId);
    return { ok: true };
  });

// Store-authenticated: fetch own store + owner
const getStoreContext = async (supabase: any, userId: string) => {
  const { data: store, error } = await supabase
    .from("stores")
    .select("id, name, user_id, commission_percent, auth_user_id")
    .eq("auth_user_id", userId)
    .maybeSingle();
  if (error) throw new Error("Erro ao identificar loja.");
  if (!store) throw new Error("Esta conta não está vinculada a uma loja.");
  return store;
};

export const getMyStore = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    return await getStoreContext(supabase, userId);
  });

// Helper: compute available limit for a customer (limit - open installments)
const computeCustomerLimit = async (supabaseAdmin: any, customerId: string, creditLimit: number) => {
  const { data: openInst } = await supabaseAdmin
    .from("installments")
    .select("amount")
    .eq("customer_id", customerId)
    .neq("status", "paid");
  const used = (openInst || []).reduce((s: number, r: any) => s + Number(r.amount || 0), 0);
  const limit = Number(creditLimit || 0);
  return { creditLimit: limit, usedAmount: used, availableLimit: Math.max(0, limit - used) };
};

const consumeTemporaryLimitRelease = async (supabaseAdmin: any, customerId: string, storeId: string) => {
  const { data: releases, error } = await supabaseAdmin
    .from("limit_requests")
    .select("id, applied_delta")
    .eq("customer_id", customerId)
    .eq("store_id", storeId)
    .eq("status", "approved")
    .is("consumed_at", null)
    .gt("applied_delta", 0);
  if (error) throw new Error("Erro ao localizar liberação temporária: " + error.message);

  const totalDelta = (releases || []).reduce((sum: number, row: any) => sum + Number(row.applied_delta || 0), 0);
  if (totalDelta <= 0) return { consumed: false, revertedAmount: 0 };

  const { data: customer, error: customerError } = await supabaseAdmin
    .from("customers")
    .select("credit_limit")
    .eq("id", customerId)
    .maybeSingle();
  if (customerError || !customer) throw new Error("Erro ao atualizar limite após compra.");

  const revertedLimit = Math.max(0, Number(customer.credit_limit || 0) - totalDelta);
  const { error: updateError } = await supabaseAdmin
    .from("customers")
    .update({ credit_limit: revertedLimit })
    .eq("id", customerId);
  if (updateError) throw new Error("Erro ao normalizar limite: " + updateError.message);

  const ids = (releases || []).map((row: any) => row.id);
  const { error: markError } = await supabaseAdmin
    .from("limit_requests")
    .update({ consumed_at: new Date().toISOString() })
    .in("id", ids);
  if (markError) throw new Error("Erro ao finalizar liberação temporária: " + markError.message);

  return { consumed: true, revertedAmount: totalDelta };
};

// Store: lookup customer by id (from QR). Customer must belong to store's owner.
export const storeFindCustomer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const store = await getStoreContext(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: customer, error } = await supabaseAdmin
      .from("customers")
      .select("id, name, cpf, phone, credit_limit, status, avatar_url, user_id")
      .eq("id", data.customerId)
      .maybeSingle();
    if (error) throw new Error("Erro ao buscar cliente.");
    if (!customer) throw new Error("Cliente não encontrado.");
    if (customer.user_id !== store.user_id) throw new Error("Cliente não pertence à sua administradora.");
    const limits = await computeCustomerLimit(supabaseAdmin, customer.id, Number(customer.credit_limit ?? 0));
    return { customer, store, ...limits };
  });

// Store: create 3x purchase for a customer
export const storeCreatePurchase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string; totalAmount: number; orderNumber?: string; deliveryNote?: string; notes?: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const store = await getStoreContext(supabase, userId);
    const total = Number(data.totalAmount);
    if (!data.customerId) throw new Error("Cliente obrigatório.");
    if (!(total > 0)) throw new Error("Valor inválido.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: customer } = await supabaseAdmin
      .from("customers")
      .select("id, user_id, credit_limit")
      .eq("id", data.customerId)
      .maybeSingle();
    if (!customer || customer.user_id !== store.user_id) throw new Error("Cliente inválido.");

    const limits = await computeCustomerLimit(supabaseAdmin, customer.id, Number(customer.credit_limit ?? 0));
    if (total > limits.availableLimit) {
      throw new Error(`Limite insuficiente. Disponível: R$ ${limits.availableLimit.toFixed(2).replace(".", ",")}. Solicite liberação ao administrador.`);
    }

    const today = new Date();
    const loanDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;

    const { data: loan, error: loanErr } = await supabaseAdmin
      .from("loans")
      .insert({
        user_id: store.user_id,
        customer_id: customer.id,
        store_name: store.name,
        total_amount: total,
        loan_date: loanDate,
        installments_count: 3,
        order_number: data.orderNumber || null,
        delivery_note: data.deliveryNote || null,
        notes: data.notes || null,
        legal_terms_accepted: true,
      })
      .select()
      .single();
    if (loanErr || !loan) throw new Error("Erro ao criar compra: " + (loanErr?.message || ""));

    const amountPer = total / 3;
    const anchorY = today.getFullYear();
    const anchorM = today.getMonth() + 2;
    const anchorD = 10;
    const installments = Array.from({ length: 3 }).map((_, i) => {
      const dt = new Date(anchorY, anchorM + i, anchorD);
      const dueDate = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
      return {
        user_id: store.user_id,
        loan_id: loan.id,
        customer_id: customer.id,
        number: i + 1,
        amount: amountPer,
        due_date: dueDate,
        status: "pending",
      };
    });
    const { error: instErr } = await supabaseAdmin.from("installments").insert(installments as any);
    if (instErr) throw new Error("Erro ao criar parcelas: " + instErr.message);

    const release = await consumeTemporaryLimitRelease(supabaseAdmin, customer.id, store.id);

    return { loan, installmentsCount: 3, amountPer, temporaryReleaseConsumed: release.consumed, revertedAmount: release.revertedAmount };
  });

// Store: request limit increase to system owner
export const storeRequestLimit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { customerId: string; requestedAmount?: number; purchaseAmount?: number; reason?: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const store = await getStoreContext(supabase, userId);
    // 0 = loja não sugeriu valor; admin decide.
    const requested = Number(data.requestedAmount || 0);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: customer } = await supabaseAdmin
      .from("customers")
      .select("id, user_id")
      .eq("id", data.customerId)
      .maybeSingle();
    if (!customer || customer.user_id !== store.user_id) throw new Error("Cliente inválido.");
    const { error } = await supabaseAdmin.from("limit_requests").insert({
      owner_user_id: store.user_id,
      customer_id: customer.id,
      store_id: store.id,
      store_name: store.name,
      requested_amount: requested,
      purchase_amount: data.purchaseAmount ? Number(data.purchaseAmount) : null,
      reason: data.reason || null,
      status: "pending",
    });
    if (error) throw new Error("Erro ao enviar solicitação: " + error.message);
    return { ok: true };
  });

// Admin: list limit requests
export const listLimitRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("limit_requests")
      .select("*, customer:customers(id, name, cpf, credit_limit)")
      .eq("owner_user_id", userId)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error("Erro ao listar solicitações.");
    return data || [];
  });

// Admin: respond to limit request (approve increases customer's credit_limit)
export const respondLimitRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { id: string; approve: boolean; approvedAmount?: number; note?: string }) => d)
  .handler(async ({ context, data }: { context: any; data: any }) => {
    const { supabase, userId } = context;
    const supabaseAdmin = await requireAdminRole(userId);
    let approvedAmount: number | null = null;
    let appliedDelta = 0;
    const { data: req, error: reqErr } = await supabase
      .from("limit_requests")
      .select("*")
      .eq("id", data.id)
      .eq("owner_user_id", userId)
      .maybeSingle();
    if (reqErr || !req) throw new Error("Solicitação não encontrada.");
    if (req.status !== "pending") throw new Error("Solicitação já respondida.");

    if (data.approve) {
      approvedAmount = Number(data.approvedAmount ?? req.requested_amount);
      if (!(approvedAmount > 0)) throw new Error("Valor aprovado inválido.");
      const { data: cust } = await supabaseAdmin
        .from("customers")
        .select("credit_limit")
        .eq("id", req.customer_id)
        .maybeSingle();
      const current = Number(cust?.credit_limit || 0);
      appliedDelta = approvedAmount;
      const target = current + appliedDelta;
      const { error: upErr } = await supabaseAdmin
        .from("customers")
        .update({ credit_limit: target })
        .eq("id", req.customer_id);
      if (upErr) throw new Error("Erro ao atualizar limite: " + upErr.message);
    }

    const { error } = await supabase
      .from("limit_requests")
      .update({
        status: data.approve ? "approved" : "rejected",
        responded_at: new Date().toISOString(),
        response_note: data.note || null,
        approved_amount: data.approve ? approvedAmount : null,
        applied_delta: data.approve ? appliedDelta : 0,
      })
      .eq("id", data.id);
    if (error) throw new Error("Erro ao responder: " + error.message);
    return { ok: true };
  });


// Store: list recent purchases the store created
export const storeListRecentPurchases = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const store = await getStoreContext(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("loans")
      .select("id, total_amount, loan_date, installments_count, order_number, customer:customers(id, name)")
      .eq("user_id", store.user_id)
      .eq("store_name", store.name)
      .order("created_at", { ascending: false })
      .limit(20);
    if (error) throw new Error("Erro ao listar compras.");
    return data || [];
  });

// List monthly purchase totals (by loan, not by installment) for this store
export const storeListMonthlyPurchases = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    const store = await getStoreContext(supabase, userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("loans")
      .select("id, total_amount, loan_date")
      .eq("user_id", store.user_id)
      .eq("store_name", store.name)
      .order("loan_date", { ascending: false });
    if (error) throw new Error("Erro ao listar compras mensais.");
    const map = new Map<string, { month: string; total: number; count: number }>();
    for (const l of data || []) {
      const d = new Date(l.loan_date as any);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const cur = map.get(key) || { month: key, total: 0, count: 0 };
      cur.total += Number(l.total_amount) || 0;
      cur.count += 1;
      map.set(key, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.month.localeCompare(a.month));
  });




// Get or create my customer self-signup token
export const getMySignupToken = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }: { context: any }) => {
    const { supabase, userId } = context;
    let { data, error } = await supabase
      .from("profiles")
      .select("signup_token")
      .eq("id", userId)
      .maybeSingle();
    if (error) throw new Error("Erro ao buscar token");
    if (!data || !data.signup_token) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { data: upd, error: uErr } = await supabaseAdmin
        .from("profiles")
        .upsert({ id: userId, signup_token: crypto.randomUUID() as any }, { onConflict: "id" })
        .select("signup_token")
        .single();
      if (uErr) throw new Error("Erro ao gerar token");
      return { token: upd.signup_token };
    }
    return { token: data.signup_token };
  });

// Public: lookup admin name by signup token (for showing on the public form)
export const lookupSignupToken = createServerFn({ method: "GET" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: prof, error } = await supabaseAdmin
      .from("profiles")
      .select("id, display_name")
      .eq("signup_token", data.token)
      .maybeSingle();
    if (error || !prof) throw new Error("Link de cadastro inválido");
    return { adminName: prof.display_name || "Administrador" };
  });

// Public: register customer using signup token (no auth)
export const registerCustomerByToken = createServerFn({ method: "POST" })
  .inputValidator((d: any) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { token, name, phone, secondary_phone, cpf, cep, address_street, address_number, address_complement, address_neighborhood, address_city, address_state } = data || {};
    if (!token) throw new Error("Token ausente");
    if (!name || !phone || !cpf) throw new Error("Nome, telefone e CPF são obrigatórios");

    const { data: prof, error: pErr } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("signup_token", token)
      .maybeSingle();
    if (pErr || !prof) throw new Error("Link de cadastro inválido");

    const cleanedCpf = String(cpf).replace(/\D/g, "");

    const { data: inserted, error } = await supabaseAdmin
      .from("customers")
      .insert({
        user_id: prof.id,
        name,
        phone,
        secondary_phone: secondary_phone || null,
        cpf: cleanedCpf,
        credit_limit: 0,
        status: "active",
        cep: cep || null,
        address_street: address_street || null,
        address_number: address_number || null,
        address_complement: address_complement || null,
        address_neighborhood: address_neighborhood || null,
        address_city: address_city || null,
        address_state: address_state || null,
      })
      .select("id")
      .single();

    if (error) {
      if ((error as any).code === "23505") throw new Error("Já existe um cadastro com este CPF.");
      throw new Error("Erro ao cadastrar");
    }
    return { ok: true, id: inserted.id };
  });
