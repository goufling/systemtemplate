export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      access_requests: {
        Row: {
          created_at: string
          email: string
          full_name: string | null
          id: string
          notes: string | null
          requested_role: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          full_name?: string | null
          id?: string
          notes?: string | null
          requested_role?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          notes?: string | null
          requested_role?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      activity_logs: {
        Row: {
          action: string
          created_at: string | null
          id: string
          new_data: Json | null
          old_data: Json | null
          record_id: string
          table_name: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string | null
          id?: string
          new_data?: Json | null
          old_data?: Json | null
          record_id: string
          table_name: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string | null
          id?: string
          new_data?: Json | null
          old_data?: Json | null
          record_id?: string
          table_name?: string
          user_id?: string
        }
        Relationships: []
      }
      customer_month_closings: {
        Row: {
          closed_at: string
          closed_by_role: string
          closed_by_user_id: string | null
          created_at: string
          customer_id: string
          id: string
          month: number
          notes: string | null
          total_amount: number | null
          updated_at: string
          user_id: string
          year: number
        }
        Insert: {
          closed_at?: string
          closed_by_role?: string
          closed_by_user_id?: string | null
          created_at?: string
          customer_id: string
          id?: string
          month: number
          notes?: string | null
          total_amount?: number | null
          updated_at?: string
          user_id: string
          year: number
        }
        Update: {
          closed_at?: string
          closed_by_role?: string
          closed_by_user_id?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          month?: number
          notes?: string | null
          total_amount?: number | null
          updated_at?: string
          user_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "customer_month_closings_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          address_city: string | null
          address_complement: string | null
          address_neighborhood: string | null
          address_number: string | null
          address_state: string | null
          address_street: string | null
          avatar_url: string | null
          cep: string | null
          client_user_id: string | null
          cpf: string | null
          created_at: string
          credit_limit: number | null
          id: string
          is_favorite: boolean | null
          name: string
          notes: string | null
          phone: string | null
          secondary_phone: string | null
          status: string | null
          tags: string[] | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address_city?: string | null
          address_complement?: string | null
          address_neighborhood?: string | null
          address_number?: string | null
          address_state?: string | null
          address_street?: string | null
          avatar_url?: string | null
          cep?: string | null
          client_user_id?: string | null
          cpf?: string | null
          created_at?: string
          credit_limit?: number | null
          id?: string
          is_favorite?: boolean | null
          name: string
          notes?: string | null
          phone?: string | null
          secondary_phone?: string | null
          status?: string | null
          tags?: string[] | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address_city?: string | null
          address_complement?: string | null
          address_neighborhood?: string | null
          address_number?: string | null
          address_state?: string | null
          address_street?: string | null
          avatar_url?: string | null
          cep?: string | null
          client_user_id?: string | null
          cpf?: string | null
          created_at?: string
          credit_limit?: number | null
          id?: string
          is_favorite?: boolean | null
          name?: string
          notes?: string | null
          phone?: string | null
          secondary_phone?: string | null
          status?: string | null
          tags?: string[] | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      installments: {
        Row: {
          amount: number
          card_fee: number | null
          cheque_bank: string | null
          cheque_date: string | null
          cheque_number: string | null
          created_at: string
          customer_id: string
          discount_amount: number | null
          due_date: string
          id: string
          interest_amount: number | null
          loan_id: string
          notes: string | null
          number: number
          original_amount: number | null
          paid_at: string | null
          payment_method: string | null
          penalty_amount: number | null
          receipt_url: string | null
          renegotiation_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          card_fee?: number | null
          cheque_bank?: string | null
          cheque_date?: string | null
          cheque_number?: string | null
          created_at?: string
          customer_id: string
          discount_amount?: number | null
          due_date: string
          id?: string
          interest_amount?: number | null
          loan_id: string
          notes?: string | null
          number: number
          original_amount?: number | null
          paid_at?: string | null
          payment_method?: string | null
          penalty_amount?: number | null
          receipt_url?: string | null
          renegotiation_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          card_fee?: number | null
          cheque_bank?: string | null
          cheque_date?: string | null
          cheque_number?: string | null
          created_at?: string
          customer_id?: string
          discount_amount?: number | null
          due_date?: string
          id?: string
          interest_amount?: number | null
          loan_id?: string
          notes?: string | null
          number?: number
          original_amount?: number | null
          paid_at?: string | null
          payment_method?: string | null
          penalty_amount?: number | null
          receipt_url?: string | null
          renegotiation_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "installments_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installments_loan_id_fkey"
            columns: ["loan_id"]
            isOneToOne: false
            referencedRelation: "loans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "installments_renegotiation_id_fkey"
            columns: ["renegotiation_id"]
            isOneToOne: false
            referencedRelation: "renegotiations"
            referencedColumns: ["id"]
          },
        ]
      }
      limit_requests: {
        Row: {
          applied_delta: number
          approved_amount: number | null
          consumed_at: string | null
          created_at: string
          customer_id: string
          id: string
          owner_user_id: string
          purchase_amount: number | null
          reason: string | null
          requested_amount: number
          responded_at: string | null
          response_note: string | null
          status: string
          store_id: string | null
          store_name: string | null
          updated_at: string
        }
        Insert: {
          applied_delta?: number
          approved_amount?: number | null
          consumed_at?: string | null
          created_at?: string
          customer_id: string
          id?: string
          owner_user_id: string
          purchase_amount?: number | null
          reason?: string | null
          requested_amount: number
          responded_at?: string | null
          response_note?: string | null
          status?: string
          store_id?: string | null
          store_name?: string | null
          updated_at?: string
        }
        Update: {
          applied_delta?: number
          approved_amount?: number | null
          consumed_at?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          owner_user_id?: string
          purchase_amount?: number | null
          reason?: string | null
          requested_amount?: number
          responded_at?: string | null
          response_note?: string | null
          status?: string
          store_id?: string | null
          store_name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "limit_requests_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "limit_requests_store_id_fkey"
            columns: ["store_id"]
            isOneToOne: false
            referencedRelation: "stores"
            referencedColumns: ["id"]
          },
        ]
      }
      loans: {
        Row: {
          attachment_url: string | null
          capital_source: string | null
          contract_pdf_url: string | null
          created_at: string
          customer_id: string
          delivery_note: string | null
          id: string
          installments_count: number
          legal_terms_accepted: boolean | null
          loan_date: string
          notes: string | null
          order_number: string | null
          profit_margin_percent: number | null
          status: string
          store_name: string
          total_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          attachment_url?: string | null
          capital_source?: string | null
          contract_pdf_url?: string | null
          created_at?: string
          customer_id: string
          delivery_note?: string | null
          id?: string
          installments_count?: number
          legal_terms_accepted?: boolean | null
          loan_date?: string
          notes?: string | null
          order_number?: string | null
          profit_margin_percent?: number | null
          status?: string
          store_name: string
          total_amount: number
          updated_at?: string
          user_id: string
        }
        Update: {
          attachment_url?: string | null
          capital_source?: string | null
          contract_pdf_url?: string | null
          created_at?: string
          customer_id?: string
          delivery_note?: string | null
          id?: string
          installments_count?: number
          legal_terms_accepted?: boolean | null
          loan_date?: string
          notes?: string | null
          order_number?: string | null
          profit_margin_percent?: number | null
          status?: string
          store_name?: string
          total_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "loans_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      month_closings: {
        Row: {
          closed_at: string
          created_at: string
          id: string
          month: number
          notes: string | null
          totals: Json | null
          updated_at: string
          user_id: string
          year: number
        }
        Insert: {
          closed_at?: string
          created_at?: string
          id?: string
          month: number
          notes?: string | null
          totals?: Json | null
          updated_at?: string
          user_id: string
          year: number
        }
        Update: {
          closed_at?: string
          created_at?: string
          id?: string
          month?: number
          notes?: string | null
          totals?: Json | null
          updated_at?: string
          user_id?: string
          year?: number
        }
        Relationships: []
      }
      payment_records: {
        Row: {
          amount: number
          card_fee: number | null
          cheque_bank: string | null
          cheque_date: string | null
          cheque_number: string | null
          created_at: string
          id: string
          installment_id: string
          paid_at: string
          payment_method: string
          proof_url: string | null
          user_id: string
        }
        Insert: {
          amount: number
          card_fee?: number | null
          cheque_bank?: string | null
          cheque_date?: string | null
          cheque_number?: string | null
          created_at?: string
          id?: string
          installment_id: string
          paid_at?: string
          payment_method: string
          proof_url?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          card_fee?: number | null
          cheque_bank?: string | null
          cheque_date?: string | null
          cheque_number?: string | null
          created_at?: string
          id?: string
          installment_id?: string
          paid_at?: string
          payment_method?: string
          proof_url?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_records_installment_id_fkey"
            columns: ["installment_id"]
            isOneToOne: false
            referencedRelation: "installments"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_categories: {
        Row: {
          color: string | null
          created_at: string
          icon: string | null
          id: string
          monthly_budget: number | null
          name: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          monthly_budget?: number | null
          name: string
          type?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string | null
          created_at?: string
          icon?: string | null
          id?: string
          monthly_budget?: number | null
          name?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      personal_credit_card_expenses: {
        Row: {
          category_id: string | null
          category_name: string | null
          created_at: string
          credit_card_id: string
          current_installment: number
          description: string
          id: string
          installments: number
          notes: string | null
          purchase_date: string
          total_amount: number
          user_id: string
        }
        Insert: {
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          credit_card_id: string
          current_installment?: number
          description: string
          id?: string
          installments?: number
          notes?: string | null
          purchase_date?: string
          total_amount: number
          user_id: string
        }
        Update: {
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          credit_card_id?: string
          current_installment?: number
          description?: string
          id?: string
          installments?: number
          notes?: string | null
          purchase_date?: string
          total_amount?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_credit_card_expenses_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "personal_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "personal_credit_card_expenses_credit_card_id_fkey"
            columns: ["credit_card_id"]
            isOneToOne: false
            referencedRelation: "personal_credit_cards"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_credit_cards: {
        Row: {
          active: boolean
          bank: string | null
          brand: string | null
          closing_day: number
          color: string | null
          created_at: string
          credit_limit: number
          due_day: number
          id: string
          last_digits: string | null
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          bank?: string | null
          brand?: string | null
          closing_day: number
          color?: string | null
          created_at?: string
          credit_limit?: number
          due_day: number
          id?: string
          last_digits?: string | null
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          bank?: string | null
          brand?: string | null
          closing_day?: number
          color?: string | null
          created_at?: string
          credit_limit?: number
          due_day?: number
          id?: string
          last_digits?: string | null
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      personal_goals: {
        Row: {
          color: string | null
          completed: boolean
          created_at: string
          current_amount: number
          deadline: string | null
          icon: string | null
          id: string
          name: string
          notes: string | null
          target_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string | null
          completed?: boolean
          created_at?: string
          current_amount?: number
          deadline?: string | null
          icon?: string | null
          id?: string
          name: string
          notes?: string | null
          target_amount: number
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string | null
          completed?: boolean
          created_at?: string
          current_amount?: number
          deadline?: string | null
          icon?: string | null
          id?: string
          name?: string
          notes?: string | null
          target_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      personal_recurring_bills: {
        Row: {
          active: boolean
          amount: number
          category_id: string | null
          category_name: string | null
          created_at: string
          description: string
          due_day: number
          id: string
          notes: string | null
          reminder_days_before: number | null
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          amount: number
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          description: string
          due_day: number
          id?: string
          notes?: string | null
          reminder_days_before?: number | null
          type?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          amount?: number
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          description?: string
          due_day?: number
          id?: string
          notes?: string | null
          reminder_days_before?: number | null
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_recurring_bills_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "personal_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      personal_transactions: {
        Row: {
          amount: number
          category_id: string | null
          category_name: string | null
          created_at: string
          credit_card_id: string | null
          description: string
          id: string
          notes: string | null
          payment_method: string | null
          receipt_url: string | null
          recurring_bill_id: string | null
          source: string | null
          transaction_date: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          credit_card_id?: string | null
          description: string
          id?: string
          notes?: string | null
          payment_method?: string | null
          receipt_url?: string | null
          recurring_bill_id?: string | null
          source?: string | null
          transaction_date?: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          category_id?: string | null
          category_name?: string | null
          created_at?: string
          credit_card_id?: string | null
          description?: string
          id?: string
          notes?: string | null
          payment_method?: string | null
          receipt_url?: string | null
          recurring_bill_id?: string | null
          source?: string | null
          transaction_date?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "personal_transactions_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "personal_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
          signup_token: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id: string
          signup_token?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          signup_token?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      renegotiations: {
        Row: {
          created_at: string | null
          id: string
          installment_id: string
          new_installment_id: string | null
          original_amount: number
          paid_amount: number
          reason: string | null
          remaining_amount: number
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          installment_id: string
          new_installment_id?: string | null
          original_amount: number
          paid_amount: number
          reason?: string | null
          remaining_amount: number
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          installment_id?: string
          new_installment_id?: string | null
          original_amount?: number
          paid_amount?: number
          reason?: string | null
          remaining_amount?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "renegotiations_installment_id_fkey"
            columns: ["installment_id"]
            isOneToOne: false
            referencedRelation: "installments"
            referencedColumns: ["id"]
          },
        ]
      }
      store_month_closings: {
        Row: {
          closed_at: string
          closed_by_user_id: string | null
          commission_amount: number | null
          created_at: string
          id: string
          month: number
          notes: string | null
          payment_details: Json | null
          payment_method: string | null
          purchases_count: number
          store_name: string
          total_amount: number
          updated_at: string
          user_id: string
          year: number
        }
        Insert: {
          closed_at?: string
          closed_by_user_id?: string | null
          commission_amount?: number | null
          created_at?: string
          id?: string
          month: number
          notes?: string | null
          payment_details?: Json | null
          payment_method?: string | null
          purchases_count?: number
          store_name: string
          total_amount?: number
          updated_at?: string
          user_id: string
          year: number
        }
        Update: {
          closed_at?: string
          closed_by_user_id?: string | null
          commission_amount?: number | null
          created_at?: string
          id?: string
          month?: number
          notes?: string | null
          payment_details?: Json | null
          payment_method?: string | null
          purchases_count?: number
          store_name?: string
          total_amount?: number
          updated_at?: string
          user_id?: string
          year?: number
        }
        Relationships: []
      }
      stores: {
        Row: {
          auth_user_id: string | null
          category: string | null
          commission_percent: number | null
          created_at: string | null
          id: string
          name: string
          updated_at: string | null
          user_id: string
          username: string | null
        }
        Insert: {
          auth_user_id?: string | null
          category?: string | null
          commission_percent?: number | null
          created_at?: string | null
          id?: string
          name: string
          updated_at?: string | null
          user_id: string
          username?: string | null
        }
        Update: {
          auth_user_id?: string | null
          category?: string | null
          commission_percent?: number | null
          created_at?: string | null
          id?: string
          name?: string
          updated_at?: string | null
          user_id?: string
          username?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "client"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "client"],
    },
  },
} as const
